import { FrostboundApp } from '@/components/frostbound-app'

export default function Page() {
  return <FrostboundApp />
}
