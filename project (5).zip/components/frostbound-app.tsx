'use client'

import dynamic from 'next/dynamic'
import '@/frostbound/src/foundation.css'
import '@/frostbound/src/styles.css'
import '@/frostbound/src/science.css'
import '@/frostbound/src/cryo.css'

// The app reads localStorage during initial state, so it renders client-only.
const App = dynamic(() => import('@/frostbound/src/App.jsx'), { ssr: false })

export function FrostboundApp() {
  return <App />
}
