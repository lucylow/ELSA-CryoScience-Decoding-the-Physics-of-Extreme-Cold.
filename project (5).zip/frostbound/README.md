# Elsa's Ice Palace — Replit App

A responsive, interactive fan-inspired exploration app centered on Elsa, her magical ice palace, and the winter world of Frozen.

## Run on Replit
1. Create a new **Node.js** Replit.
2. Upload/extract this ZIP into the project.
3. Run `npm install`.
4. Run `npm run dev` (or press Run if Replit detects the Vite script).

## Features
- Palace dashboard with a custom CSS-built ice castle scene.
- Explore rooms, architecture, magical details, and palace lore.
- Searchable character and location directory with rich mock data.
- Interactive snow-globe scene, snowflake generator, and spellbook.
- Palace design studio with editable architectural controls.
- Collections, quests, timeline, gallery, and journal.
- Local browser persistence for saved favorites and notes.

## Notes
This is an unofficial fan-made learning/demo project. It is not affiliated with or endorsed by Disney.
All story entries and metrics are illustrative mock data. No copyrighted film footage or official artwork is included; the palace visual is built from CSS shapes and gradients.
