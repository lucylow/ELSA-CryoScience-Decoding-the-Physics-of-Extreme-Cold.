import React, { useMemo, useState } from "react";
import { Snowflake } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import ResearchDashboard from "./pages/ResearchDashboard";
import MaterialsExplorer from "./pages/MaterialsExplorer";
import ScienceLab from "./pages/ScienceLab";
import Palace from "./pages/Palace";
import Magic from "./pages/Magic";
import Characters from "./pages/Characters";
import World from "./pages/World";
import Story from "./pages/Story";
import Gallery from "./pages/Gallery";
import Studio from "./pages/Studio";
import Journal from "./pages/Journal";
import Modal from "./components/Modal";
import { useLocalStorage } from "./hooks/useLocalStorage";
import Home from "./pages/Home";
import CrystalCampus from "./pages/CrystalCampus";
import Academy from "./pages/Academy";
import IcePhysics from "./pages/IcePhysics";
import CryoLab from "./pages/CryoLab";
import Experiments from "./pages/Experiments";

const PEARL_PAGES = new Set(["academy","experiments","ice","ice-phase","materials","materials-carbon"]);

const pageMeta = {
 home:["ELSA CryoScience","Decoding the physics of extreme cold"],
 campus:["Crystal Campus","Ten laboratories inside the crystal palace"],
 academy:["Science Academy","Learning pathways for every curious mind"],
 dashboard:["Research Dashboard","Extreme Low-Temperature Science & Advanced Materials Laboratory"],
 ice:["Ice Physics Observatory","Lattices, phase transitions, latent heat and snow"],
 "ice-phase":["Molecular Science","Molecules through solid, liquid and vapour"],
 cryo:["Cryogenic Laboratory","Materials and heat at extreme low temperature"],
 experiments:["Experimental Research","Synthetic demonstration records with quality flags"],
 "materials-carbon":["Sustainability Research","Embodied-carbon comparison across families"],
 materials:["Materials Intelligence","Browse transparent, synthetic demonstration records"],
 lab:["Thermal & Exposure Lab","Inspect assumptions and the calculation behind each result"],
 "lab-freeze":["Freeze–Thaw Lab","Explore a clearly illustrative exposure profile"],
 palace:["The Ice Palace","Explore Elsa's crystalline mountain sanctuary"],
 magic:["Magic & Spells","A playful field guide to winter magic"],
 characters:["Characters","Friends, family, and magical companions"],
 world:["The winter world","Explore the places beyond the palace"],
 story:["Story Timeline","Moments of courage, change, and discovery"],
 gallery:["Gallery","A visual notebook of winter wonders"],
 studio:["Palace Studio","Shape a new concept for the ice palace"],
 journal:["Explorer's Journal","Keep your discoveries close"]
};
export default function App() {
 const [page,setPage]=useState("home");
 const [mobileOpen,setMobileOpen]=useState(false);
 const [search,setSearch]=useState("");
 const [favorites,setFavorites]=useLocalStorage("frostbound-favorites",[]);
 const [notes,setNotes]=useLocalStorage("frostbound-notes",[]);
 const [help,setHelp]=useState(false);
 const [room,setRoom]=useState(null);
 const title=pageMeta[page]?.[0]||"Research Dashboard";
 const content=useMemo(()=>({
   home:<Home setPage={setPage}/>,
   campus:<CrystalCampus setPage={setPage} search={search}/>,
   academy:<Academy setPage={setPage} search={search}/>,
   dashboard:<ResearchDashboard setPage={setPage}/>,
   ice:<IcePhysics/>,
   "ice-phase":<IcePhysics initialTab="phase"/>,
   cryo:<CryoLab/>,
   experiments:<Experiments search={search}/>,
   "materials-carbon":<MaterialsExplorer search={search} initialMetric="embodiedCarbonKgCO2eKg"/>,
   materials:<MaterialsExplorer search={search}/>,
   lab:<ScienceLab/>,
   "lab-freeze":<ScienceLab initialTab="freeze"/>,
   palace:<Palace favorites={favorites} setFavorites={setFavorites} search={search}/>,
   magic:<Magic/>,characters:<Characters search={search}/>,world:<World/>,story:<Story/>,
   gallery:<Gallery search={search}/>,studio:<Studio/>,journal:<Journal notes={notes} setNotes={setNotes}/>
 })[page],[page,favorites,search,notes]);
 return <div className="app-shell"><Sidebar page={page} setPage={p=>{setPage(p);setSearch("");}} open={mobileOpen} onClose={()=>setMobileOpen(false)}/><main className={`main-area ${PEARL_PAGES.has(page)?"is-pearl":""} ${page==="home"?"is-home":""}`}><Topbar title={title} subtitle={pageMeta[page]?.[1]} onMenu={()=>setMobileOpen(true)} search={search} setSearch={setSearch}/><div key={page} className="cs-page-enter">{content}</div><footer className="app-footer"><span><Snowflake size={14} aria-hidden="true"/> ELSA CRYOSCIENCE</span><span>Synthetic demonstrations are labeled · Not for engineering design</span><button onClick={()=>setHelp(true)}>About this laboratory</button></footer></main>
 <Modal open={help} onClose={()=>setHelp(false)} title="About ELSA"><p>ELSA is an educational interface for exploring ice, materials, and cold-climate engineering. The research screens use deterministic synthetic demonstration data and simplified models.</p><p>These examples are not laboratory measurements, certified properties, validated simulations, or a substitute for engineering review.</p><div className="detail-chips"><span>React + Vite</span><span>Synthetic dataset</span><span>Illustrative models</span></div></Modal>
 <Modal open={!!room} onClose={()=>setRoom(null)} title={room?.name}><p>{room?.description}</p><div className="detail-chips"><span>{room?.level}</span><span>{room?.mood}</span></div><button className="primary-btn full-btn" onClick={()=>{setPage("palace");setRoom(null);}}>Open palace directory</button></Modal>
 </div>;
}
