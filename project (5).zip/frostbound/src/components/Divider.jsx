import React from "react";
export default function Divider(){return <div className="frost-divider"><span>✧</span></div>;}
