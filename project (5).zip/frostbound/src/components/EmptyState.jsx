import React from "react";
import { Snowflake } from "lucide-react";
export default function EmptyState({title="Nothing here yet",description="Explore the palace to discover more."}){return <div className="empty-state"><Snowflake/><h3>{title}</h3><p>{description}</p></div>;}
