import React from "react";
export default function PalaceScene({compact=false}) {
  return <div className={`palace-scene ${compact?"compact":""}`} aria-label="Illustration of a magical ice palace">
    <div className="scene-stars">{Array.from({length:28},(_,i)=><i key={i} style={{left:`${(i*37)%100}%`,top:`${(i*23)%78}%`,animationDelay:`${(i%7)*.4}s`}}/>)}</div>
    <div className="aurora aurora-one"/><div className="aurora aurora-two"/>
    <div className="mountain mountain-back"/><div className="mountain mountain-front"/>
    <div className="palace-ground"/>
    <div className="castle">
      <div className="tower tower-left"><div className="spire"/><div className="tower-body"><i/><i/></div></div>
      <div className="tower tower-right"><div className="spire"/><div className="tower-body"><i/><i/></div></div>
      <div className="tower tower-center"><div className="spire tall"/><div className="tower-body"><i/><i/><i/></div></div>
      <div className="castle-main"><div className="roof roof-left"/><div className="roof roof-right"/><div className="arch"><div className="door"/></div><div className="window w1"/><div className="window w2"/><div className="window w3"/></div>
      <div className="castle-base"/>
    </div>
    <div className="scene-snow">{Array.from({length:34},(_,i)=><span key={i} style={{left:`${(i*29)%100}%`,animationDelay:`${(i%9)*-.8}s`,animationDuration:`${7+(i%5)}s`}}/>)}</div>
    {!compact&&<div className="scene-caption"><span>THE NORTH MOUNTAIN</span><b>Elsa's Ice Palace</b><small>A kingdom shaped by wonder</small></div>}
  </div>;
}
