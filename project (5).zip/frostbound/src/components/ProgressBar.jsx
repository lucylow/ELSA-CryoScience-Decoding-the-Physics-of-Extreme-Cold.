import React from "react";
export default function ProgressBar({value=0,label}){return <div className="progress-wrap">{label&&<span>{label}</span>}<div className="progress-track"><i style={{width:`${Math.max(0,Math.min(100,value))}%`}}/></div></div>;}
