import React from "react";
import { ArrowUpRight, Snowflake } from "lucide-react";
export default function RoomCard({room,onClick,favorite,onFavorite}) {
  return <article className="room-card" onClick={()=>onClick(room)}><div className={`room-art art-${room.id}`} style={{"--room-color":room.color}}><div className="room-art-glow"/><div className="room-icon">{room.icon}</div><span className="room-level">{room.level}</span><button className={`favorite-btn ${favorite?"saved":""}`} onClick={e=>{e.stopPropagation();onFavorite(room.id);}} aria-label="Save room">♥</button></div><div className="room-info"><div><span className="eyebrow">{room.category} · {room.mood}</span><h3>{room.name}</h3><p>{room.description}</p></div><div className="room-foot"><span><Snowflake size={13}/>{room.temperature}</span><button className="text-link">Explore <ArrowUpRight size={14}/></button></div></div></article>;
}
