import React from "react";
import { Activity, Atom, BookOpen, Boxes, Castle, FlaskConical, GalleryHorizontalEnd, Globe2, GraduationCap, House, NotebookPen, Snowflake, Sparkles, Thermometer, ThermometerSnowflake, Users, WandSparkles, X } from "lucide-react";
import CryoEmblem from "./cryo/CryoEmblem";

const groups = [
  {
    label: "Discover",
    links: [
      ["Home", "home", House],
      ["Crystal campus", "campus", Castle],
      ["Science academy", "academy", GraduationCap],
    ],
  },
  {
    label: "Laboratories",
    links: [
      ["Research dashboard", "dashboard", Activity],
      ["Materials intelligence", "materials", Boxes],
      ["Ice physics", "ice", Atom],
      ["Cryogenic lab", "cryo", ThermometerSnowflake],
      ["Thermal lab", "lab", Thermometer],
      ["Freeze–thaw lab", "lab-freeze", Snowflake],
      ["Experiments", "experiments", FlaskConical],
    ],
  },
  {
    label: "Winter world",
    links: [
      ["The Ice Palace", "palace", Castle],
      ["Ice & snow magic", "magic", WandSparkles],
      ["Characters", "characters", Users],
      ["Winter world", "world", Globe2],
      ["Story timeline", "story", BookOpen],
      ["Gallery", "gallery", GalleryHorizontalEnd],
      ["Palace studio", "studio", Sparkles],
      ["Research journal", "journal", NotebookPen],
    ],
  },
];

const aliases = { "ice-phase": "ice", "materials-carbon": "materials" };

export default function Sidebar({ page, setPage, open, onClose }) {
  const current = aliases[page] ?? page;
  return (
    <>
      <div className={`sidebar-backdrop ${open ? "show" : ""}`} onClick={onClose} />
      <aside className={`sidebar ${open ? "mobile-open" : ""}`}>
        <div className="brand">
          <CryoEmblem size={42} withWordmark />
          <button className="icon-btn mobile-close" onClick={onClose} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <nav aria-label="Main navigation" className="cs-nav">
          {groups.map((g) => (
            <div key={g.label} className="cs-nav-group">
              <div className="nav-label">{g.label}</div>
              {g.links.map(([label, id, Icon]) => (
                <button key={id} className={`nav-link ${current === id ? "active" : ""}`} aria-current={current === id ? "page" : undefined} onClick={() => { setPage(id); onClose(); }}>
                  <Icon size={17} aria-hidden="true" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="mini-quote">“Your imagination belongs in science.”<small>ELSA CryoScience Academy</small></div>
        </div>
      </aside>
    </>
  );
}
