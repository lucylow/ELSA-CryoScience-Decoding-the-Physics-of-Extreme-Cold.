import React from "react";
export default function StatCard({icon,label,value,note}) {
  return <div className="stat-card"><div className="stat-icon">{icon}</div><div><small>{label}</small><strong>{value}</strong><span>{note}</span></div></div>;
}
