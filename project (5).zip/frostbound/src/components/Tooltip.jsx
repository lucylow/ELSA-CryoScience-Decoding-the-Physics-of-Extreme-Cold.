import React from "react";
export default function Tooltip({label,children}){return <span className="tooltip-wrap">{children}<span className="tooltip-text">{label}</span></span>;}
