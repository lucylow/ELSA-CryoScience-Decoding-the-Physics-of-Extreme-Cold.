import React from "react";
import { Menu, Search } from "lucide-react";

export default function Topbar({ title, subtitle, onMenu, search, setSearch }) {
  return (
    <header className="topbar">
      <div className="topbar-title">
        <button className="icon-btn menu-btn" onClick={onMenu} aria-label="Open navigation"><Menu aria-hidden="true" /></button>
        <div>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
      </div>
      <div className="topbar-actions">
        <label className="search-box">
          <Search size={16} aria-hidden="true" />
          <span className="sr-only">Search this page</span>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search this page…" />
        </label>
      </div>
    </header>
  );
}
