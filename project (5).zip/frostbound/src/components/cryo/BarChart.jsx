import React from "react";

const fmt = (v) => Number(Number(v).toPrecision(3)).toLocaleString("en-US");

export default function BarChart({ items, unit, log = false, ariaLabel, tone = "dark", caption }) {
  const values = items.map((i) => i.value);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const hasNegative = !log && min < 0;
  const logMin = log ? Math.log10(Math.min(...values.filter((v) => v > 0)) / 2) : 0;
  const logMax = log ? Math.log10(max) : 0;
  const lo = hasNegative ? min : 0;
  const span = max - lo || 1;
  const zero = hasNegative ? ((0 - lo) / span) * 100 : 0;

  const geometry = (v) => {
    if (log) return { left: 0, width: Math.max(1.5, ((Math.log10(v) - logMin) / (logMax - logMin || 1)) * 100) };
    const pos = ((v - lo) / span) * 100;
    return v >= 0 ? { left: zero, width: Math.max(0.8, pos - zero) } : { left: pos, width: zero - pos };
  };

  return (
    <figure className={`cs-bars cs-bars--${tone}`} aria-label={ariaLabel}>
      <ul>
        {items.map((item) => {
          const g = geometry(item.value);
          return (
            <li key={item.label} className={item.highlight ? "is-highlight" : ""}>
              <span className="cs-bars-label">{item.label}</span>
              <span className="cs-bars-track">
                {hasNegative && <i className="cs-bars-zero" style={{ left: `${zero}%` }} />}
                <span className="cs-bars-fill" style={{ left: `${g.left}%`, width: `${g.width}%`, background: item.color }} />
              </span>
              <span className="cs-bars-value">
                {fmt(item.value)} <small>{unit}</small>
              </span>
            </li>
          );
        })}
      </ul>
      {caption && <figcaption>{caption}{log ? " · Logarithmic scale." : ""}</figcaption>}
    </figure>
  );
}
