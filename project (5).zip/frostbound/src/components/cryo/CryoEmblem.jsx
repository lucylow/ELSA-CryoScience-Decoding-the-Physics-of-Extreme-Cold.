import React, { useId } from "react";

const ARM_ANGLES = [0, 60, 120, 180, 240, 300];

export default function CryoEmblem({ size = 40, withWordmark = false, className = "" }) {
  const gradientId = useId().replace(/:/g, "");
  return (
    <span className={`cs-emblem ${className}`}>
      <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id={`g${gradientId}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#f4fdff" />
            <stop offset=".55" stopColor="#7fe3f2" />
            <stop offset="1" stopColor="#a796f2" />
          </linearGradient>
        </defs>
        <circle cx="32" cy="32" r="30.5" fill="#0b1c37" stroke={`url(#g${gradientId})`} strokeOpacity=".6" />
        <ellipse cx="32" cy="32" rx="26" ry="8.5" fill="none" stroke="#a796f2" strokeOpacity=".75" strokeWidth=".9" transform="rotate(32 32 32)" />
        <ellipse cx="32" cy="32" rx="26" ry="8.5" fill="none" stroke="#7fe3f2" strokeOpacity=".6" strokeWidth=".9" transform="rotate(-32 32 32)" />
        <g stroke={`url(#g${gradientId})`} strokeWidth="1.7" strokeLinecap="round" fill="none">
          {ARM_ANGLES.map((angle) => (
            <g key={angle} transform={`rotate(${angle} 32 32)`}>
              <line x1="32" y1="32" x2="32" y2="12.5" />
              <line x1="32" y1="21" x2="28" y2="17.6" />
              <line x1="32" y1="21" x2="36" y2="17.6" />
            </g>
          ))}
        </g>
        {ARM_ANGLES.map((angle) => {
          const rad = (angle - 90) * (Math.PI / 180);
          return <circle key={angle} cx={32 + Math.cos(rad) * 19.5} cy={32 + Math.sin(rad) * 19.5} r="2.1" fill="#e9fbff" />;
        })}
        <path d="M13 47.5 q4.75 -3.6 9.5 0 t9.5 0 t9.5 0 t9.5 0" fill="none" stroke="#3fd2c0" strokeWidth="1.1" strokeOpacity=".85" />
        <circle cx="32" cy="32" r="3.4" fill="#7fe3f2" />
      </svg>
      {withWordmark && (
        <span className="cs-wordmark">
          <b>ELSA</b>
          <small>CRYOSCIENCE</small>
        </span>
      )}
    </span>
  );
}
