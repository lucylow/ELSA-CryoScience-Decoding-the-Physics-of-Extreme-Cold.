import React, { useId } from "react";

export const TOWERS = [
  { x: 175, w: 34, top: 340, spire: 268 },
  { x: 825, w: 34, top: 340, spire: 268 },
  { x: 270, w: 46, top: 290, spire: 196 },
  { x: 730, w: 46, top: 290, spire: 196 },
  { x: 380, w: 60, top: 230, spire: 118 },
  { x: 620, w: 60, top: 230, spire: 118 },
  { x: 500, w: 82, top: 168, spire: 34 },
];
const BASE = 440;

function Tower({ x, w, top, spire, fill, edge, index }) {
  const half = w / 2;
  const windows = Math.max(2, Math.floor((BASE - top) / 46));
  return (
    <g>
      <polygon points={`${x - half},${top} ${x},${spire} ${x + half},${top}`} fill={fill} stroke={edge} strokeWidth="1" />
      <line x1={x} y1={spire} x2={x} y2={top} stroke="#ffffff" strokeOpacity=".55" strokeWidth="1" />
      <rect x={x - half} y={top} width={w} height={BASE - top} fill={fill} stroke={edge} strokeWidth="1" />
      <polygon points={`${x},${top} ${x + half},${top} ${x + half},${BASE} ${x},${BASE}`} fill="#0b2a4a" opacity=".18" />
      {Array.from({ length: windows }, (_, i) => (
        <rect
          key={i}
          className="cs-win"
          style={{ animationDelay: `${((index * 3 + i) % 7) * 0.6}s` }}
          x={x - w * 0.16}
          y={top + 18 + i * 44}
          width={w * 0.32}
          height="20"
          rx={w * 0.16}
        />
      ))}
    </g>
  );
}

export default function CrystalPalace({ className = "", showPond = true }) {
  const id = useId().replace(/:/g, "");
  const fill = `url(#ice${id})`;
  const edge = "#e6fbff";
  return (
    <svg className={`cs-palace ${className}`} viewBox="0 0 1000 520" preserveAspectRatio="xMidYMax meet" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={`ice${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f2fdff" stopOpacity=".95" />
          <stop offset=".45" stopColor="#a9e6f6" stopOpacity=".72" />
          <stop offset="1" stopColor="#5d9fd0" stopOpacity=".5" />
        </linearGradient>
        <linearGradient id={`pond${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c8f3ff" stopOpacity=".55" />
          <stop offset="1" stopColor="#5b8fc8" stopOpacity=".08" />
        </linearGradient>
        <linearGradient id={`mtn${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d9e8f6" stopOpacity=".55" />
          <stop offset="1" stopColor="#25416c" stopOpacity=".2" />
        </linearGradient>
      </defs>
      <polygon points="0,520 0,330 140,236 250,300 372,196 490,262 640,176 780,286 880,222 1000,300 1000,520" fill={`url(#mtn${id})`} />
      <polygon points="0,520 0,400 120,350 300,410 520,360 700,412 880,356 1000,392 1000,520" fill="#dff3fb" opacity=".22" />
      <ellipse cx="500" cy="122" rx="78" ry="14" fill="none" stroke="#a796f2" strokeOpacity=".7" strokeWidth="1.2" className="cs-ring" />
      <g className="cs-bridges" fill="none" stroke="#e6fbff" strokeOpacity=".8" strokeWidth="2">
        <path d="M410 262 Q435 248 459 258" />
        <path d="M541 258 Q565 248 590 262" />
        <path d="M293 316 Q322 300 350 310" />
        <path d="M650 310 Q678 300 707 316" />
        <path d="M192 360 Q222 344 247 352" />
        <path d="M753 352 Q778 344 808 360" />
      </g>
      {TOWERS.map((t, i) => (
        <Tower key={t.x} {...t} fill={fill} edge={edge} index={i} />
      ))}
      <polygon points="320,440 320,346 360,318 640,318 680,346 680,440" fill={fill} stroke={edge} strokeWidth="1" />
      <path d="M470 440 L470 392 Q500 360 530 392 L530 440 Z" fill="#1b4f7b" opacity=".55" />
      <path d="M478 440 L478 396 Q500 372 522 396 L522 440 Z" className="cs-win cs-door" />
      {[352, 400, 584, 632].map((x, i) => (
        <rect key={x} className="cs-win" style={{ animationDelay: `${i * 0.9}s` }} x={x} y="362" width="16" height="30" rx="8" />
      ))}
      <path d="M110 446 Q300 430 500 446 T890 446 L900 458 L100 458 Z" fill="#f4fbff" opacity=".9" />
      <path d="M150 468 Q500 452 850 468 L860 476 L140 476 Z" fill="#e7f6fd" opacity=".7" />
      {showPond && (
        <g>
          <ellipse cx="500" cy="498" rx="380" ry="20" fill={`url(#pond${id})`} />
          <ellipse className="cs-pond-glint" cx="440" cy="496" rx="70" ry="3" fill="#ffffff" opacity=".5" />
        </g>
      )}
    </svg>
  );
}
