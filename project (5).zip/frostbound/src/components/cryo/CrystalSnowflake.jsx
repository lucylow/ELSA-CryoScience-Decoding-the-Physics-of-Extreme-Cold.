import React, { useId } from "react";

const ARMS = [0, 60, 120, 180, 240, 300];
const BRANCHES = [
  { y: -30, len: 24 },
  { y: -52, len: 19 },
  { y: -72, len: 12 },
];

export default function CrystalSnowflake({ className = "", strokeWidth = 2.2 }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg className={className} viewBox="-100 -100 200 200" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={`sf${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset=".5" stopColor="#9eeaf7" />
          <stop offset="1" stopColor="#b3a4f5" />
        </linearGradient>
        <radialGradient id={`sfc${id}`}>
          <stop offset="0" stopColor="#ffffff" stopOpacity=".9" />
          <stop offset="1" stopColor="#7fe3f2" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle r="40" fill={`url(#sfc${id})`} opacity=".45" />
      <g stroke={`url(#sf${id})`} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" fill="none">
        {ARMS.map((angle) => (
          <g key={angle} transform={`rotate(${angle})`}>
            <line x1="0" y1="-14" x2="0" y2="-92" />
            {BRANCHES.map(({ y, len }) => (
              <g key={y}>
                <line x1="0" y1={y} x2={len * 0.866} y2={y - len * 0.5} />
                <line x1="0" y1={y} x2={-len * 0.866} y2={y - len * 0.5} />
              </g>
            ))}
            <path d="M0 -98 L5 -91 L0 -84 L-5 -91 Z" />
          </g>
        ))}
        <polygon points="0,-14 12.1,-7 12.1,7 0,14 -12.1,7 -12.1,-7" />
        <polygon points="0,-6.5 5.6,-3.25 5.6,3.25 0,6.5 -5.6,3.25 -5.6,-3.25" opacity=".7" />
      </g>
    </svg>
  );
}
