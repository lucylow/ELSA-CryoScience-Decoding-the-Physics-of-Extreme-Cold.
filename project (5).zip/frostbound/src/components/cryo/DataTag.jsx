import React from "react";
import { BookOpen, Calculator, CircleDashed, FlaskConical, ShieldAlert } from "lucide-react";

const KINDS = {
  synthetic: { label: "Synthetic demonstration data", Icon: ShieldAlert },
  reference: { label: "Educational reference values", Icon: BookOpen },
  model: { label: "Simplified physics model", Icon: Calculator },
  measured: { label: "Measured experimental data", Icon: FlaskConical },
  missing: { label: "Not available in dataset", Icon: CircleDashed },
};

export default function DataTag({ kind = "synthetic", label, compact = false }) {
  const { label: defaultLabel, Icon } = KINDS[kind] ?? KINDS.synthetic;
  return (
    <span className={`cs-tag cs-tag--${kind} ${compact ? "cs-tag--compact" : ""}`}>
      <Icon size={compact ? 11 : 13} aria-hidden="true" />
      {label ?? defaultLabel}
    </span>
  );
}
