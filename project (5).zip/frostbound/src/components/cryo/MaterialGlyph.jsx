import React from "react";

export function materialClass(family) {
  const f = family.toLowerCase();
  if (f.includes("steel") || f.includes("aluminium")) return "metal";
  if (f.includes("concrete")) return "concrete";
  if (f.includes("timber") || f.includes("glulam")) return "timber";
  if (f.includes("composite")) return "composite";
  if (f.includes("polymer") || f.includes("thermoplastic") || f.includes("elastomer")) return "polymer";
  if (f.includes("wool") || f.includes("cellulose") || f.includes("aerogel")) return "insulation";
  if (f.includes("glass")) return "glass";
  return "metal";
}

export const classLabels = {
  metal: "Metals & alloys",
  concrete: "Concrete",
  timber: "Timber",
  composite: "Composites",
  polymer: "Polymers",
  insulation: "Insulation",
  glass: "Glass & ceramics",
};

const rand = (i) => ((Math.sin(i * 12.9898) * 43758.5453) % 1 + 1) % 1;

function Pattern({ kind }) {
  switch (kind) {
    case "metal":
      return (
        <g className="mg-lines">
          {[[0, 0, 38, 0, 30, 34, 0, 40], [38, 0, 80, 0, 74, 28, 30, 34], [80, 0, 120, 0, 120, 42, 74, 28], [0, 40, 30, 34, 44, 72, 0, 80], [30, 34, 74, 28, 88, 66, 44, 72], [74, 28, 120, 42, 120, 80, 88, 66], [0, 80, 44, 72, 52, 120, 0, 120], [44, 72, 88, 66, 92, 120, 52, 120], [88, 66, 120, 80, 120, 120, 92, 120]].map((p, i) => (
            <polygon key={i} points={p.join(" ")} style={{ fillOpacity: 0.08 + (i % 3) * 0.07 }} />
          ))}
        </g>
      );
    case "concrete":
      return (
        <g className="mg-fill">
          {Array.from({ length: 22 }, (_, i) => (
            <ellipse key={i} cx={rand(i) * 120} cy={rand(i + 40) * 120} rx={5 + rand(i + 9) * 11} ry={4 + rand(i + 3) * 9} transform={`rotate(${rand(i + 7) * 180} ${rand(i) * 120} ${rand(i + 40) * 120})`} />
          ))}
        </g>
      );
    case "timber":
      return (
        <g className="mg-lines">
          {Array.from({ length: 9 }, (_, i) => (
            <path key={i} d={`M-10 ${8 + i * 14} Q 30 ${2 + i * 14} 60 ${10 + i * 14} T 130 ${6 + i * 14}`} />
          ))}
        </g>
      );
    case "composite":
      return (
        <g className="mg-lines">
          {Array.from({ length: 12 }, (_, i) => <line key={`a${i}`} x1={i * 11} y1="0" x2={i * 11 - 40} y2="120" />)}
          {Array.from({ length: 12 }, (_, i) => <line key={`b${i}`} x1={i * 11} y1="0" x2={i * 11 + 40} y2="120" style={{ opacity: 0.45 }} />)}
        </g>
      );
    case "polymer":
      return (
        <g className="mg-lines">
          {Array.from({ length: 7 }, (_, i) => (
            <path key={i} d={`M-5 ${10 + i * 17} C 20 ${-5 + i * 17}, 30 ${30 + i * 17}, 55 ${12 + i * 17} S 95 ${28 + i * 17}, 125 ${8 + i * 17}`} />
          ))}
        </g>
      );
    case "insulation":
      return (
        <g className="mg-lines">
          {Array.from({ length: 26 }, (_, i) => (
            <line key={i} x1={rand(i) * 120} y1={rand(i + 50) * 120} x2={rand(i) * 120 + (rand(i + 5) - 0.5) * 60} y2={rand(i + 50) * 120 + (rand(i + 15) - 0.5) * 40} />
          ))}
        </g>
      );
    default:
      return (
        <g className="mg-fill">
          {Array.from({ length: 60 }, (_, i) => <circle key={i} cx={rand(i) * 120} cy={rand(i + 70) * 120} r={1 + rand(i + 3) * 1.6} />)}
        </g>
      );
  }
}

export default function MaterialGlyph({ family, size = 56, className = "", label }) {
  const kind = materialClass(family);
  return (
    <span className={`cs-glyph cs-glyph--${kind} ${className}`} style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120" role={label ? "img" : undefined} aria-label={label} aria-hidden={label ? undefined : "true"}>
        <Pattern kind={kind} />
      </svg>
    </span>
  );
}
