import React from "react";

export default function ParticleField({ count = 30, variant = "float", className = "" }) {
  return (
    <div className={`cs-particles cs-particles--${variant} ${className}`} aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <span
          key={i}
          style={{
            left: `${(i * 37 + 11) % 100}%`,
            top: variant === "snow" ? undefined : `${(i * 53 + 7) % 100}%`,
            "--size": `${2 + (i % 4) * 1.4}px`,
            "--delay": `${-((i * 1.7) % 14)}s`,
            "--dur": `${9 + (i % 6) * 2.2}s`,
            "--drift": `${((i % 5) - 2) * 14}px`,
          }}
        />
      ))}
    </div>
  );
}
