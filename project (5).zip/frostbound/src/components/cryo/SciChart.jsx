import React, { useMemo, useState } from "react";
import { ArrowDownToLine } from "lucide-react";

const W = 720;
const PAD = { l: 62, r: 22, t: 18, b: 48 };

function niceTicks(min, max, count = 5) {
  const span = max - min || 1;
  const rough = span / count;
  const mag = 10 ** Math.floor(Math.log10(rough));
  const norm = rough / mag;
  const step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * mag;
  const ticks = [];
  for (let v = Math.ceil(min / step) * step; v <= max + step * 1e-9; v += step) ticks.push(Number(v.toPrecision(12)));
  return ticks;
}

function buildPath(pts, smooth) {
  if (!pts.length) return "";
  if (!smooth || pts.length < 3) return pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(2)} ${p[1].toFixed(2)}`).join(" ");
  let d = `M${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    d += ` C${p1[0] + (p2[0] - p0[0]) / 6} ${p1[1] + (p2[1] - p0[1]) / 6} ${p2[0] - (p3[0] - p1[0]) / 6} ${p2[1] - (p3[1] - p1[1]) / 6} ${p2[0]} ${p2[1]}`;
  }
  return d;
}

const defaultFormat = (v) => Number(Number(v).toPrecision(4)).toLocaleString("en-US");

export default function SciChart({
  series,
  xLabel,
  yLabel,
  xUnit = "",
  yUnit = "",
  height = 260,
  smooth = false,
  marker,
  bands = [],
  xDomain,
  yDomain,
  ariaLabel,
  onExport,
  exportLabel = "Export CSV",
  caption,
  tone = "dark",
  formatX = defaultFormat,
  formatY = defaultFormat,
}) {
  const [hoverIndex, setHoverIndex] = useState(null);
  const primary = series[0]?.points ?? [];

  const { sx, sy, xTicks, yTicks } = useMemo(() => {
    const all = series.flatMap((s) => s.points);
    const xs = all.map((p) => p.x);
    const ys = all.map((p) => p.y);
    const [x0, x1] = xDomain ?? [Math.min(...xs), Math.max(...xs)];
    let [y0, y1] = yDomain ?? [Math.min(...ys), Math.max(...ys)];
    if (!yDomain) {
      const margin = (y1 - y0) * 0.1 || Math.abs(y0) * 0.05 || 1;
      y0 -= margin;
      y1 += margin;
    }
    return {
      sx: (v) => PAD.l + ((v - x0) / (x1 - x0 || 1)) * (W - PAD.l - PAD.r),
      sy: (v) => height - PAD.b - ((v - y0) / (y1 - y0 || 1)) * (height - PAD.t - PAD.b),
      xTicks: niceTicks(x0, x1, 6).filter((t) => t >= x0 && t <= x1),
      yTicks: niceTicks(y0, y1, 4).filter((t) => t >= y0 && t <= y1),
    };
  }, [series, xDomain, yDomain, height]);

  const handlePointer = (event) => {
    if (!primary.length) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const svgX = ((event.clientX - rect.left) / rect.width) * W;
    let best = 0;
    primary.forEach((p, i) => {
      if (Math.abs(sx(p.x) - svgX) < Math.abs(sx(primary[best].x) - svgX)) best = i;
    });
    setHoverIndex(best);
  };

  const handleKey = (event) => {
    if (!primary.length) return;
    if (event.key === "ArrowRight") setHoverIndex((i) => Math.min(primary.length - 1, (i ?? -1) + 1));
    else if (event.key === "ArrowLeft") setHoverIndex((i) => Math.max(0, (i ?? primary.length) - 1));
    else if (event.key === "Escape") setHoverIndex(null);
    else return;
    event.preventDefault();
  };

  const hoverX = hoverIndex != null ? primary[hoverIndex]?.x : null;

  return (
    <figure className={`cs-chart cs-chart--${tone}`}>
      <div className="cs-chart-top">
        <div className="cs-chart-legend">
          {series.map((s) => (
            <span key={s.id ?? s.name}>
              <i style={{ background: s.color }} className={s.dashed ? "dashed" : ""} />
              {s.name}
            </span>
          ))}
        </div>
        {onExport && (
          <button type="button" className="cs-chart-export" onClick={onExport}>
            {exportLabel} <ArrowDownToLine size={13} aria-hidden="true" />
          </button>
        )}
      </div>
      <div
        className="cs-chart-stage"
        tabIndex={0}
        role="group"
        aria-label={`${ariaLabel ?? yLabel}. Use left and right arrow keys to read values.`}
        onPointerMove={handlePointer}
        onPointerLeave={() => setHoverIndex(null)}
        onKeyDown={handleKey}
        onBlur={() => setHoverIndex(null)}
      >
        <svg viewBox={`0 0 ${W} ${height}`} role="img" aria-label={ariaLabel ?? `${yLabel} versus ${xLabel}`}>
          {bands.map((b) => (
            <g key={b.label}>
              <rect x={sx(b.x1)} y={PAD.t} width={Math.max(0, sx(b.x2) - sx(b.x1))} height={height - PAD.t - PAD.b} className="cs-chart-band" />
              <text x={(sx(b.x1) + sx(b.x2)) / 2} y={PAD.t + 13} textAnchor="middle" className="cs-chart-band-label">{b.label}</text>
            </g>
          ))}
          {yTicks.map((t) => (
            <g key={`y${t}`}>
              <line x1={PAD.l} x2={W - PAD.r} y1={sy(t)} y2={sy(t)} className="cs-chart-grid" />
              <text x={PAD.l - 9} y={sy(t) + 4} textAnchor="end" className="cs-chart-tick">{formatY(t)}</text>
            </g>
          ))}
          {xTicks.map((t) => (
            <g key={`x${t}`}>
              <line x1={sx(t)} x2={sx(t)} y1={PAD.t} y2={height - PAD.b} className="cs-chart-grid cs-chart-grid--v" />
              <text x={sx(t)} y={height - PAD.b + 17} textAnchor="middle" className="cs-chart-tick">{formatX(t)}</text>
            </g>
          ))}
          <line x1={PAD.l} x2={W - PAD.r} y1={height - PAD.b} y2={height - PAD.b} className="cs-chart-axis" />
          <line x1={PAD.l} x2={PAD.l} y1={PAD.t} y2={height - PAD.b} className="cs-chart-axis" />
          <text x={(PAD.l + W - PAD.r) / 2} y={height - 8} textAnchor="middle" className="cs-chart-label">
            {xLabel}{xUnit ? ` (${xUnit})` : ""}
          </text>
          <text transform={`translate(15 ${(PAD.t + height - PAD.b) / 2}) rotate(-90)`} textAnchor="middle" className="cs-chart-label">
            {yLabel}{yUnit ? ` (${yUnit})` : ""}
          </text>
          {series.map((s) => (
            <path
              key={s.id ?? s.name}
              d={buildPath(s.points.map((p) => [sx(p.x), sy(p.y)]), smooth)}
              className="cs-chart-line"
              style={{ stroke: s.color, strokeDasharray: s.dashed ? "6 5" : undefined }}
            />
          ))}
          {marker && Number.isFinite(marker.x) && (
            <g className="cs-chart-marker">
              <line x1={sx(marker.x)} x2={sx(marker.x)} y1={PAD.t} y2={height - PAD.b} />
              {Number.isFinite(marker.y) && <circle cx={sx(marker.x)} cy={sy(marker.y)} r="6" />}
              {marker.label && <text x={sx(marker.x) + 8} y={PAD.t + 28}>{marker.label}</text>}
            </g>
          )}
          {hoverX != null && (
            <g className="cs-chart-hover">
              <line x1={sx(hoverX)} x2={sx(hoverX)} y1={PAD.t} y2={height - PAD.b} />
              {series.map((s) => {
                const p = s.points.reduce((a, b) => (Math.abs(b.x - hoverX) < Math.abs(a.x - hoverX) ? b : a), s.points[0]);
                return p ? <circle key={s.id ?? s.name} cx={sx(p.x)} cy={sy(p.y)} r="4.5" style={{ fill: s.color }} /> : null;
              })}
            </g>
          )}
        </svg>
        {hoverX != null && (
          <div className="cs-chart-tooltip" role="status" style={{ left: `${(sx(hoverX) / W) * 100}%` }}>
            <b>{formatX(hoverX)}{xUnit ? ` ${xUnit}` : ""}</b>
            {series.map((s) => {
              const p = s.points.reduce((a, b) => (Math.abs(b.x - hoverX) < Math.abs(a.x - hoverX) ? b : a), s.points[0]);
              return (
                <span key={s.id ?? s.name}>
                  <i style={{ background: s.color }} />
                  {s.name}: <strong>{formatY(p.y)}</strong> {yUnit}
                </span>
              );
            })}
          </div>
        )}
      </div>
      {caption && <figcaption>{caption}</figcaption>}
    </figure>
  );
}
