import React from "react";

const ARMS = [0, 60, 120, 180, 240, 300];

export default function SnowflakeAtom({ className = "" }) {
  return (
    <svg className={`cs-morph ${className}`} viewBox="-60 -60 120 120" role="img" aria-label="Animated illustration: a six-armed snowflake transforms into an atom with a nucleus and electron orbitals">
      <g className="cs-morph-flake" stroke="#bff3fb" strokeWidth="2" strokeLinecap="round" fill="none">
        {ARMS.map((a) => (
          <g key={a} transform={`rotate(${a})`}>
            <line x1="0" y1="-6" x2="0" y2="-46" />
            <line x1="0" y1="-24" x2="9" y2="-30" />
            <line x1="0" y1="-24" x2="-9" y2="-30" />
            <line x1="0" y1="-36" x2="6" y2="-40" />
            <line x1="0" y1="-36" x2="-6" y2="-40" />
          </g>
        ))}
      </g>
      <g className="cs-morph-atom" fill="none">
        <ellipse rx="46" ry="15" stroke="#7fe3f2" strokeWidth="1.4" />
        <ellipse rx="46" ry="15" stroke="#a796f2" strokeWidth="1.4" transform="rotate(60)" />
        <ellipse rx="46" ry="15" stroke="#3fd2c0" strokeWidth="1.4" transform="rotate(120)" />
        <g className="cs-morph-electrons">
          <circle cx="46" cy="0" r="3.2" fill="#e9fbff" />
          <circle cx="-23" cy="39.8" r="3.2" fill="#e9fbff" />
          <circle cx="-23" cy="-39.8" r="3.2" fill="#e9fbff" />
        </g>
      </g>
      <circle className="cs-morph-core" r="7" fill="#7fe3f2" />
      <circle r="3" fill="#ffffff" />
    </svg>
  );
}
