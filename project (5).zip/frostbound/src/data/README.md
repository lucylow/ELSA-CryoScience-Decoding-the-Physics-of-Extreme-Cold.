# Mock data catalog

The files in this directory are deliberately fictional and illustrative. They provide enough sample content to prototype filtering, collections, room discovery, and interactive UI states.

- `mockData.js`: primary room, character, location, spell, quest, gallery, and dashboard data.
- `catalog/`: expanded sample catalogs for visual design exploration.
- `mockApi.js`: asynchronous mock service layer.
- `questEngine.js`, `collectionEngine.js`: small pure functions for state transitions.
- Additional files contain blueprints, motifs, weather snapshots, prompts, relationships, and glossary entries.

Do not use the mock material values as engineering design inputs.
