export const achievements=[
{id:"first-step",title:"First Footprints",description:"Open the palace for the first time.",icon:"❄"},
{id:"room-seeker",title:"Room Seeker",description:"Explore five palace rooms.",icon:"⌂"},
{id:"spell-student",title:"Spell Student",description:"Practice three different spells.",icon:"✧"},
{id:"story-keeper",title:"Story Keeper",description:"Read the story timeline.",icon:"▤"},
{id:"world-walker",title:"World Walker",description:"Visit every location in the atlas.",icon:"♧"},
{id:"designer",title:"Crystal Designer",description:"Save a palace studio concept.",icon:"♢"}
];
