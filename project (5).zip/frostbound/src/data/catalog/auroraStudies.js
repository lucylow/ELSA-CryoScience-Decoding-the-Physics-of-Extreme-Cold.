export const auroraStudies = [
  {
    "id": "auroraStudies-01",
    "name": "Polar ribbon",
    "group": "Aurora Studies",
    "index": 1,
    "rarity": "Common",
    "description": "Polar ribbon — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "ice"
    ]
  },
  {
    "id": "auroraStudies-02",
    "name": "Emerald arc",
    "group": "Aurora Studies",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Emerald arc — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "snow"
    ]
  },
  {
    "id": "auroraStudies-03",
    "name": "Violet curtain",
    "group": "Aurora Studies",
    "index": 3,
    "rarity": "Rare",
    "description": "Violet curtain — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "light"
    ]
  },
  {
    "id": "auroraStudies-04",
    "name": "Blue corona",
    "group": "Aurora Studies",
    "index": 4,
    "rarity": "Special",
    "description": "Blue corona — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "story"
    ]
  },
  {
    "id": "auroraStudies-05",
    "name": "Dawn shimmer",
    "group": "Aurora Studies",
    "index": 5,
    "rarity": "Common",
    "description": "Dawn shimmer — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "ice"
    ]
  },
  {
    "id": "auroraStudies-06",
    "name": "Quiet halo",
    "group": "Aurora Studies",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Quiet halo — an illustrative entry in the Frostbound aurora studies collection.",
    "tags": [
      "aurora",
      "snow"
    ]
  }
];
