export const bridgeConcepts = [
  {
    "id": "bridgeConcepts-01",
    "name": "Ribbon span",
    "group": "Bridge Concepts",
    "index": 1,
    "rarity": "Common",
    "description": "Ribbon span — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "ice"
    ]
  },
  {
    "id": "bridgeConcepts-02",
    "name": "Crystal truss",
    "group": "Bridge Concepts",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Crystal truss — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "snow"
    ]
  },
  {
    "id": "bridgeConcepts-03",
    "name": "Snow arch",
    "group": "Bridge Concepts",
    "index": 3,
    "rarity": "Rare",
    "description": "Snow arch — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "light"
    ]
  },
  {
    "id": "bridgeConcepts-04",
    "name": "Layered ice deck",
    "group": "Bridge Concepts",
    "index": 4,
    "rarity": "Special",
    "description": "Layered ice deck — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "story"
    ]
  },
  {
    "id": "bridgeConcepts-05",
    "name": "Suspended prism",
    "group": "Bridge Concepts",
    "index": 5,
    "rarity": "Common",
    "description": "Suspended prism — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "ice"
    ]
  },
  {
    "id": "bridgeConcepts-06",
    "name": "Glacier curve",
    "group": "Bridge Concepts",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Glacier curve — an illustrative entry in the Frostbound bridge concepts collection.",
    "tags": [
      "bridge",
      "snow"
    ]
  }
];
