export const climateZones = [
  {
    "id": "climateZones-01",
    "name": "Spire summit",
    "group": "Palace Climate Zones",
    "index": 1,
    "rarity": "Common",
    "description": "Spire summit — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "ice"
    ]
  },
  {
    "id": "climateZones-02",
    "name": "Windward terrace",
    "group": "Palace Climate Zones",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Windward terrace — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "snow"
    ]
  },
  {
    "id": "climateZones-03",
    "name": "Sheltered court",
    "group": "Palace Climate Zones",
    "index": 3,
    "rarity": "Rare",
    "description": "Sheltered court — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "light"
    ]
  },
  {
    "id": "climateZones-04",
    "name": "Throne chamber",
    "group": "Palace Climate Zones",
    "index": 4,
    "rarity": "Special",
    "description": "Throne chamber — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "story"
    ]
  },
  {
    "id": "climateZones-05",
    "name": "Library alcove",
    "group": "Palace Climate Zones",
    "index": 5,
    "rarity": "Common",
    "description": "Library alcove — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "ice"
    ]
  },
  {
    "id": "climateZones-06",
    "name": "Fjord-facing balcony",
    "group": "Palace Climate Zones",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Fjord-facing balcony — an illustrative entry in the Frostbound palace climate zones collection.",
    "tags": [
      "palace",
      "snow"
    ]
  }
];
