export const constellations = [
  {
    "id": "constellations-01",
    "name": "North star",
    "group": "Winter Constellations",
    "index": 1,
    "rarity": "Common",
    "description": "North star — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "constellations-02",
    "name": "Winter crown",
    "group": "Winter Constellations",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Winter crown — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "snow"
    ]
  },
  {
    "id": "constellations-03",
    "name": "Frost constellation",
    "group": "Winter Constellations",
    "index": 3,
    "rarity": "Rare",
    "description": "Frost constellation — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "light"
    ]
  },
  {
    "id": "constellations-04",
    "name": "Aurora path",
    "group": "Winter Constellations",
    "index": 4,
    "rarity": "Special",
    "description": "Aurora path — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "story"
    ]
  },
  {
    "id": "constellations-05",
    "name": "Snow hare",
    "group": "Winter Constellations",
    "index": 5,
    "rarity": "Common",
    "description": "Snow hare — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "constellations-06",
    "name": "Crystal arc",
    "group": "Winter Constellations",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Crystal arc — an illustrative entry in the Frostbound winter constellations collection.",
    "tags": [
      "winter",
      "snow"
    ]
  }
];
