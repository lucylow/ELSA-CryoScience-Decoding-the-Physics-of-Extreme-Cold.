export const designMotifs = [
  {
    "id": "designMotifs-01",
    "name": "Six-fold symmetry",
    "group": "Design Motifs",
    "index": 1,
    "rarity": "Common",
    "description": "Six-fold symmetry — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "ice"
    ]
  },
  {
    "id": "designMotifs-02",
    "name": "Branching dendrite",
    "group": "Design Motifs",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Branching dendrite — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "snow"
    ]
  },
  {
    "id": "designMotifs-03",
    "name": "Radial crystal",
    "group": "Design Motifs",
    "index": 3,
    "rarity": "Rare",
    "description": "Radial crystal — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "light"
    ]
  },
  {
    "id": "designMotifs-04",
    "name": "Ribbon curve",
    "group": "Design Motifs",
    "index": 4,
    "rarity": "Special",
    "description": "Ribbon curve — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "story"
    ]
  },
  {
    "id": "designMotifs-05",
    "name": "Layered facet",
    "group": "Design Motifs",
    "index": 5,
    "rarity": "Common",
    "description": "Layered facet — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "ice"
    ]
  },
  {
    "id": "designMotifs-06",
    "name": "Glacial striation",
    "group": "Design Motifs",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Glacial striation — an illustrative entry in the Frostbound design motifs collection.",
    "tags": [
      "design",
      "snow"
    ]
  }
];
