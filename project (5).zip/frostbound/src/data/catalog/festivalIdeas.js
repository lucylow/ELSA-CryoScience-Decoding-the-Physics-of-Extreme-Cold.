export const festivalIdeas = [
  {
    "id": "festivalIdeas-01",
    "name": "Lantern walk",
    "group": "Winter Festival Ideas",
    "index": 1,
    "rarity": "Common",
    "description": "Lantern walk — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "festivalIdeas-02",
    "name": "Snow sculpture day",
    "group": "Winter Festival Ideas",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Snow sculpture day — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "snow"
    ]
  },
  {
    "id": "festivalIdeas-03",
    "name": "Aurora gathering",
    "group": "Winter Festival Ideas",
    "index": 3,
    "rarity": "Rare",
    "description": "Aurora gathering — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "light"
    ]
  },
  {
    "id": "festivalIdeas-04",
    "name": "Ice music evening",
    "group": "Winter Festival Ideas",
    "index": 4,
    "rarity": "Special",
    "description": "Ice music evening — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "story"
    ]
  },
  {
    "id": "festivalIdeas-05",
    "name": "Crystal garden tour",
    "group": "Winter Festival Ideas",
    "index": 5,
    "rarity": "Common",
    "description": "Crystal garden tour — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "festivalIdeas-06",
    "name": "Winter story circle",
    "group": "Winter Festival Ideas",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Winter story circle — an illustrative entry in the Frostbound winter festival ideas collection.",
    "tags": [
      "winter",
      "snow"
    ]
  }
];
