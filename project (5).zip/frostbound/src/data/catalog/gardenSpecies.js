export const gardenSpecies = [
  {
    "id": "gardenSpecies-01",
    "name": "Frost rose",
    "group": "Garden Species",
    "index": 1,
    "rarity": "Common",
    "description": "Frost rose — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "ice"
    ]
  },
  {
    "id": "gardenSpecies-02",
    "name": "Snow lily",
    "group": "Garden Species",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Snow lily — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "snow"
    ]
  },
  {
    "id": "gardenSpecies-03",
    "name": "Ice fern",
    "group": "Garden Species",
    "index": 3,
    "rarity": "Rare",
    "description": "Ice fern — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "light"
    ]
  },
  {
    "id": "gardenSpecies-04",
    "name": "Winter bell",
    "group": "Garden Species",
    "index": 4,
    "rarity": "Special",
    "description": "Winter bell — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "story"
    ]
  },
  {
    "id": "gardenSpecies-05",
    "name": "Crystal vine",
    "group": "Garden Species",
    "index": 5,
    "rarity": "Common",
    "description": "Crystal vine — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "ice"
    ]
  },
  {
    "id": "gardenSpecies-06",
    "name": "Moon orchid",
    "group": "Garden Species",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Moon orchid — an illustrative entry in the Frostbound garden species collection.",
    "tags": [
      "garden",
      "snow"
    ]
  }
];
