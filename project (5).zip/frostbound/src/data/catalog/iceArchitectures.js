export const iceArchitectures = [
  {
    "id": "iceArchitectures-01",
    "name": "Needle spire",
    "group": "Ice Architecture Studies",
    "index": 1,
    "rarity": "Common",
    "description": "Needle spire — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "iceArchitectures-02",
    "name": "Faceted arch",
    "group": "Ice Architecture Studies",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Faceted arch — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "snow"
    ]
  },
  {
    "id": "iceArchitectures-03",
    "name": "Ribbon stair",
    "group": "Ice Architecture Studies",
    "index": 3,
    "rarity": "Rare",
    "description": "Ribbon stair — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "light"
    ]
  },
  {
    "id": "iceArchitectures-04",
    "name": "Crystal vault",
    "group": "Ice Architecture Studies",
    "index": 4,
    "rarity": "Special",
    "description": "Crystal vault — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "story"
    ]
  },
  {
    "id": "iceArchitectures-05",
    "name": "Frost lattice",
    "group": "Ice Architecture Studies",
    "index": 5,
    "rarity": "Common",
    "description": "Frost lattice — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "iceArchitectures-06",
    "name": "Glacier buttress",
    "group": "Ice Architecture Studies",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Glacier buttress — an illustrative entry in the Frostbound ice architecture studies collection.",
    "tags": [
      "ice",
      "snow"
    ]
  }
];
