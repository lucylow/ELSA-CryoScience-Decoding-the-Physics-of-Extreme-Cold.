export const iceSculptures = [
  {
    "id": "iceSculptures-01",
    "name": "Crystal swan",
    "group": "Ice Sculptures",
    "index": 1,
    "rarity": "Common",
    "description": "Crystal swan — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "iceSculptures-02",
    "name": "Snowflake tree",
    "group": "Ice Sculptures",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Snowflake tree — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "snow"
    ]
  },
  {
    "id": "iceSculptures-03",
    "name": "Frozen fountain",
    "group": "Ice Sculptures",
    "index": 3,
    "rarity": "Rare",
    "description": "Frozen fountain — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "light"
    ]
  },
  {
    "id": "iceSculptures-04",
    "name": "Ice lantern",
    "group": "Ice Sculptures",
    "index": 4,
    "rarity": "Special",
    "description": "Ice lantern — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "story"
    ]
  },
  {
    "id": "iceSculptures-05",
    "name": "Spiral shell",
    "group": "Ice Sculptures",
    "index": 5,
    "rarity": "Common",
    "description": "Spiral shell — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "iceSculptures-06",
    "name": "Frost arch",
    "group": "Ice Sculptures",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Frost arch — an illustrative entry in the Frostbound ice sculptures collection.",
    "tags": [
      "ice",
      "snow"
    ]
  }
];
