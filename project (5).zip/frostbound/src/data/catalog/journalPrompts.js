export const journalPrompts = [
  {
    "id": "journalPrompts-01",
    "name": "What does the palace sound like?",
    "group": "Journal Prompts",
    "index": 1,
    "rarity": "Common",
    "description": "What does the palace sound like? — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "ice"
    ]
  },
  {
    "id": "journalPrompts-02",
    "name": "Which room feels most peaceful?",
    "group": "Journal Prompts",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Which room feels most peaceful? — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "snow"
    ]
  },
  {
    "id": "journalPrompts-03",
    "name": "Design a new snowflake.",
    "group": "Journal Prompts",
    "index": 3,
    "rarity": "Rare",
    "description": "Design a new snowflake. — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "light"
    ]
  },
  {
    "id": "journalPrompts-04",
    "name": "Describe the aurora.",
    "group": "Journal Prompts",
    "index": 4,
    "rarity": "Special",
    "description": "Describe the aurora. — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "story"
    ]
  },
  {
    "id": "journalPrompts-05",
    "name": "What would you keep in the library?",
    "group": "Journal Prompts",
    "index": 5,
    "rarity": "Common",
    "description": "What would you keep in the library? — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "ice"
    ]
  },
  {
    "id": "journalPrompts-06",
    "name": "Sketch a new spire.",
    "group": "Journal Prompts",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Sketch a new spire. — an illustrative entry in the Frostbound journal prompts collection.",
    "tags": [
      "journal",
      "snow"
    ]
  }
];
