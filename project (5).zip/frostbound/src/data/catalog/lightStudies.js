export const lightStudies = [
  {
    "id": "lightStudies-01",
    "name": "Refraction",
    "group": "Light Studies",
    "index": 1,
    "rarity": "Common",
    "description": "Refraction — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "ice"
    ]
  },
  {
    "id": "lightStudies-02",
    "name": "Caustic shimmer",
    "group": "Light Studies",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Caustic shimmer — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "snow"
    ]
  },
  {
    "id": "lightStudies-03",
    "name": "Blue shadow",
    "group": "Light Studies",
    "index": 3,
    "rarity": "Rare",
    "description": "Blue shadow — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "light"
    ]
  },
  {
    "id": "lightStudies-04",
    "name": "Prism scatter",
    "group": "Light Studies",
    "index": 4,
    "rarity": "Special",
    "description": "Prism scatter — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "story"
    ]
  },
  {
    "id": "lightStudies-05",
    "name": "Moon glow",
    "group": "Light Studies",
    "index": 5,
    "rarity": "Common",
    "description": "Moon glow — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "ice"
    ]
  },
  {
    "id": "lightStudies-06",
    "name": "Aurora wash",
    "group": "Light Studies",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Aurora wash — an illustrative entry in the Frostbound light studies collection.",
    "tags": [
      "light",
      "snow"
    ]
  }
];
