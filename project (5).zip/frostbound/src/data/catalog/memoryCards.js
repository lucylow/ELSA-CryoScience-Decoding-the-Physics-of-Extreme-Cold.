export const memoryCards = [
  {
    "id": "memoryCards-01",
    "name": "Family warmth",
    "group": "Memory Cards",
    "index": 1,
    "rarity": "Common",
    "description": "Family warmth — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "ice"
    ]
  },
  {
    "id": "memoryCards-02",
    "name": "First snow",
    "group": "Memory Cards",
    "index": 2,
    "rarity": "Uncommon",
    "description": "First snow — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "snow"
    ]
  },
  {
    "id": "memoryCards-03",
    "name": "Mountain courage",
    "group": "Memory Cards",
    "index": 3,
    "rarity": "Rare",
    "description": "Mountain courage — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "light"
    ]
  },
  {
    "id": "memoryCards-04",
    "name": "Quiet promise",
    "group": "Memory Cards",
    "index": 4,
    "rarity": "Special",
    "description": "Quiet promise — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "story"
    ]
  },
  {
    "id": "memoryCards-05",
    "name": "New beginning",
    "group": "Memory Cards",
    "index": 5,
    "rarity": "Common",
    "description": "New beginning — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "ice"
    ]
  },
  {
    "id": "memoryCards-06",
    "name": "Shared laughter",
    "group": "Memory Cards",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Shared laughter — an illustrative entry in the Frostbound memory cards collection.",
    "tags": [
      "memory",
      "snow"
    ]
  }
];
