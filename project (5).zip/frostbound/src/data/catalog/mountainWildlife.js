export const mountainWildlife = [
  {
    "id": "mountainWildlife-01",
    "name": "Arctic hare",
    "group": "Mountain Wildlife",
    "index": 1,
    "rarity": "Common",
    "description": "Arctic hare — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "ice"
    ]
  },
  {
    "id": "mountainWildlife-02",
    "name": "Snowy owl",
    "group": "Mountain Wildlife",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Snowy owl — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "snow"
    ]
  },
  {
    "id": "mountainWildlife-03",
    "name": "Mountain fox",
    "group": "Mountain Wildlife",
    "index": 3,
    "rarity": "Rare",
    "description": "Mountain fox — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "light"
    ]
  },
  {
    "id": "mountainWildlife-04",
    "name": "Reindeer",
    "group": "Mountain Wildlife",
    "index": 4,
    "rarity": "Special",
    "description": "Reindeer — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "story"
    ]
  },
  {
    "id": "mountainWildlife-05",
    "name": "Ptarmigan",
    "group": "Mountain Wildlife",
    "index": 5,
    "rarity": "Common",
    "description": "Ptarmigan — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "ice"
    ]
  },
  {
    "id": "mountainWildlife-06",
    "name": "Arctic tern",
    "group": "Mountain Wildlife",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Arctic tern — an illustrative entry in the Frostbound mountain wildlife collection.",
    "tags": [
      "mountain",
      "snow"
    ]
  }
];
