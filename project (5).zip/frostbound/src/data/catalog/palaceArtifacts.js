export const palaceArtifacts = [
  {
    "id": "palaceArtifacts-01",
    "name": "Snowflake pendant",
    "group": "Palace Artifacts",
    "index": 1,
    "rarity": "Common",
    "description": "Snowflake pendant — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "ice"
    ]
  },
  {
    "id": "palaceArtifacts-02",
    "name": "Crystal compass",
    "group": "Palace Artifacts",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Crystal compass — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "snow"
    ]
  },
  {
    "id": "palaceArtifacts-03",
    "name": "Ice harp",
    "group": "Palace Artifacts",
    "index": 3,
    "rarity": "Rare",
    "description": "Ice harp — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "light"
    ]
  },
  {
    "id": "palaceArtifacts-04",
    "name": "Winter lantern",
    "group": "Palace Artifacts",
    "index": 4,
    "rarity": "Special",
    "description": "Winter lantern — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "story"
    ]
  },
  {
    "id": "palaceArtifacts-05",
    "name": "Memory prism",
    "group": "Palace Artifacts",
    "index": 5,
    "rarity": "Common",
    "description": "Memory prism — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "ice"
    ]
  },
  {
    "id": "palaceArtifacts-06",
    "name": "Frosted journal",
    "group": "Palace Artifacts",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Frosted journal — an illustrative entry in the Frostbound palace artifacts collection.",
    "tags": [
      "palace",
      "snow"
    ]
  }
];
