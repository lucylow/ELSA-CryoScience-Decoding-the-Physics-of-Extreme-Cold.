export const paletteLibrary = [
  {
    "id": "paletteLibrary-01",
    "name": "Glacier blue",
    "group": "Ice Palettes",
    "index": 1,
    "rarity": "Common",
    "description": "Glacier blue — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "paletteLibrary-02",
    "name": "Moonlit silver",
    "group": "Ice Palettes",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Moonlit silver — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "snow"
    ]
  },
  {
    "id": "paletteLibrary-03",
    "name": "Aurora violet",
    "group": "Ice Palettes",
    "index": 3,
    "rarity": "Rare",
    "description": "Aurora violet — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "light"
    ]
  },
  {
    "id": "paletteLibrary-04",
    "name": "Frost mint",
    "group": "Ice Palettes",
    "index": 4,
    "rarity": "Special",
    "description": "Frost mint — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "story"
    ]
  },
  {
    "id": "paletteLibrary-05",
    "name": "Snow white",
    "group": "Ice Palettes",
    "index": 5,
    "rarity": "Common",
    "description": "Snow white — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "ice"
    ]
  },
  {
    "id": "paletteLibrary-06",
    "name": "Deep fjord",
    "group": "Ice Palettes",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Deep fjord — an illustrative entry in the Frostbound ice palettes collection.",
    "tags": [
      "ice",
      "snow"
    ]
  }
];
