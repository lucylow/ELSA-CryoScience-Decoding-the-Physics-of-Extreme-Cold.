export const questRewards = [
  {
    "id": "questRewards-01",
    "name": "Aurora badge",
    "group": "Quest Rewards",
    "index": 1,
    "rarity": "Common",
    "description": "Aurora badge — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "ice"
    ]
  },
  {
    "id": "questRewards-02",
    "name": "Crystal key",
    "group": "Quest Rewards",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Crystal key — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "snow"
    ]
  },
  {
    "id": "questRewards-03",
    "name": "Snowflake stamp",
    "group": "Quest Rewards",
    "index": 3,
    "rarity": "Rare",
    "description": "Snowflake stamp — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "light"
    ]
  },
  {
    "id": "questRewards-04",
    "name": "Explorer pin",
    "group": "Quest Rewards",
    "index": 4,
    "rarity": "Special",
    "description": "Explorer pin — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "story"
    ]
  },
  {
    "id": "questRewards-05",
    "name": "Winter journal",
    "group": "Quest Rewards",
    "index": 5,
    "rarity": "Common",
    "description": "Winter journal — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "ice"
    ]
  },
  {
    "id": "questRewards-06",
    "name": "Spire sketch",
    "group": "Quest Rewards",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Spire sketch — an illustrative entry in the Frostbound quest rewards collection.",
    "tags": [
      "quest",
      "snow"
    ]
  }
];
