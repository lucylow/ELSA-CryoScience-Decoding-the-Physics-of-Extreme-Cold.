export const roomTextures = [
  {
    "id": "roomTextures-01",
    "name": "Clear ice",
    "group": "Room Textures",
    "index": 1,
    "rarity": "Common",
    "description": "Clear ice — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "ice"
    ]
  },
  {
    "id": "roomTextures-02",
    "name": "Blue ice",
    "group": "Room Textures",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Blue ice — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "snow"
    ]
  },
  {
    "id": "roomTextures-03",
    "name": "Frosted glass",
    "group": "Room Textures",
    "index": 3,
    "rarity": "Rare",
    "description": "Frosted glass — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "light"
    ]
  },
  {
    "id": "roomTextures-04",
    "name": "Snow plaster",
    "group": "Room Textures",
    "index": 4,
    "rarity": "Special",
    "description": "Snow plaster — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "story"
    ]
  },
  {
    "id": "roomTextures-05",
    "name": "Crystal facets",
    "group": "Room Textures",
    "index": 5,
    "rarity": "Common",
    "description": "Crystal facets — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "ice"
    ]
  },
  {
    "id": "roomTextures-06",
    "name": "Rime lace",
    "group": "Room Textures",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Rime lace — an illustrative entry in the Frostbound room textures collection.",
    "tags": [
      "room",
      "snow"
    ]
  }
];
