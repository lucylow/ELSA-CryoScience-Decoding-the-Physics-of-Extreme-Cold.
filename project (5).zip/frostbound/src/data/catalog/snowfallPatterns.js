export const snowfallPatterns = [
  {
    "id": "snowfallPatterns-01",
    "name": "Powder veil",
    "group": "Snowfall Patterns",
    "index": 1,
    "rarity": "Common",
    "description": "Powder veil — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "ice"
    ]
  },
  {
    "id": "snowfallPatterns-02",
    "name": "Wind-carved drift",
    "group": "Snowfall Patterns",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Wind-carved drift — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "snow"
    ]
  },
  {
    "id": "snowfallPatterns-03",
    "name": "Rime curtain",
    "group": "Snowfall Patterns",
    "index": 3,
    "rarity": "Rare",
    "description": "Rime curtain — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "light"
    ]
  },
  {
    "id": "snowfallPatterns-04",
    "name": "Soft flurry",
    "group": "Snowfall Patterns",
    "index": 4,
    "rarity": "Special",
    "description": "Soft flurry — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "story"
    ]
  },
  {
    "id": "snowfallPatterns-05",
    "name": "Glitter fall",
    "group": "Snowfall Patterns",
    "index": 5,
    "rarity": "Common",
    "description": "Glitter fall — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "ice"
    ]
  },
  {
    "id": "snowfallPatterns-06",
    "name": "Mountain squall",
    "group": "Snowfall Patterns",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Mountain squall — an illustrative entry in the Frostbound snowfall patterns collection.",
    "tags": [
      "snowfall",
      "snow"
    ]
  }
];
