export const soundscapes = [
  {
    "id": "soundscapes-01",
    "name": "Icicle chime",
    "group": "Winter Soundscapes",
    "index": 1,
    "rarity": "Common",
    "description": "Icicle chime — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "soundscapes-02",
    "name": "Snow hush",
    "group": "Winter Soundscapes",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Snow hush — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "snow"
    ]
  },
  {
    "id": "soundscapes-03",
    "name": "Wind flute",
    "group": "Winter Soundscapes",
    "index": 3,
    "rarity": "Rare",
    "description": "Wind flute — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "light"
    ]
  },
  {
    "id": "soundscapes-04",
    "name": "Frozen echo",
    "group": "Winter Soundscapes",
    "index": 4,
    "rarity": "Special",
    "description": "Frozen echo — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "story"
    ]
  },
  {
    "id": "soundscapes-05",
    "name": "Fjord call",
    "group": "Winter Soundscapes",
    "index": 5,
    "rarity": "Common",
    "description": "Fjord call — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "soundscapes-06",
    "name": "Soft crackle",
    "group": "Winter Soundscapes",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Soft crackle — an illustrative entry in the Frostbound winter soundscapes collection.",
    "tags": [
      "winter",
      "snow"
    ]
  }
];
