export const storyMoments = [
  {
    "id": "storyMoments-01",
    "name": "A quiet secret",
    "group": "Story Moments",
    "index": 1,
    "rarity": "Common",
    "description": "A quiet secret — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "ice"
    ]
  },
  {
    "id": "storyMoments-02",
    "name": "A brave choice",
    "group": "Story Moments",
    "index": 2,
    "rarity": "Uncommon",
    "description": "A brave choice — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "snow"
    ]
  },
  {
    "id": "storyMoments-03",
    "name": "A new connection",
    "group": "Story Moments",
    "index": 3,
    "rarity": "Rare",
    "description": "A new connection — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "light"
    ]
  },
  {
    "id": "storyMoments-04",
    "name": "A winter journey",
    "group": "Story Moments",
    "index": 4,
    "rarity": "Special",
    "description": "A winter journey — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "story"
    ]
  },
  {
    "id": "storyMoments-05",
    "name": "A discovery",
    "group": "Story Moments",
    "index": 5,
    "rarity": "Common",
    "description": "A discovery — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "ice"
    ]
  },
  {
    "id": "storyMoments-06",
    "name": "A promise",
    "group": "Story Moments",
    "index": 6,
    "rarity": "Uncommon",
    "description": "A promise — an illustrative entry in the Frostbound story moments collection.",
    "tags": [
      "story",
      "snow"
    ]
  }
];
