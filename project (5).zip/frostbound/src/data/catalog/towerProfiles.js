export const towerProfiles = [
  {
    "id": "towerProfiles-01",
    "name": "Needle tower",
    "group": "Tower Profiles",
    "index": 1,
    "rarity": "Common",
    "description": "Needle tower — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "ice"
    ]
  },
  {
    "id": "towerProfiles-02",
    "name": "Crown spire",
    "group": "Tower Profiles",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Crown spire — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "snow"
    ]
  },
  {
    "id": "towerProfiles-03",
    "name": "Twin turret",
    "group": "Tower Profiles",
    "index": 3,
    "rarity": "Rare",
    "description": "Twin turret — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "light"
    ]
  },
  {
    "id": "towerProfiles-04",
    "name": "Open lantern",
    "group": "Tower Profiles",
    "index": 4,
    "rarity": "Special",
    "description": "Open lantern — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "story"
    ]
  },
  {
    "id": "towerProfiles-05",
    "name": "Crystal pinnacle",
    "group": "Tower Profiles",
    "index": 5,
    "rarity": "Common",
    "description": "Crystal pinnacle — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "ice"
    ]
  },
  {
    "id": "towerProfiles-06",
    "name": "Ribbon crown",
    "group": "Tower Profiles",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Ribbon crown — an illustrative entry in the Frostbound tower profiles collection.",
    "tags": [
      "tower",
      "snow"
    ]
  }
];
