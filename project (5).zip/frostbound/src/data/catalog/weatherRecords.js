export const weatherRecords = [
  {
    "id": "weatherRecords-01",
    "name": "Quiet snowfall",
    "group": "Weather Records",
    "index": 1,
    "rarity": "Common",
    "description": "Quiet snowfall — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "ice"
    ]
  },
  {
    "id": "weatherRecords-02",
    "name": "Blue hour",
    "group": "Weather Records",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Blue hour — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "snow"
    ]
  },
  {
    "id": "weatherRecords-03",
    "name": "Clear frost",
    "group": "Weather Records",
    "index": 3,
    "rarity": "Rare",
    "description": "Clear frost — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "light"
    ]
  },
  {
    "id": "weatherRecords-04",
    "name": "Wind gust",
    "group": "Weather Records",
    "index": 4,
    "rarity": "Special",
    "description": "Wind gust — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "story"
    ]
  },
  {
    "id": "weatherRecords-05",
    "name": "Aurora night",
    "group": "Weather Records",
    "index": 5,
    "rarity": "Common",
    "description": "Aurora night — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "ice"
    ]
  },
  {
    "id": "weatherRecords-06",
    "name": "Soft thaw",
    "group": "Weather Records",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Soft thaw — an illustrative entry in the Frostbound weather records collection.",
    "tags": [
      "weather",
      "snow"
    ]
  }
];
