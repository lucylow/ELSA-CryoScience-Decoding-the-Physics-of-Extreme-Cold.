export const windowStudies = [
  {
    "id": "windowStudies-01",
    "name": "Lancet window",
    "group": "Window Studies",
    "index": 1,
    "rarity": "Common",
    "description": "Lancet window — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "ice"
    ]
  },
  {
    "id": "windowStudies-02",
    "name": "Ice rose",
    "group": "Window Studies",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Ice rose — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "snow"
    ]
  },
  {
    "id": "windowStudies-03",
    "name": "Star aperture",
    "group": "Window Studies",
    "index": 3,
    "rarity": "Rare",
    "description": "Star aperture — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "light"
    ]
  },
  {
    "id": "windowStudies-04",
    "name": "Tall arch",
    "group": "Window Studies",
    "index": 4,
    "rarity": "Special",
    "description": "Tall arch — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "story"
    ]
  },
  {
    "id": "windowStudies-05",
    "name": "Prism bay",
    "group": "Window Studies",
    "index": 5,
    "rarity": "Common",
    "description": "Prism bay — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "ice"
    ]
  },
  {
    "id": "windowStudies-06",
    "name": "Snowflake oculus",
    "group": "Window Studies",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Snowflake oculus — an illustrative entry in the Frostbound window studies collection.",
    "tags": [
      "window",
      "snow"
    ]
  }
];
