export const winterFlora = [
  {
    "id": "winterFlora-01",
    "name": "Snow lily",
    "group": "Winter Flora",
    "index": 1,
    "rarity": "Common",
    "description": "Snow lily — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "winterFlora-02",
    "name": "Frost rose",
    "group": "Winter Flora",
    "index": 2,
    "rarity": "Uncommon",
    "description": "Frost rose — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "snow"
    ]
  },
  {
    "id": "winterFlora-03",
    "name": "Ice fern",
    "group": "Winter Flora",
    "index": 3,
    "rarity": "Rare",
    "description": "Ice fern — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "light"
    ]
  },
  {
    "id": "winterFlora-04",
    "name": "Crystal willow",
    "group": "Winter Flora",
    "index": 4,
    "rarity": "Special",
    "description": "Crystal willow — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "story"
    ]
  },
  {
    "id": "winterFlora-05",
    "name": "Moon moss",
    "group": "Winter Flora",
    "index": 5,
    "rarity": "Common",
    "description": "Moon moss — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "ice"
    ]
  },
  {
    "id": "winterFlora-06",
    "name": "Glacier bell",
    "group": "Winter Flora",
    "index": 6,
    "rarity": "Uncommon",
    "description": "Glacier bell — an illustrative entry in the Frostbound winter flora collection.",
    "tags": [
      "winter",
      "snow"
    ]
  }
];
