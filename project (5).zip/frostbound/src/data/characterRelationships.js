export const relationships=[
{from:"Elsa",to:"Anna",kind:"Sisters",note:"A deep family bond shaped by care and trust."},
{from:"Elsa",to:"Olaf",kind:"Friends",note:"A joyful snow friend connected to Elsa's magic."},
{from:"Anna",to:"Kristoff",kind:"Partners",note:"A supportive partnership built on honesty."},
{from:"Kristoff",to:"Sven",kind:"Companions",note:"A long-standing friendship and mountain team."},
{from:"Elsa",to:"Bruni",kind:"Spirit connection",note:"A curious friendship with a small fire spirit."}
];
