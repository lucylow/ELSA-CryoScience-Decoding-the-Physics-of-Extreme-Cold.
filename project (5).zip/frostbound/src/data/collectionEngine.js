export function addCollectionItem(collection,item){if(collection.some(entry=>entry.id===item.id))return collection;return [...collection,item];}
export function removeCollectionItem(collection,id){return collection.filter(entry=>entry.id!==id);}
export function collectionStats(collection){return {total:collection.length,rare:collection.filter(x=>x.rarity==="Rare"||x.rarity==="Special").length};}
