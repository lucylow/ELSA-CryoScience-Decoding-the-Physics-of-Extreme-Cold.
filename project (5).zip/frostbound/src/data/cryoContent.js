import { Atom, BookOpen, Boxes, Cpu, Droplets, FlaskConical, Leaf, Snowflake, Thermometer, ThermometerSnowflake } from "lucide-react";

export const campusRooms = [
  { id: "materials", n: "01", name: "Materials Intelligence Laboratory", short: "Materials", dest: "materials", Icon: Boxes, x: 38, y: 57, hue: "#7fe3f2", wing: "West tower", description: "Browse a 100-record catalogue, compare density, stiffness, conductivity and embodied carbon, and export records with their provenance." },
  { id: "observatory", n: "02", name: "Ice Physics Observatory", short: "Ice physics", dest: "ice", Icon: Snowflake, x: 50, y: 23, hue: "#bff3fb", wing: "Central spire", description: "Zoom into the hexagonal lattice of ice Ih, hydrogen bonding, crystal growth, grain boundaries and defects." },
  { id: "cryo", n: "03", name: "Cryogenic Research Chamber", short: "Cryogenics", dest: "cryo", Icon: ThermometerSnowflake, x: 50, y: 52, hue: "#8fb8ff", wing: "Central hall", description: "Select a temperature down to −196 °C and see how stiffness, contraction and cooling behave — with clear data-range warnings." },
  { id: "thermal", n: "04", name: "Thermal Engineering Laboratory", short: "Thermal", dest: "lab", Icon: Thermometer, x: 62, y: 57, hue: "#ffc8a8", wing: "East tower", description: "Run steady-state conduction through a specimen with Fourier's law and inspect every assumption behind the result." },
  { id: "freeze", n: "05", name: "Freeze–Thaw Research Centre", short: "Freeze–thaw", dest: "lab-freeze", Icon: Droplets, x: 27, y: 66, hue: "#3fd2c0", wing: "West terrace", description: "Explore how cycles and saturation drive an illustrative exposure index for porous materials." },
  { id: "molecular", n: "06", name: "Molecular Science Laboratory", short: "Molecular", dest: "ice-phase", Icon: Atom, x: 73, y: 66, hue: "#c2b4ff", wing: "East terrace", description: "Watch molecules order, vibrate and escape as energy moves water between solid, liquid and vapour." },
  { id: "computational", n: "07", name: "Computational Physics Hall", short: "Computation", dest: "dashboard", Icon: Cpu, x: 17.5, y: 73, hue: "#9eeaf7", wing: "West annex", description: "The research dashboard: datasets, generated records and the models that power each workflow." },
  { id: "sustainability", n: "08", name: "Sustainability Research Centre", short: "Sustainability", dest: "materials-carbon", Icon: Leaf, x: 82.5, y: 73, hue: "#9ef0c4", wing: "East annex", description: "Compare embodied-carbon indicators across material families — including timber that stores biogenic carbon." },
  { id: "experimental", n: "09", name: "Experimental Testing Laboratory", short: "Experiments", dest: "experiments", Icon: FlaskConical, x: 43, y: 79, hue: "#ffd6f0", wing: "Lower gallery", description: "300 demonstration experiment records with configurations, measurement tables, uncertainty and data-quality flags." },
  { id: "library", n: "10", name: "Scientific Knowledge Library", short: "Library", dest: "academy", Icon: BookOpen, x: 57, y: 79, hue: "#f2e3b8", wing: "Lower gallery", description: "The ELSA Science Academy: learning pathways, quizzes, equation challenges and vocabulary." },
];

export const inspirations = [
  "Curiosity is the beginning of discovery.",
  "Every great scientist starts with a question.",
  "Physics explains the extraordinary world around us.",
  "Your imagination belongs in science.",
  "The future of physics includes you.",
];
