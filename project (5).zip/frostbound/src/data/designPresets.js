export const designPresets=[
{id:"classic",label:"Classic Glacier",height:72,width:56,glow:72,tone:"ice"},
{id:"aurora",label:"Aurora Spire",height:94,width:48,glow:96,tone:"violet"},
{id:"garden",label:"Frost Garden Keep",height:55,width:88,glow:64,tone:"mint"},
{id:"citadel",label:"Snowflake Citadel",height:82,width:92,glow:80,tone:"ice"}
];
