export const faqs=[
{q:"Is this an official Frozen app?",a:"No. It is an unofficial fan-made project and is not affiliated with or endorsed by Disney."},
{q:"Are the palace rooms from the film?",a:"The app mixes familiar themes with invented room names and illustrative design details."},
{q:"Does the app save my notes?",a:"Yes, notes and favorites are stored locally in the browser using localStorage."},
{q:"Are the engineering values real?",a:"No. Any mock values are illustrative and should not be used for engineering decisions."},
{q:"Can I add more mock data?",a:"Yes. The data files in src/data are designed to be easy to extend."}
];
