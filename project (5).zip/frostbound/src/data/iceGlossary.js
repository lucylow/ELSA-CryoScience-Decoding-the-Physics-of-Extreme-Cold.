export const iceGlossary=[
{term:"Dendrite",meaning:"A branching, tree-like crystal form."},
{term:"Refraction",meaning:"The bending of light as it passes between materials."},
{term:"Rime",meaning:"A deposit of ice crystals formed when supercooled droplets freeze on a surface."},
{term:"Facet",meaning:"A flat face on a geometric crystal."},
{term:"Prism",meaning:"A form that can separate light into component colors."},
{term:"Hoarfrost",meaning:"Feathery ice crystals that form on cold surfaces."}
];
