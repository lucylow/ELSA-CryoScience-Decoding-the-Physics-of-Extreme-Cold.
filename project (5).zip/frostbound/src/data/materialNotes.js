export const materialNotes=[
{material:"Clear glacier ice",note:"Translucency and refraction are the defining visual qualities.",care:"Illustrative only: avoid assuming real-world structural suitability."},
{material:"Blue structural ice",note:"A saturated blue tint gives the palace its signature cool depth.",care:"Real ice properties vary with temperature, flaws, and loading."},
{material:"Compacted snow",note:"Soft matte forms contrast with the palace's sharp crystal facets.",care:"Snow density and strength are highly variable."},
{material:"Frosted ice glass",note:"Diffused light can make a space feel calm and private.",care:"A fictional design material in this app, not a tested product."}
];
