import { rooms,characters,locations,spells,quests } from "./mockData";
const wait = ms => new Promise(resolve=>setTimeout(resolve,ms));
export async function getRooms(){await wait(120);return rooms;}
export async function getCharacters(){await wait(100);return characters;}
export async function getLocations(){await wait(100);return locations;}
export async function getSpells(){await wait(90);return spells;}
export async function getQuests(){await wait(140);return quests;}
