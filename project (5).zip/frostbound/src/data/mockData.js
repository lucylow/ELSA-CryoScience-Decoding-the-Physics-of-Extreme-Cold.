export const rooms = [
  { id:"throne", name:"Crystal Throne Hall", category:"Royal", level:"Crown level", mood:"Majestic", temperature:"−8°", description:"A soaring chamber of faceted ice, where the palace's crystalline geometry catches every glimmer of northern light.", details:["Prismatic ice columns","A crystalline throne dais","High vaulted ceiling","Aurora-lit windows"], color:"#bceeff", icon:"♛" },
  { id:"stair", name:"Grand Ice Staircase", category:"Passage", level:"Entry level", mood:"Radiant", temperature:"−6°", description:"A sweeping staircase spirals upward in translucent blue, with steps that shimmer like frozen waves.", details:["Floating frost motes","Sculpted balustrades","Blue-white reflections"], color:"#8adfff", icon:"⌁" },
  { id:"library", name:"Winter Library", category:"Quiet", level:"East wing", mood:"Peaceful", temperature:"−3°", description:"A quiet sanctuary of snowbound stories, maps of the fjord, and beautifully preserved memories.", details:["Snowflake index","Map alcove","Memory shelves","Reading nook"], color:"#d9f7ff", icon:"▤" },
  { id:"observatory", name:"Aurora Observatory", category:"Viewpoint", level:"Spire", mood:"Dreamlike", temperature:"−12°", description:"A glassy lookout beneath the tallest spire, designed to frame the dancing northern lights.", details:["Panoramic ice dome","Star chart","Aurora lens"], color:"#b5d9ff", icon:"✧" },
  { id:"garden", name:"Frost Garden", category:"Nature", level:"Terrace", mood:"Enchanted", temperature:"−1°", description:"A garden of ice flowers, delicate frozen vines, and snow-lilies that sparkle in moonlight.", details:["Crystal roses","Ice willow","Snow-lily pond","Frost arches"], color:"#c4fff1", icon:"❀" },
  { id:"music", name:"Echo Music Room", category:"Creative", level:"West wing", mood:"Luminous", temperature:"−4°", description:"A resonant chamber where every note creates tiny dancing crystals in the air.", details:["Icicle chimes","Frozen harp","Sound-wave ceiling"], color:"#e2d5ff", icon:"♫" },
  { id:"gallery", name:"Memory Gallery", category:"Memory", level:"North corridor", mood:"Nostalgic", temperature:"−2°", description:"A gentle gallery celebrating family, friendship, courage, and the changing seasons.", details:["Memory panels","Lantern niches","Snowflake mosaics"], color:"#d6e8ff", icon:"◇" },
  { id:"balcony", name:"Moonlit Balcony", category:"Viewpoint", level:"South tower", mood:"Serene", temperature:"−10°", description:"A quiet balcony overlooking the mountains and the distant lights of Arendelle.", details:["Carved balustrade","Fjord panorama","Moonstone floor"], color:"#a7d9ff", icon:"☾" },
  { id:"workshop", name:"Snowcraft Workshop", category:"Creative", level:"Lower wing", mood:"Playful", temperature:"−5°", description:"A bright studio for experimenting with snow sculptures, tiny ice creatures, and intricate ornaments.", details:["Sculpting tables","Crystal tools","Snowflake molds"], color:"#c9f5ff", icon:"✣" },
  { id:"portal", name:"Northern Portal", category:"Passage", level:"Outer terrace", mood:"Mysterious", temperature:"−15°", description:"An ornate archway that frames the wild mountain landscape beyond the palace.", details:["Frost-carved arch","Wind bells","Runic snow patterns"], color:"#b8caff", icon:"⌑" }
];

export const characters = [
  { id:"elsa", name:"Elsa", role:"Queen of Arendelle", element:"Ice & snow", quote:"The magic is in you.", bio:"A thoughtful, determined queen whose powers shape ice and snow into extraordinary forms.", traits:["Courageous","Creative","Independent","Protective"], color:"#a8e8ff", symbol:"❄" },
  { id:"anna", name:"Anna", role:"Princess of Arendelle", element:"Warmth", quote:"Some people are worth melting for.", bio:"Optimistic, brave, and loyal, Anna leads with her heart and never gives up on family.", traits:["Hopeful","Loyal","Fearless","Funny"], color:"#f6c6a8", symbol:"♡" },
  { id:"olaf", name:"Olaf", role:"Snow friend", element:"Snow magic", quote:"Some people are worth melting for.", bio:"A cheerful snowman who finds wonder in everything and brings laughter to every room.", traits:["Joyful","Curious","Kind","Dreamy"], color:"#f3f7ff", symbol:"☃" },
  { id:"kristoff", name:"Kristoff", role:"Ice harvester", element:"Mountain life", quote:"I like warm hugs.", bio:"A practical mountain companion with a generous heart and a strong connection to the outdoors.", traits:["Resourceful","Honest","Steady","Kind"], color:"#d8d2c8", symbol:"❅" },
  { id:"sven", name:"Sven", role:"Reindeer companion", element:"Forest", quote:"Best reindeer friend.", bio:"A loyal reindeer whose expressive personality makes him an unforgettable companion.", traits:["Loyal","Gentle","Playful","Brave"], color:"#d9b88f", symbol:"♧" },
  { id:"bruni", name:"Bruni", role:"Fire spirit", element:"Fire", quote:"A tiny spark of wonder.", bio:"A small salamander spirit with a curious nature and a fondness for warmth.", traits:["Curious","Shy","Magical","Playful"], color:"#ffb5a2", symbol:"✦" },
  { id:"grandpabbie", name:"Grand Pabbie", role:"Troll elder", element:"Ancient magic", quote:"The past is not what it seems.", bio:"A wise keeper of old stories who offers perspective when magic and memory become complicated.", traits:["Wise","Patient","Mysterious","Gentle"], color:"#c8d8c5", symbol:"✧" }
];

export const locations = [
  { id:"arendelle", name:"Arendelle", type:"Kingdom", region:"Fjord coast", description:"A lively kingdom nestled between steep mountains and a deep blue fjord.", highlight:"Harbor, castle, village square" },
  { id:"north-mountain", name:"North Mountain", type:"Mountain", region:"Northern range", description:"A rugged, snow-covered mountain range that rises above the kingdom.", highlight:"Ice palace, snowy ridges" },
  { id:"ice-palace", name:"Elsa's Ice Palace", type:"Palace", region:"North Mountain", description:"A magnificent crystalline palace created through Elsa's ice magic.", highlight:"Spire, throne hall, balcony" },
  { id:"enchanted-forest", name:"Enchanted Forest", type:"Forest", region:"Beyond the valley", description:"An ancient woodland filled with spirits, mist, and hidden history.", highlight:"River, mist, elemental spirits" },
  { id:"dark-sea", name:"Dark Sea", type:"Sea", region:"Far north", description:"A vast, stormy sea that tests courage and determination.", highlight:"Waves, wind, distant horizon" },
  { id:"aatohallan", name:"Ahtohallan", type:"Glacial wonder", region:"Far north", description:"A mysterious frozen place associated with memory and discovery.", highlight:"Glacial forms, memory visions" }
];

export const timeline = [
  { year:"Before the story", title:"A gift of winter", text:"Elsa discovers that her magic can shape delicate snowflakes and powerful walls of ice.", tag:"Origins" },
  { year:"The coronation", title:"A secret revealed", text:"A moment of fear brings Elsa's hidden powers into the open, changing life in Arendelle.", tag:"Turning point" },
  { year:"The mountain", title:"A palace of her own", text:"Seeking solitude, Elsa creates an extraordinary ice palace high above the kingdom.", tag:"Architecture" },
  { year:"A new beginning", title:"Learning to connect", text:"Elsa begins to understand that love and connection can help her live confidently with her powers.", tag:"Growth" },
  { year:"Beyond the forest", title:"A wider world", text:"New discoveries invite Elsa to explore the origins and responsibilities of her magic.", tag:"Discovery" }
];

export const spells = [
  { id:"snowflake", name:"Snowflake Bloom", type:"Creation", difficulty:"Beginner", description:"Create a delicate six-pointed snowflake with branching crystal arms.", effect:"A small snowflake blooms in the air.", color:"#bdefff" },
  { id:"ice-bridge", name:"Glacier Bridge", type:"Architecture", difficulty:"Advanced", description:"Raise a graceful bridge of layered ice across a narrow gap.", effect:"A luminous arched bridge forms.", color:"#8adfff" },
  { id:"aurora", name:"Aurora Veil", type:"Light", difficulty:"Intermediate", description:"Scatter cool light into a ribbon of color above the palace.", effect:"A soft aurora shimmers overhead.", color:"#c7c4ff" },
  { id:"crystal", name:"Crystal Bloom", type:"Sculpture", difficulty:"Intermediate", description:"Grow a cluster of translucent crystals from a smooth ice surface.", effect:"Faceted crystal petals rise.", color:"#d8f8ff" },
  { id:"frost-wind", name:"Frostwind Spiral", type:"Motion", difficulty:"Advanced", description:"Guide snow into a controlled spiral that dances around a space.", effect:"A sparkling spiral of snow swirls.", color:"#d3eaff" },
  { id:"snow-dome", name:"Winter Dome", type:"Architecture", difficulty:"Expert", description:"Shape a protective dome from interlocking ice ribs.", effect:"A vaulted dome glows with blue light.", color:"#a8dfff" }
];

export const quests = [
  { id:1, title:"Map the Palace", category:"Explorer", reward:120, description:"Visit five palace rooms and discover their architectural details.", steps:["Open the Throne Hall","Visit the Winter Library","Explore the Frost Garden","Find the Observatory","Save a favorite room"] },
  { id:2, title:"A Study in Snowflakes", category:"Creative", reward:90, description:"Experiment with snow magic and collect three spell designs.", steps:["Read Snowflake Bloom","Try Crystal Bloom","Try Aurora Veil"] },
  { id:3, title:"Kingdom Connections", category:"Story", reward:150, description:"Learn about the people and places connected to Elsa's story.", steps:["Meet Anna","Explore Arendelle","Visit the North Mountain","Read the timeline"] },
  { id:4, title:"Design a New Spire", category:"Architect", reward:200, description:"Use the Palace Studio to create a new architectural silhouette.", steps:["Adjust spire height","Choose an ice tone","Set the window pattern","Save your design"] }
];

export const gallery = [
  { id:1, title:"The First Snowfall", category:"Magic", caption:"A quiet drift of snow over the mountain.", tone:"blue" },
  { id:2, title:"Crystal Geometry", category:"Architecture", caption:"Repeating facets create a sense of height and light.", tone:"cyan" },
  { id:3, title:"Aurora Above the Spire", category:"Sky", caption:"Northern lights frame the tallest tower.", tone:"violet" },
  { id:4, title:"The Frozen Garden", category:"Nature", caption:"Ice flowers catch the pale winter sun.", tone:"mint" },
  { id:5, title:"Throne Hall Reflections", category:"Interior", caption:"The floor mirrors the palace's crystalline ribs.", tone:"blue" },
  { id:6, title:"A Balcony at Dusk", category:"Landscape", caption:"The fjord fades into a soft winter evening.", tone:"violet" },
  { id:7, title:"Snowflake Study", category:"Magic", caption:"A close look at branching six-fold symmetry.", tone:"cyan" },
  { id:8, title:"The Ice Bridge", category:"Architecture", caption:"A graceful connection between two terraces.", tone:"mint" },
  { id:9, title:"Winter Library", category:"Interior", caption:"A quiet place for stories and reflection.", tone:"blue" },
  { id:10, title:"Mountain Silhouette", category:"Landscape", caption:"The palace rises above the mountain ridge.", tone:"violet" }
];

export const mockProjects = [
  { id:"P-104", name:"Aurora Spire Study", status:"In progress", owner:"Elsa", updated:"Today", progress:78 },
  { id:"P-103", name:"Crystal Garden Pavilion", status:"Review", owner:"Anna", updated:"Yesterday", progress:92 },
  { id:"P-102", name:"Fjord Lookout", status:"Concept", owner:"Kristoff", updated:"2 days ago", progress:34 },
  { id:"P-101", name:"Winter Library Expansion", status:"Complete", owner:"Elsa", updated:"Last week", progress:100 }
];

export const mockEvents = [
  { time:"08:00", title:"First light on the spire", type:"Palace" },
  { time:"10:30", title:"Snowflake study in the workshop", type:"Creative" },
  { time:"13:00", title:"Garden crystal inspection", type:"Nature" },
  { time:"16:15", title:"Aurora observatory visit", type:"Sky" },
  { time:"19:00", title:"Quiet hour in the library", type:"Personal" }
];

export const materials = [
  { id:"ice-clear", name:"Clear glacier ice", density:917, thermal:"High sensitivity", finish:"Translucent", use:"Windows, crystal details" },
  { id:"ice-blue", name:"Blue structural ice", density:920, thermal:"High sensitivity", finish:"Blue translucent", use:"Columns, walls, stairs" },
  { id:"snow-pack", name:"Compacted snow", density:450, thermal:"Insulating", finish:"Matte white", use:"Snow forms, sheltered berms" },
  { id:"frost-glass", name:"Frosted ice glass", density:910, thermal:"High sensitivity", finish:"Diffused", use:"Screens, partitions" },
  { id:"crystal", name:"Faceted crystal ice", density:925, thermal:"High sensitivity", finish:"Prismatic", use:"Decorative spires, sculpture" },
  { id:"everfrost", name:"Everfrost composite (fictional)", density:780, thermal:"Illustrative", finish:"Pearlescent", use:"Concept-only magical detailing" }
];

export const mockStats = [
  { label:"Palace rooms", value:"10", note:"Explore every wing" },
  { label:"Magic studies", value:"06", note:"Try a new spell" },
  { label:"Story entries", value:"05", note:"A journey through time" },
  { label:"Discoveries", value:"24", note:"Mock collection count" }
];
