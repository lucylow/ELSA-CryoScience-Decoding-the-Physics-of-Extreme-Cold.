export const mockNotifications=[
{id:1,title:"A new room awaits",message:"The Winter Library is ready to explore.",time:"Just now",read:false},
{id:2,title:"Journal saved",message:"Your latest palace note was saved locally.",time:"Earlier today",read:true},
{id:3,title:"Aurora forecast",message:"The observatory has a clear view tonight.",time:"Yesterday",read:true},
{id:4,title:"Quest progress",message:"You are one room away from Map the Palace.",time:"Yesterday",read:false}
];
