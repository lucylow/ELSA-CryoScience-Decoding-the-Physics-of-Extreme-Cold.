export const blueprints=[
{id:"bp-01",name:"North Crown",spires:5,levels:3,style:"Radial crystal",notes:"A symmetrical crown silhouette with a high central needle."},
{id:"bp-02",name:"Aurora Ribbon",spires:3,levels:4,style:"Flowing",notes:"Curved tower profiles inspired by ribbons of light."},
{id:"bp-03",name:"Glacier Keep",spires:7,levels:2,style:"Layered facets",notes:"A broad base and clustered crystalline pinnacles."},
{id:"bp-04",name:"Moonlit Pavilion",spires:4,levels:1,style:"Open lantern",notes:"An airy pavilion with a translucent lantern roof."},
{id:"bp-05",name:"Snowflake Citadel",spires:6,levels:3,style:"Six-fold symmetry",notes:"Six wings radiate from a central crystalline hall."}
];
