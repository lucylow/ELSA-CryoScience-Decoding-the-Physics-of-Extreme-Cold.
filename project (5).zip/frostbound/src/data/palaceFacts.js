export const palaceFacts=[
"Elsa's palace is a visual expression of independence and self-discovery.",
"Repeating six-fold snowflake geometry gives the palace a coherent visual motif.",
"Translucent surfaces allow light to become part of the architecture.",
"The tallest spire creates a strong vertical focal point against the mountain.",
"Curved stairs and pointed arches balance organic and crystalline forms.",
"Cool blues and pale silvers make the palace feel luminous rather than heavy.",
"The palace is imagined here as a collection of connected rooms and terraces.",
"Every room in this demo has its own mood, palette, and design vocabulary."
];
