const familyTemplates = [
  { family: "Carbon steel", name: "Carbon steel", density: 7850, modulus: 205, strength: 355, conductivity: 50, heatCapacity: 490, expansion: 12, moisture: 0.12, carbon: 2.1 },
  { family: "Stainless steel", name: "Austenitic stainless steel", density: 8000, modulus: 193, strength: 290, conductivity: 16, heatCapacity: 500, expansion: 17, moisture: 0.08, carbon: 5.4 },
  { family: "Alloy steel", name: "Low-alloy steel", density: 7850, modulus: 210, strength: 460, conductivity: 42, heatCapacity: 470, expansion: 11.5, moisture: 0.1, carbon: 2.8 },
  { family: "High-strength steel", name: "High-strength structural steel", density: 7820, modulus: 205, strength: 690, conductivity: 40, heatCapacity: 470, expansion: 12, moisture: 0.1, carbon: 2.5 },
  { family: "Aluminium alloy", name: "Aluminium alloy", density: 2700, modulus: 70, strength: 310, conductivity: 160, heatCapacity: 900, expansion: 23, moisture: 0.04, carbon: 8.2 },
  { family: "Reinforced concrete", name: "Reinforced concrete", density: 2400, modulus: 32, strength: 35, conductivity: 1.8, heatCapacity: 880, expansion: 10, moisture: 0.72, carbon: 0.17 },
  { family: "Low-carbon concrete", name: "Low-carbon concrete", density: 2300, modulus: 29, strength: 32, conductivity: 1.5, heatCapacity: 900, expansion: 9.5, moisture: 0.68, carbon: 0.11 },
  { family: "High-performance concrete", name: "High-performance concrete", density: 2450, modulus: 42, strength: 75, conductivity: 2.2, heatCapacity: 850, expansion: 10, moisture: 0.54, carbon: 0.22 },
  { family: "Cross-laminated timber", name: "Cross-laminated timber", density: 480, modulus: 11, strength: 28, conductivity: 0.13, heatCapacity: 1600, expansion: 0.2, moisture: 0.82, carbon: -0.65 },
  { family: "Glulam", name: "Glulam", density: 500, modulus: 13, strength: 38, conductivity: 0.14, heatCapacity: 1500, expansion: 0.2, moisture: 0.78, carbon: -0.72 },
  { family: "Structural timber", name: "Structural softwood", density: 430, modulus: 10, strength: 24, conductivity: 0.12, heatCapacity: 1500, expansion: 0.25, moisture: 0.9, carbon: -0.55 },
  { family: "Glass-fibre composite", name: "Glass-fibre polymer composite", density: 1900, modulus: 28, strength: 420, conductivity: 0.35, heatCapacity: 900, expansion: 8, moisture: 0.2, carbon: 4.6 },
  { family: "Carbon-fibre composite", name: "Carbon-fibre polymer composite", density: 1550, modulus: 125, strength: 900, conductivity: 6, heatCapacity: 850, expansion: 1.5, moisture: 0.12, carbon: 18 },
  { family: "Thermoplastic", name: "Engineering thermoplastic", density: 1180, modulus: 2.4, strength: 65, conductivity: 0.22, heatCapacity: 1450, expansion: 75, moisture: 0.18, carbon: 3.2 },
  { family: "Thermoset polymer", name: "Epoxy thermoset", density: 1200, modulus: 3.1, strength: 82, conductivity: 0.24, heatCapacity: 1100, expansion: 55, moisture: 0.16, carbon: 5.1 },
  { family: "Elastomer", name: "Synthetic elastomer", density: 1120, modulus: 0.025, strength: 18, conductivity: 0.16, heatCapacity: 1800, expansion: 160, moisture: 0.12, carbon: 3.5 },
  { family: "Mineral wool", name: "Mineral wool insulation", density: 85, modulus: 0.02, strength: 0.08, conductivity: 0.038, heatCapacity: 840, expansion: 5, moisture: 0.2, carbon: 1.2 },
  { family: "Cellulose insulation", name: "Cellulose-fibre insulation", density: 55, modulus: 0.01, strength: 0.04, conductivity: 0.039, heatCapacity: 1900, expansion: 8, moisture: 0.64, carbon: 0.18 },
  { family: "Silica aerogel", name: "Silica aerogel blanket", density: 150, modulus: 0.08, strength: 0.5, conductivity: 0.018, heatCapacity: 1000, expansion: 2, moisture: 0.14, carbon: 6.4 },
  { family: "Soda-lime glass", name: "Soda-lime glass", density: 2500, modulus: 70, strength: 45, conductivity: 1.0, heatCapacity: 840, expansion: 9, moisture: 0.02, carbon: 1.3 },
];

const variantNames = ["Baseline", "Low-density variant", "High-strength variant", "Thermal-optimized variant", "Moisture-conditioned variant"];
const temperaturesC = [-60, -50, -40, -30, -20, -10, 0, 10, 20, 30, 40];
const variation = (index) => 0.94 + ((index * 17 + 13) % 13) / 100;

export const materials = familyTemplates.flatMap((template, familyIndex) =>
  variantNames.map((variant, variantIndex) => {
    const index = familyIndex * variantNames.length + variantIndex;
    const factor = variation(index);
    const strengthFactor = variantIndex === 2 ? 1.18 : factor;
    const conductivityFactor = variantIndex === 3 ? 0.86 : factor;
    const moistureFactor = variantIndex === 4 ? 1.14 : factor;
    const density = Math.round(template.density * factor);
    const modulus = Number((template.modulus * (variantIndex === 1 ? 0.91 : factor)).toPrecision(3));
    const tensileStrength = Number((template.strength * strengthFactor).toPrecision(3));
    const thermalConductivity = Number((template.conductivity * conductivityFactor).toPrecision(3));
    const moistureSensitivity = Number(Math.min(1, template.moisture * moistureFactor).toFixed(2));
    const embodiedCarbon = Number((template.carbon * factor).toPrecision(3));
    const id = `SDEM-${String(index + 1).padStart(3, "0")}`;
    const points = temperaturesC.map((temperatureC) => {
      const coldFactor = 1 + Math.max(0, 20 - temperatureC) * (template.family.includes("Polymer") || template.family === "Elastomer" ? 0.0017 : 0.00018);
      return { temperatureC, youngsModulusGPa: Number((modulus * coldFactor).toPrecision(4)) };
    });
    return {
      id,
      name: `${template.name} — ${variant}`,
      family: template.family,
      densityKgM3: density,
      youngsModulusGPa: modulus,
      tensileStrengthMPa: tensileStrength,
      thermalConductivityWMK: thermalConductivity,
      specificHeatJkgK: Math.round(template.heatCapacity * factor),
      thermalExpansionMicrostrainK: Number((template.expansion * factor).toPrecision(3)),
      moistureSensitivity,
      embodiedCarbonKgCO2eKg: embodiedCarbon,
      temperatureRangeC: [-60, 40],
      propertyCurve: points,
      dataClassification: "synthetic_demonstration",
      isExperimentalMeasurement: false,
      isPublishedReferenceData: false,
      isValidatedSimulation: false,
      sourceDescription: "Deterministically generated educational demonstration data; not measured or certified material data.",
      limitations: ["Synthetic values only", "Not suitable as the sole basis for engineering design", "Temperature curves are illustrative and not validated"],
    };
  }),
);

export const propertyPointCount = materials.reduce((total, material) => total + material.propertyCurve.length, 0);
export const materialFamilies = [...new Set(materials.map((material) => material.family))];

export const experimentRecords = Array.from({ length: 300 }, (_, index) => {
  const material = materials[(index * 7 + 3) % materials.length];
  const testTypes = ["Thermal conductivity demonstration", "Freeze–thaw exposure demonstration", "Moisture uptake demonstration"];
  const testType = testTypes[index % testTypes.length];
  const temperatureC = -40 + ((index * 11) % 61);
  const exposureCycles = 1 + ((index * 13) % 120);
  return {
    id: `XDEMO-${String(index + 1).padStart(4, "0")}`,
    materialId: material.id,
    testType,
    temperatureC,
    exposureCycles,
    dataClassification: "synthetic_demonstration",
    isExperimentalMeasurement: false,
    sourceDescription: "Generated for interface and analysis demonstrations only.",
  };
});
