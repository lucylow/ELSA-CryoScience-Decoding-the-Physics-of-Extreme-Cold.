import {rooms,characters,locations,spells} from "./mockData";
export const searchIndex=[...rooms.map(x=>({...x,kind:"Room"})),...characters.map(x=>({...x,kind:"Character"})),...locations.map(x=>({...x,kind:"Location"})),...spells.map(x=>({...x,kind:"Spell"}))];
export function globalSearch(query){const q=query.toLowerCase().trim();return q?searchIndex.filter(x=>`${x.name} ${x.description??x.bio??""} ${x.kind}`.toLowerCase().includes(q)):[];}
