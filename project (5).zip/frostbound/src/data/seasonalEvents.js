export const seasonalEvents=[
{id:"winter-lights",name:"Winter Lights Evening",month:"December",description:"A gentle lantern walk and aurora viewing night."},
{id:"crystal-week",name:"Crystal Week",month:"January",description:"A week of ice sculpture and geometry challenges."},
{id:"snow-stories",name:"Snow Stories",month:"February",description:"A story circle in the Winter Library."},
{id:"first-thaw",name:"First Thaw Celebration",month:"March",description:"A celebration of change, renewal, and warmer light."}
];
