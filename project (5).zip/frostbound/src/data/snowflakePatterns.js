export const snowflakePatterns=[
{id:"six-arm",name:"Six-arm classic",arms:6,symmetry:6,complexity:1},
{id:"fern",name:"Fern branch",arms:6,symmetry:6,complexity:3},
{id:"star",name:"Crystal star",arms:6,symmetry:6,complexity:2},
{id:"plate",name:"Hexagonal plate",arms:6,symmetry:6,complexity:1},
{id:"needle",name:"Needle cluster",arms:6,symmetry:6,complexity:2},
{id:"lace",name:"Lace crystal",arms:6,symmetry:6,complexity:4}
];
