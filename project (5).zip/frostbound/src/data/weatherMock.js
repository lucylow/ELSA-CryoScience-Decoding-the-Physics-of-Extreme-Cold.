export const weatherSnapshots=[
{day:"Monday",temperature:-8,condition:"Soft snowfall",wind:"Light north breeze",visibility:"Clear"},
{day:"Tuesday",temperature:-11,condition:"Bright frost",wind:"Calm",visibility:"Excellent"},
{day:"Wednesday",temperature:-6,condition:"Aurora evening",wind:"Gentle",visibility:"Clear"},
{day:"Thursday",temperature:-13,condition:"Mountain flurries",wind:"Moderate",visibility:"Variable"},
{day:"Friday",temperature:-4,condition:"Blue-sky winter",wind:"Light",visibility:"Excellent"}
];
