import React, { useMemo, useState } from "react";
import { ArrowRight, Atom, BookOpen, Check, Cpu, Flame, Globe2, Hexagon, Lightbulb, RotateCcw, Snowflake, Sparkles, Thermometer, ThermometerSnowflake, Boxes, X } from "lucide-react";
import Modal from "../components/Modal";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { inspirations } from "../data/cryoContent";

const pathways = [
  { id: "discover", title: "Discovering Physics", Icon: Lightbulb, level: "Beginner", mins: 15, dest: "home", text: "What physicists do, how a question becomes an experiment, and why measurement matters.", concepts: ["Physics models the world with quantities, units and equations.", "A good experiment changes one variable at a time.", "Every measurement has an uncertainty."] },
  { id: "ice", title: "The Science of Ice", Icon: Snowflake, level: "Beginner", mins: 20, dest: "ice", text: "Why ice floats, why snowflakes have six arms and how a crystal grows.", concepts: ["Ice Ih is a hexagonal lattice held together by hydrogen bonds.", "Its open structure makes ice about 9% less dense than water.", "Temperature and humidity decide a snow crystal's shape."] },
  { id: "temperature", title: "Understanding Temperature", Icon: Thermometer, level: "Beginner", mins: 15, dest: "cryo", text: "Celsius, kelvin and what temperature really measures at the molecular scale.", concepts: ["Temperature reflects the average kinetic energy of particles.", "Absolute zero is 0 K = −273.15 °C.", "A change of 1 K equals a change of 1 °C."] },
  { id: "atoms", title: "Atoms and Molecules", Icon: Atom, level: "Beginner", mins: 20, dest: "ice-phase", text: "From protons and electrons to the bent shape of the water molecule.", concepts: ["Atoms bond by sharing or transferring electrons.", "Water is bent (104.5°) and polar.", "Polarity enables hydrogen bonding."] },
  { id: "thermo", title: "Thermodynamics", Icon: Flame, level: "Intermediate", mins: 30, dest: "ice", text: "Energy, heat, work and the latent heat that hides inside every phase change.", concepts: ["Energy is conserved: heat in equals energy stored plus work out.", "During a phase change temperature stays constant (Q = m·L).", "Heat flows spontaneously from hot to cold."] },
  { id: "materials", title: "Materials Science", Icon: Boxes, level: "Intermediate", mins: 30, dest: "materials", text: "How structure at the atomic scale gives steel, timber and polymers their properties.", concepts: ["Stiffness is measured by Young's modulus (E = stress / strain).", "Microstructure — grains, fibres, pores — controls behaviour.", "Every material choice is a trade-off."] },
  { id: "heat", title: "Heat Transfer", Icon: ThermometerSnowflake, level: "Intermediate", mins: 25, dest: "lab", text: "Conduction, convection and radiation — and how insulation slows all three.", concepts: ["Fourier's law: Q̇ = k·A·ΔT / L.", "Low conductivity k means good insulation.", "Trapped still air is why snow and wool insulate."] },
  { id: "cryo", title: "Cryogenic Engineering", Icon: Hexagon, level: "Advanced", mins: 35, dest: "cryo", text: "Designing for −196 °C: contraction, brittle fracture and vacuum insulation.", concepts: ["Materials contract on cooling: ΔL = α·L₀·ΔT.", "Some steels turn brittle in the cold; austenitic alloys stay tough.", "Cryogenic tanks rely on vacuum and multilayer insulation."] },
  { id: "env", title: "Environmental Physics", Icon: Globe2, level: "Intermediate", mins: 25, dest: "lab-freeze", text: "Snowpacks, glaciers, freeze–thaw weathering and the physics of a changing climate.", concepts: ["Water expands about 9% on freezing, cracking rock and concrete.", "Snow albedo reflects most sunlight.", "Glaciers form as snow compacts into firn and ice."] },
  { id: "compute", title: "Computational Science", Icon: Cpu, level: "Advanced", mins: 30, dest: "dashboard", text: "Turning equations into simulations — and knowing when a model can be trusted.", concepts: ["Models simplify reality with stated assumptions.", "Validate a model against measured data before trusting it.", "Synthetic data is for testing workflows, not drawing conclusions."] },
];

const quiz = [
  { q: "Why does ice float on liquid water?", options: ["Ice contains trapped air bubbles", "Its hydrogen-bonded hexagonal lattice is more open, so it is less dense", "Ice is colder than water", "Water molecules in ice are lighter"], a: 1, why: "Ice Ih (≈917 kg/m³) is less dense than liquid water (≈1000 kg/m³) because hydrogen bonds hold molecules in an open hexagonal network." },
  { q: "How much energy does it take to melt 1 kg of ice at 0 °C?", options: ["4.18 kJ", "2.09 kJ", "334 kJ", "2257 kJ"], a: 2, why: "The specific latent heat of fusion of water is about 334 kJ/kg." },
  { q: "Which of these is the best thermal insulator?", options: ["Aluminium alloy", "Concrete", "Silica aerogel", "Soda-lime glass"], a: 2, why: "Aerogels have thermal conductivities around 0.015–0.02 W/(m·K), among the lowest of any solid." },
  { q: "Absolute zero, in degrees Celsius, is…", options: ["−100 °C", "−196 °C", "−273.15 °C", "−459.67 °C"], a: 2, why: "0 K = −273.15 °C. (−459.67 is the value in °F; −196 °C is where nitrogen boils.)" },
  { q: "Snowflakes have six-fold symmetry because…", options: ["Clouds are hexagonal", "Of the hexagonal crystal structure of ice Ih", "Wind shapes them", "They contain six molecules"], a: 1, why: "The macroscopic shape reflects the underlying hexagonal lattice." },
  { q: "Which process turns a solid directly into a gas?", options: ["Condensation", "Sublimation", "Deposition", "Fusion"], a: 1, why: "Sublimation skips the liquid phase — dry ice and snow on cold sunny days both sublimate." },
];

const vocabulary = [
  ["Nucleation", "The first formation of a tiny stable crystal, often on a dust particle or surface."],
  ["Latent heat", "Energy absorbed or released during a phase change without a change in temperature."],
  ["Thermal conductivity", "How readily a material conducts heat, in W/(m·K)."],
  ["Hydrogen bond", "An attraction between a hydrogen bonded to oxygen and a neighbouring oxygen."],
  ["Grain boundary", "The interface where two crystals of different orientation meet."],
  ["Brittle fracture", "Sudden cracking with little plastic deformation, more common in the cold."],
  ["Specific heat capacity", "Energy to raise 1 kg of a substance by 1 K, in J/(kg·K)."],
  ["Sublimation", "A direct transition from solid to gas."],
];

const matching = [
  { prompt: "Highest thermal conductivity", answer: "Aluminium alloy" },
  { prompt: "Stores biogenic carbon (negative embodied carbon)", answer: "Cross-laminated timber" },
  { prompt: "Largest thermal expansion", answer: "Synthetic elastomer" },
  { prompt: "Lowest thermal conductivity", answer: "Silica aerogel" },
];
const matchOptions = ["Aluminium alloy", "Cross-laminated timber", "Synthetic elastomer", "Silica aerogel"];

export default function Academy({ setPage, search = "" }) {
  const [progress, setProgress] = useLocalStorage("cryo-academy-progress", {});
  const [open, setOpen] = useState(null);
  const [quoteIndex, setQuoteIndex] = useState(0);
  const list = pathways.filter((p) => `${p.title} ${p.text}`.toLowerCase().includes(search.toLowerCase()));
  const pct = (p) => Math.round(((progress[p.id]?.length ?? 0) / p.concepts.length) * 100);
  const overall = Math.round(pathways.reduce((s, p) => s + pct(p), 0) / pathways.length);
  const toggleConcept = (pid, idx) =>
    setProgress((old) => {
      const cur = new Set(old[pid] ?? []);
      cur.has(idx) ? cur.delete(idx) : cur.add(idx);
      return { ...old, [pid]: [...cur] };
    });

  return (
    <div className="page-wrap cs-page">
      <section className="cs-academy-hero">
        <div>
          <span className="cs-overline cs-overline--dark">The ELSA Science Academy</span>
          <h2 className="cs-display">Every great scientist starts with <em>a question.</em></h2>
          <p>Ten pathways from your first experiment to cryogenic engineering. Learn at your own pace — your progress is saved in this browser.</p>
          <div className="cs-overall">
            <div className="cs-progress" role="progressbar" aria-valuenow={overall} aria-valuemin={0} aria-valuemax={100} aria-label="Overall academy progress"><i style={{ width: `${overall}%` }} /></div>
            <span className="cs-mono">{overall}% complete</span>
          </div>
        </div>
        <figure className="cs-quote-card">
          <Sparkles size={18} aria-hidden="true" />
          <blockquote key={quoteIndex} className="cs-fade">{inspirations[quoteIndex]}</blockquote>
          <button className="cs-link" onClick={() => setQuoteIndex((i) => (i + 1) % inspirations.length)}>Next inspiration <ArrowRight size={14} aria-hidden="true" /></button>
        </figure>
      </section>

      <div className="cs-section-head">
        <span className="cs-overline cs-overline--dark">Learning pathways</span>
        <h3 className="cs-display">Choose where to begin</h3>
      </div>
      <div className="cs-path-grid">
        {list.map((p, i) => (
          <article key={p.id} className="cs-path" style={{ "--i": i }}>
            <div className="cs-path-art" aria-hidden="true"><p.Icon size={26} /><span className="cs-mono">{String(i + 1).padStart(2, "0")}</span></div>
            <div className="cs-path-meta"><span className={`cs-level cs-level--${p.level.toLowerCase()}`}>{p.level}</span><span className="cs-mono">{p.mins} min</span></div>
            <h4>{p.title}</h4>
            <p>{p.text}</p>
            <div className="cs-progress cs-progress--sm" role="progressbar" aria-valuenow={pct(p)} aria-valuemin={0} aria-valuemax={100} aria-label={`${p.title} progress`}><i style={{ width: `${pct(p)}%` }} /></div>
            <div className="cs-path-actions">
              <button className="cs-btn cs-btn--dark" onClick={() => setOpen(p)}>{pct(p) ? (pct(p) === 100 ? "Review" : "Continue") : "Start lesson"}</button>
              <button className="cs-link cs-link--dark" onClick={() => setPage(p.dest)}>Demo <ArrowRight size={13} aria-hidden="true" /></button>
            </div>
          </article>
        ))}
        {!list.length && <p className="cs-empty cs-empty--dark">No pathways match “{search}”.</p>}
      </div>

      <div className="cs-section-head">
        <span className="cs-overline cs-overline--dark">Interactive activities</span>
        <h3 className="cs-display">Practise like a physicist</h3>
      </div>
      <div className="cs-activity-grid">
        <Quiz />
        <EquationChallenge />
        <MaterialMatching />
        <Vocabulary />
      </div>

      <Modal open={!!open} onClose={() => setOpen(null)} title={open?.title}>
        {open && (
          <div className="cs-lesson">
            <p>{open.text}</p>
            <span className="cs-overline cs-overline--dark">Key ideas · tick each one you understand</span>
            <ul>
              {open.concepts.map((c, idx) => {
                const done = progress[open.id]?.includes(idx);
                return (
                  <li key={c}>
                    <button className={done ? "is-done" : ""} aria-pressed={!!done} onClick={() => toggleConcept(open.id, idx)}>
                      <span className="cs-check">{done && <Check size={13} aria-hidden="true" />}</span>
                      {c}
                    </button>
                  </li>
                );
              })}
            </ul>
            <button className="cs-btn cs-btn--primary" onClick={() => { setPage(open.dest); setOpen(null); }}>
              Open the interactive demonstration <ArrowRight size={15} aria-hidden="true" />
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Quiz() {
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  const done = i >= quiz.length;
  const item = quiz[i];
  const choose = (idx) => {
    if (picked != null) return;
    setPicked(idx);
    if (idx === item.a) setScore((s) => s + 1);
  };
  return (
    <article className="cs-card cs-activity">
      <span className="cs-overline cs-overline--dark">Knowledge quiz</span>
      {done ? (
        <div className="cs-quiz-done">
          <b className="cs-mono">{score} / {quiz.length}</b>
          <p>{score === quiz.length ? "Perfect — you think like a physicist." : "Great effort. Every question is a step toward discovery."}</p>
          <button className="cs-btn cs-btn--outline" onClick={() => { setI(0); setPicked(null); setScore(0); }}><RotateCcw size={14} aria-hidden="true" /> Try again</button>
        </div>
      ) : (
        <>
          <h4>{item.q}</h4>
          <div className="cs-options">
            {item.options.map((o, idx) => (
              <button key={o} onClick={() => choose(idx)} disabled={picked != null} className={picked == null ? "" : idx === item.a ? "is-right" : idx === picked ? "is-wrong" : ""}>
                {o}
              </button>
            ))}
          </div>
          {picked != null && (
            <div className="cs-feedback" role="status">
              <p>{picked === item.a ? "Correct. " : "Not quite. "}{item.why}</p>
              <button className="cs-btn cs-btn--dark" onClick={() => { setI((n) => n + 1); setPicked(null); }}>Next question</button>
            </div>
          )}
          <small className="cs-mono">Question {i + 1} of {quiz.length}</small>
        </>
      )}
    </article>
  );
}

const MASSES = [0.5, 1.2, 2, 2.5, 3.5, 4.8];
function EquationChallenge() {
  const [n, setN] = useState(0);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState(null);
  const m = MASSES[n % MASSES.length];
  const target = m * 334;
  const check = (e) => {
    e.preventDefault();
    const v = Number(answer);
    setResult(Number.isFinite(v) && Math.abs(v - target) <= target * 0.01 ? "right" : "wrong");
  };
  return (
    <article className="cs-card cs-activity">
      <span className="cs-overline cs-overline--dark">Equation challenge</span>
      <h4>How much energy melts {m} kg of ice already at 0 °C?</h4>
      <code className="cs-eq cs-mono">Q = m · L_f · L_f = 334 kJ/kg</code>
      <form onSubmit={check} className="cs-answer">
        <label htmlFor="eq-answer" className="sr-only">Your answer in kilojoules</label>
        <input id="eq-answer" inputMode="decimal" value={answer} onChange={(e) => { setAnswer(e.target.value); setResult(null); }} placeholder="Answer" />
        <span>kJ</span>
        <button className="cs-btn cs-btn--dark" type="submit" disabled={!answer}>Check</button>
      </form>
      {result && (
        <p className={`cs-feedback-line ${result}`} role="status">
          {result === "right" ? `Correct: ${m} × 334 = ${target.toFixed(0)} kJ.` : `Not yet. Multiply the mass by 334 kJ/kg.`}
        </p>
      )}
      <button className="cs-link cs-link--dark" onClick={() => { setN((x) => x + 1); setAnswer(""); setResult(null); }}>New challenge <ArrowRight size={13} aria-hidden="true" /></button>
    </article>
  );
}

function MaterialMatching() {
  const [picks, setPicks] = useState({});
  const [checked, setChecked] = useState(false);
  const score = useMemo(() => matching.filter((m) => picks[m.prompt] === m.answer).length, [picks]);
  return (
    <article className="cs-card cs-activity">
      <span className="cs-overline cs-overline--dark">Material matching · from the dataset</span>
      <h4>Match each property to a material</h4>
      <div className="cs-match">
        {matching.map((m) => (
          <label key={m.prompt}>
            <span>{m.prompt}</span>
            <select value={picks[m.prompt] ?? ""} onChange={(e) => { setPicks((p) => ({ ...p, [m.prompt]: e.target.value })); setChecked(false); }} className={checked ? (picks[m.prompt] === m.answer ? "is-right" : "is-wrong") : ""}>
              <option value="">Choose…</option>
              {matchOptions.map((o) => <option key={o}>{o}</option>)}
            </select>
          </label>
        ))}
      </div>
      <div className="cs-path-actions">
        <button className="cs-btn cs-btn--dark" onClick={() => setChecked(true)}>Check matches</button>
        {checked && <span className="cs-mono" role="status">{score} / {matching.length} correct</span>}
      </div>
    </article>
  );
}

function Vocabulary() {
  const [flipped, setFlipped] = useState(new Set());
  const toggle = (w) => setFlipped((s) => { const n = new Set(s); n.has(w) ? n.delete(w) : n.add(w); return n; });
  return (
    <article className="cs-card cs-activity cs-activity--wide">
      <span className="cs-overline cs-overline--dark">Scientific vocabulary · tap to reveal</span>
      <div className="cs-vocab">
        {vocabulary.map(([word, def]) => (
          <button key={word} className={flipped.has(word) ? "is-flipped" : ""} aria-pressed={flipped.has(word)} onClick={() => toggle(word)}>
            <b>{word}</b>
            <span>{flipped.has(word) ? def : "Reveal definition"}</span>
          </button>
        ))}
      </div>
    </article>
  );
}
