import React, { useState } from "react";
import SectionTitle from "../components/SectionTitle";
import Modal from "../components/Modal";
import { characters } from "../data/mockData";
export default function Characters({search}) {
  const [active,setActive]=useState(null);
  const list=characters.filter(c=>`${c.name} ${c.role} ${c.element}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="page-wrap"><SectionTitle eyebrow="FRIENDS & FAMILY" title="The people of this story" description="Meet the characters who bring warmth, courage, and a little mischief to the winter world."/><div className="character-grid">{list.map(c=><button className="character-card" key={c.id} onClick={()=>setActive(c)}><div className="character-avatar" style={{"--char":c.color}}>{c.symbol}</div><span className="eyebrow">{c.element}</span><h3>{c.name}</h3><p>{c.role}</p><div className="trait-line">{c.traits.slice(0,3).map(t=><span key={t}>{t}</span>)}</div></button>)}</div>
    <Modal open={!!active} onClose={()=>setActive(null)} title={active?.name}>{active&&<><div className="character-modal-top"><div className="character-avatar large" style={{"--char":active.color}}>{active.symbol}</div><div><span className="eyebrow">{active.role}</span><h3>{active.element}</h3></div></div><p>{active.bio}</p><blockquote>“{active.quote}”</blockquote><div className="trait-line">{active.traits.map(t=><span key={t}>{t}</span>)}</div></>}</Modal>
  </div>;
}
