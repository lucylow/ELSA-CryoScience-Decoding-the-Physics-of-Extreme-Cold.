import React, { useMemo, useState } from "react";
import { AlertTriangle, ChevronDown, Gauge, Ruler, Thermometer, Timer } from "lucide-react";
import SciChart from "../components/cryo/SciChart";
import DataTag from "../components/cryo/DataTag";
import ParticleField from "../components/cryo/ParticleField";
import { experimentRecords, materials } from "../data/scienceData";
import { interpolateModulus, lumpedCoolingProfile, thermalLengthChangeMm } from "../utils/cryoPhysics";

const DATA_MIN = -60;
const DATA_MAX = 40;
const landmarks = [
  { t: -196, label: "Liquid nitrogen boils" },
  { t: -78.5, label: "Dry ice sublimes" },
  { t: -89.2, label: "Coldest air recorded on Earth" },
  { t: -40, label: "−40 °C = −40 °F" },
  { t: 0, label: "Water freezes" },
];

const topics = [
  { title: "Low-temperature behaviour", text: "Cooling reduces atomic vibration. Most solids become stiffer and many polymers move toward their glassy state." },
  { title: "Thermal contraction", text: "Materials shrink as they cool (ΔL = α·L₀·ΔT). Mismatched contraction between joined materials creates stress." },
  { title: "Brittle fracture", text: "Body-centred-cubic steels can undergo a ductile-to-brittle transition; austenitic stainless and aluminium remain tough at cryogenic temperatures." },
  { title: "Phase transitions", text: "Gases liquefy, water freezes and some alloys change crystal structure, each with an associated latent heat." },
  { title: "Heat capacity", text: "Specific heat falls steeply as temperature drops (Debye T³ law at very low temperature), so cold objects warm quickly." },
  { title: "Thermal conductivity", text: "Pure metals often conduct heat better when cold; alloys, polymers and glasses generally conduct less." },
  { title: "Cryogenic insulation", text: "Vacuum, multilayer reflective foils and aerogels suppress conduction, convection and radiation into cold vessels." },
];

export default function CryoLab() {
  const [temp, setTemp] = useState(-40);
  const [materialId, setMaterialId] = useState(materials[25].id);
  const material = materials.find((m) => m.id === materialId) ?? materials[0];
  const inRange = temp >= DATA_MIN && temp <= DATA_MAX;
  const modulus = interpolateModulus(material.propertyCurve, temp);
  const baseModulus = interpolateModulus(material.propertyCurve, 20);
  const dL = thermalLengthChangeMm({ alphaMicroPerK: material.thermalExpansionMicrostrainK, lengthM: 1, fromC: 20, toC: temp });
  const cooling = useMemo(
    () => lumpedCoolingProfile({ densityKgM3: material.densityKgM3, specificHeatJkgK: material.specificHeatJkgK, ambientC: temp, startC: 20 }),
    [material, temp],
  );
  const related = useMemo(
    () => experimentRecords.filter((r) => Math.abs(r.temperatureC - temp) <= 5 && materials.find((m) => m.id === r.materialId)?.family === material.family),
    [temp, material],
  );
  const nearby = landmarks.reduce((a, b) => (Math.abs(b.t - temp) < Math.abs(a.t - temp) ? b : a));
  const thermoFill = ((temp + 196) / 236) * 100;

  return (
    <div className="page-wrap cs-page cs-cryo">
      <ParticleField count={22} />
      <div className="cs-page-head">
        <div>
          <span className="cs-overline">Cryogenic research chamber · 03</span>
          <h2 className="cs-display cs-display--light">The cryogenic laboratory</h2>
          <p>Choose an illustrative temperature and specimen. Dataset values exist only between {DATA_MIN} °C and {DATA_MAX} °C; outside that window nothing is extrapolated.</p>
        </div>
        <DataTag kind="synthetic" />
      </div>

      <section className="cs-cryo-console">
        <div className="cs-thermo" aria-hidden="true">
          <div className="cs-thermo-tube"><i style={{ height: `${thermoFill}%` }} /></div>
          <div className="cs-thermo-bulb" />
        </div>
        <div className="cs-cryo-controls">
          <label className="cs-range">
            <span>Selected temperature <b className="cs-mono cs-big">{temp} °C</b> <small className="cs-mono">{(temp + 273.15).toFixed(2)} K</small></span>
            <input type="range" min="-196" max="40" value={temp} onChange={(e) => setTemp(Number(e.target.value))} aria-describedby="cryo-landmark" />
          </label>
          <p id="cryo-landmark" className="cs-landmark">Nearest reference point: <b>{nearby.label}</b> ({nearby.t} °C)</p>
          <label className="cs-select">
            <span>Specimen material</span>
            <span className="cs-select-wrap">
              <select value={materialId} onChange={(e) => setMaterialId(e.target.value)}>
                {materials.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
              <ChevronDown size={14} aria-hidden="true" />
            </span>
          </label>
          {!inRange && (
            <div className="cs-warning" role="alert">
              <AlertTriangle size={16} aria-hidden="true" />
              <span><b>Outside the data range.</b> The dataset covers {DATA_MIN} °C to {DATA_MAX} °C. Stiffness is shown as unavailable rather than extrapolated; contraction assumes a constant α, which is a poor approximation at cryogenic temperatures.</span>
            </div>
          )}
        </div>
        <div className="cs-readout-grid">
          <Readout Icon={Gauge} label="Young's modulus" value={modulus != null ? modulus.toPrecision(4) : "No data"} unit={modulus != null ? "GPa" : ""} note={modulus != null && baseModulus ? `${(((modulus - baseModulus) / baseModulus) * 100).toFixed(2)}% vs 20 °C` : "Outside −60…40 °C"} missing={modulus == null} />
          <Readout Icon={Ruler} label="Length change · 1 m bar" value={dL.toFixed(3)} unit="mm" note={`α = ${material.thermalExpansionMicrostrainK} µm/(m·K), from 20 °C`} />
          <Readout Icon={Timer} label="Cooling time constant" value={cooling.tauMinutes.toFixed(1)} unit="min" note="10 mm slab, h = 25 W/(m²·K)" />
          <Readout Icon={Thermometer} label="Thermal conductivity" value={material.thermalConductivityWMK} unit="W/(m·K)" note="Room-temperature value only" />
        </div>
      </section>

      <div className="cs-split cs-split--even">
        <article className="cs-card cs-card--glass">
          <span className="cs-overline">Mechanical property versus temperature</span>
          <SciChart
            series={[{ name: material.name, color: "var(--cs-ice)", points: material.propertyCurve.map((p) => ({ x: p.temperatureC, y: p.youngsModulusGPa })) }]}
            xLabel="Temperature" xUnit="°C" yLabel="Young's modulus" yUnit="GPa" smooth
            marker={inRange ? { x: temp, y: modulus, label: `${temp} °C` } : null}
            caption="Synthetic demonstration curve. The marker appears only inside the data range."
          />
        </article>
        <article className="cs-card cs-card--glass">
          <span className="cs-overline">Cooling profile · temperature versus time</span>
          <SciChart
            series={[{ name: "Slab centre (lumped model)", color: "var(--cs-aurora)", points: cooling.points }]}
            xLabel="Time" xUnit="min" yLabel="Temperature" yUnit="°C" smooth
            yDomain={[Math.min(temp, 20) - 5, Math.max(temp, 20) + 5]}
            caption="T(t) = T∞ + (T₀ − T∞)·e^(−t/τ), τ = ρ·c·L / h. Lumped-capacitance model: valid only when the Biot number is small."
          />
        </article>
      </div>

      <article className="cs-card cs-card--glass">
        <div className="cs-card-head">
          <div>
            <span className="cs-overline">Applicable experiment records</span>
            <h3>{related.length} records within ±5 °C for {material.family}</h3>
          </div>
          <DataTag kind="synthetic" compact />
        </div>
        {related.length ? (
          <ul className="cs-record-chips">
            {related.slice(0, 12).map((r) => (
              <li key={r.id}><b className="cs-mono">{r.id}</b><span>{r.testType.replace(" demonstration", "")}</span><span className="cs-mono">{r.temperatureC} °C · {r.exposureCycles} cycles</span></li>
            ))}
          </ul>
        ) : (
          <p className="cs-empty cs-empty--dark">No demonstration records for this family near {temp} °C. Records span −40 °C to 20 °C.</p>
        )}
      </article>

      <div className="cs-section-head">
        <span className="cs-overline">Cryogenic research topics</span>
        <h3 className="cs-display cs-display--light">What changes in the cold</h3>
      </div>
      <div className="cs-topic-grid">
        {topics.map((t, i) => (
          <article key={t.title} className="cs-topic">
            <span className="cs-mono">{String(i + 1).padStart(2, "0")}</span>
            <h4>{t.title}</h4>
            <p>{t.text}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

function Readout({ Icon, label, value, unit, note, missing }) {
  return (
    <div className={`cs-readout ${missing ? "is-missing" : ""}`}>
      <span><Icon size={14} aria-hidden="true" /> {label}</span>
      <b className="cs-mono">{value} <small>{unit}</small></b>
      <small>{note}</small>
    </div>
  );
}
