import React, { useState } from "react";
import { ArrowRight, MapPin } from "lucide-react";
import CrystalPalace from "../components/cryo/CrystalPalace";
import ParticleField from "../components/cryo/ParticleField";
import { campusRooms } from "../data/cryoContent";

export default function CrystalCampus({ setPage, search = "" }) {
  const [activeId, setActiveId] = useState(campusRooms[1].id);
  const active = campusRooms.find((r) => r.id === activeId) ?? campusRooms[0];
  const q = search.toLowerCase();
  const list = campusRooms.filter((r) => `${r.name} ${r.description} ${r.wing}`.toLowerCase().includes(q));

  return (
    <div className="page-wrap cs-page">
      <div className="cs-page-head">
        <div>
          <span className="cs-overline">Research campus · 10 laboratories</span>
          <h2 className="cs-display cs-display--light">The Crystal Palace Science Campus</h2>
          <p>An original crystalline research palace. Select a glowing room to learn what happens inside, then enter the laboratory.</p>
        </div>
      </div>

      <section className="cs-campus" aria-label="Interactive campus map">
        <div className="cs-campus-scene">
          <div className="cs-campus-sky" aria-hidden="true">
            <div className="cs-aurora cs-aurora--a" />
            <div className="cs-aurora cs-aurora--b" />
          </div>
          <CrystalPalace className="cs-campus-palace" />
          <ParticleField count={46} variant="snow" />
          {campusRooms.map((room) => (
            <button
              key={room.id}
              className={`cs-pin ${room.id === activeId ? "is-active" : ""}`}
              style={{ left: `${room.x}%`, top: `${room.y}%`, "--hue": room.hue }}
              onClick={() => setActiveId(room.id)}
              onDoubleClick={() => setPage(room.dest)}
              aria-pressed={room.id === activeId}
              aria-label={`${room.n}: ${room.name}`}
            >
              <span className="cs-mono">{room.n}</span>
              <em>{room.short}</em>
            </button>
          ))}
        </div>

        <aside className="cs-campus-panel" aria-live="polite">
          <span className="cs-room-glyph" style={{ "--hue": active.hue }}>
            <active.Icon size={26} aria-hidden="true" />
          </span>
          <span className="cs-overline">
            <MapPin size={12} aria-hidden="true" /> Room {active.n} · {active.wing}
          </span>
          <h3>{active.name}</h3>
          <p>{active.description}</p>
          <button className="cs-btn cs-btn--primary" onClick={() => setPage(active.dest)}>
            Enter laboratory <ArrowRight size={16} aria-hidden="true" />
          </button>
        </aside>
      </section>

      <div className="cs-section-head">
        <span className="cs-overline">Directory</span>
        <h3 className="cs-display cs-display--light">Every laboratory</h3>
      </div>
      <div className="cs-room-grid">
        {list.map((room) => (
          <article key={room.id} className="cs-room" style={{ "--hue": room.hue }}>
            <div className="cs-room-art" aria-hidden="true">
              <span className="cs-room-art-ring" />
              <room.Icon size={30} />
              <b className="cs-mono">{room.n}</b>
            </div>
            <div className="cs-room-body">
              <span className="cs-overline">{room.wing}</span>
              <h4>{room.name}</h4>
              <p>{room.description}</p>
              <button className="cs-link" onClick={() => setPage(room.dest)}>
                Enter laboratory <ArrowRight size={14} aria-hidden="true" />
              </button>
            </div>
          </article>
        ))}
        {!list.length && <p className="cs-empty">No laboratories match “{search}”. Clear the search to see all ten rooms.</p>}
      </div>
    </div>
  );
}
