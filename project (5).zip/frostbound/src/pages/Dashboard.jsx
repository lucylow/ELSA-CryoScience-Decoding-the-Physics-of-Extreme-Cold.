import React from "react";
import { ArrowUpRight, Compass, Sparkles, Wind, ChevronRight } from "lucide-react";
import PalaceScene from "../components/PalaceScene";
import StatCard from "../components/StatCard";
import SectionTitle from "../components/SectionTitle";
import { mockStats, mockEvents, rooms } from "../data/mockData";
export default function Dashboard({setPage,onRoom}) {
  const icons=[<CastleIcon/>,<Sparkles/>,<Compass/>,<Wind/>];
  return <div className="page-wrap">
    <section className="welcome-row"><div><span className="eyebrow">WELCOME TO THE NORTH MOUNTAIN</span><h2>A little more <em>wonder</em> in your world.</h2><p>Step inside a palace sculpted from snow, light, and imagination.</p><button className="primary-btn" onClick={()=>setPage("palace")}>Explore the palace <ArrowUpRight size={16}/></button></div><div className="welcome-mark">❄</div></section>
    <PalaceScene/>
    <div className="stats-grid">{mockStats.map((s,i)=><StatCard key={s.label} {...s} icon={icons[i]}/>)}</div>
    <div className="dashboard-columns"><div><SectionTitle eyebrow="DISCOVER THE PALACE" title="A world of ice and light" description="A few favorite spaces to begin your journey." action={<button className="text-link" onClick={()=>setPage("palace")}>All rooms <ArrowUpRight size={14}/></button>}/><div className="featured-rooms">{rooms.slice(0,3).map(r=><button className="featured-room" key={r.id} onClick={()=>onRoom(r)}><span className="featured-icon">{r.icon}</span><span><b>{r.name}</b><small>{r.level} · {r.mood}</small></span><ChevronRight size={16}/></button>)}</div></div>
    <div className="schedule-card"><SectionTitle eyebrow="PALACE JOURNAL" title="Today's moments"/><div className="event-list">{mockEvents.map((e,i)=><div className="event" key={e.time}><span className="event-time">{e.time}</span><i/><div><b>{e.title}</b><small>{e.type}</small></div></div>)}</div><button className="subtle-btn" onClick={()=>setPage("story")}>View story timeline <ArrowUpRight size={14}/></button></div></div>
  </div>;
}
function CastleIcon(){return <span>♜</span>}
