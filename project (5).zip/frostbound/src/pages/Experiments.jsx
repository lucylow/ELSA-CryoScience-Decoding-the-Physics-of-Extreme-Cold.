import React, { useMemo, useState } from "react";
import { CheckCircle2, CircleDashed, Droplets, FlaskConical, Hammer, Microscope, Search, Snowflake, Thermometer, TriangleAlert } from "lucide-react";
import Modal from "../components/Modal";
import SciChart from "../components/cryo/SciChart";
import DataTag from "../components/cryo/DataTag";
import { experimentRecords, materials } from "../data/scienceData";
import { calculateIllustrativeFreezeThawIndex } from "../utils/scienceCalculations";

const byId = new Map(materials.map((m) => [m.id, m]));
const CATEGORY = {
  "Thermal conductivity demonstration": "Thermal testing",
  "Freeze–thaw exposure demonstration": "Freeze–thaw testing",
  "Moisture uptake demonstration": "Moisture testing",
};
const categories = [
  { id: "Mechanical testing", Icon: Hammer },
  { id: "Thermal testing", Icon: Thermometer },
  { id: "Moisture testing", Icon: Droplets },
  { id: "Freeze–thaw testing", Icon: Snowflake },
  { id: "Material characterization", Icon: Microscope },
];

function qualityOf(record, index) {
  const warnings = [];
  if (record.temperatureC > 15) warnings.push("Near-ambient temperature: limited cold-climate relevance");
  if (record.exposureCycles < 5 && record.testType.startsWith("Freeze")) warnings.push("Fewer than 5 cycles: exposure likely too short");
  const missing = ["Measurement uncertainty", "Operator & instrument metadata", ...(index % 4 === 0 ? ["Specimen conditioning record"] : [])];
  return { warnings, missing, status: warnings.length ? "Validation warning" : index % 4 === 0 ? "Missing information" : "Complete demonstration" };
}

const enriched = experimentRecords.map((r, i) => ({ ...r, category: CATEGORY[r.testType], material: byId.get(r.materialId), quality: qualityOf(r, i) }));

function measurements(record) {
  const m = record.material;
  if (record.category === "Thermal testing") {
    const dT = 20 - record.temperatureC;
    return {
      columns: ["Thickness (m)", "ΔT (K)", "Heat flux q (W/m²)"],
      rows: [0.05, 0.1, 0.15, 0.2, 0.25].map((L) => [L.toFixed(2), dT, ((m.thermalConductivityWMK * dT) / L).toFixed(1)]),
      chart: { x: "Thickness", xu: "m", y: "Heat flux", yu: "W/m²", points: [0.05, 0.1, 0.15, 0.2, 0.25].map((L) => ({ x: L, y: (m.thermalConductivityWMK * dT) / L })) },
      config: `Steady-state plate, warm side 20 °C, cold side ${record.temperatureC} °C, q = k·ΔT/L`,
    };
  }
  if (record.category === "Freeze–thaw testing") {
    const steps = [0.2, 0.4, 0.6, 0.8, 1].map((f) => Math.round(record.exposureCycles * f));
    return {
      columns: ["Cycles", "Saturation", "Illustrative index (0–100)"],
      rows: steps.map((c) => [c, "0.85", calculateIllustrativeFreezeThawIndex({ cycles: c, saturation: 0.85, materialSensitivity: m.moistureSensitivity })]),
      chart: { x: "Cycles", xu: "", y: "Exposure index", yu: "", points: steps.map((c) => ({ x: c, y: calculateIllustrativeFreezeThawIndex({ cycles: c, saturation: 0.85, materialSensitivity: m.moistureSensitivity }) })) },
      config: `${record.exposureCycles} cycles between ${record.temperatureC} °C and +5 °C, degree of saturation 0.85`,
    };
  }
  const ms = m.moistureSensitivity * 12;
  const hours = [0, 24, 48, 96, 168, 336];
  return {
    columns: ["Time (h)", "Mass gain (%)"],
    rows: hours.map((h) => [h, (ms * (1 - Math.exp(-h / 72))).toFixed(2)]),
    chart: { x: "Time", xu: "h", y: "Mass gain", yu: "%", points: hours.map((h) => ({ x: h, y: ms * (1 - Math.exp(-h / 72)) })) },
    config: `Immersion at ${Math.max(record.temperatureC, 2)} °C, M(t) = M∞·(1 − e^(−t/τ)), τ = 72 h`,
  };
}

export default function Experiments({ search: globalSearch = "" }) {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState(globalSearch);
  const [limit, setLimit] = useState(18);
  const [active, setActive] = useState(null);
  const counts = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, enriched.filter((r) => r.category === c.id).length])), []);
  const list = useMemo(
    () => enriched.filter((r) => (category === "All" || r.category === category) && `${r.id} ${r.material.name} ${r.testType}`.toLowerCase().includes(query.toLowerCase())),
    [category, query],
  );
  const detail = active ? measurements(active) : null;
  const emptyCategory = category !== "All" && counts[category] === 0;

  return (
    <div className="page-wrap cs-page">
      <div className="cs-page-head">
        <div>
          <span className="cs-overline cs-overline--dark">Experimental testing laboratory · 09</span>
          <h2 className="cs-display">Experimental research</h2>
          <p>Every record below is a generated demonstration. Open one to see its configuration, measurement table, uncertainty and data-quality flags.</p>
        </div>
        <DataTag kind="synthetic" label="SYNTHETIC DEMONSTRATION DATA" />
      </div>

      <div className="cs-cat-grid" role="group" aria-label="Test categories">
        <button className={`cs-cat ${category === "All" ? "is-active" : ""}`} aria-pressed={category === "All"} onClick={() => setCategory("All")}>
          <FlaskConical size={18} aria-hidden="true" /><b>All tests</b><span className="cs-mono">{enriched.length}</span>
        </button>
        {categories.map(({ id, Icon }) => (
          <button key={id} className={`cs-cat ${category === id ? "is-active" : ""}`} aria-pressed={category === id} onClick={() => setCategory(id)}>
            <Icon size={18} aria-hidden="true" /><b>{id}</b><span className="cs-mono">{counts[id] || "—"}</span>
          </button>
        ))}
      </div>

      <div className="cs-toolbar">
        <label className="cs-search">
          <Search size={15} aria-hidden="true" />
          <span className="sr-only">Search experiments</span>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by ID, material or test" />
        </label>
        <span className="cs-mono cs-count">{list.length} records</span>
        <div className="cs-legend-row">
          <span><CheckCircle2 size={13} className="ok" aria-hidden="true" /> Complete</span>
          <span><CircleDashed size={13} className="miss" aria-hidden="true" /> Missing info</span>
          <span><TriangleAlert size={13} className="warn" aria-hidden="true" /> Validation warning</span>
        </div>
      </div>

      {emptyCategory ? (
        <div className="cs-empty-card">
          <CircleDashed size={26} aria-hidden="true" />
          <h3>No {category.toLowerCase()} records yet</h3>
          <p>The demonstration dataset contains thermal, moisture and freeze–thaw records only. This section is ready for measured data once it exists — nothing has been invented to fill it.</p>
        </div>
      ) : (
        <div className="cs-exp-grid">
          {list.slice(0, limit).map((r) => (
            <button key={r.id} className="cs-exp" onClick={() => setActive(r)}>
              <span className="cs-exp-top">
                <span className="cs-mono">{r.id}</span>
                <StatusIcon status={r.quality.status} />
              </span>
              <b>{r.testType.replace(" demonstration", "")}</b>
              <span className="cs-exp-mat">{r.material.name}</span>
              <span className="cs-exp-meta">
                <span>{r.category}</span>
                <span className="cs-mono">{r.temperatureC} °C</span>
                <span className="cs-mono">{r.exposureCycles} cyc</span>
              </span>
              <DataTag kind="synthetic" label="Synthetic" compact />
            </button>
          ))}
        </div>
      )}
      {!emptyCategory && list.length > limit && (
        <button className="cs-btn cs-btn--outline cs-more" onClick={() => setLimit((l) => l + 18)}>Show more records</button>
      )}
      {!emptyCategory && !list.length && <p className="cs-empty cs-empty--dark">No experiments match “{query}”.</p>}

      <Modal open={!!active} onClose={() => setActive(null)} title={active ? `${active.id} · ${active.testType.replace(" demonstration", "")}` : ""} wide>
        {active && detail && (
          <div className="cs-exp-detail">
            <div className="cs-exp-flags">
              <DataTag kind="synthetic" label="SYNTHETIC DEMONSTRATION DATA" />
              <StatusIcon status={active.quality.status} withLabel />
            </div>
            <dl className="cs-detail-grid">
              <div><dt>Research objective</dt><dd>Demonstrate how {active.category.replace(" testing", "").toLowerCase()} behaviour of {active.material.family.toLowerCase()} depends on test conditions.</dd></div>
              <div><dt>Material</dt><dd>{active.material.name} <span className="cs-mono">({active.material.id})</span></dd></div>
              <div><dt>Test configuration</dt><dd>{detail.config}</dd></div>
              <div><dt>Input parameters</dt><dd className="cs-mono">T = {active.temperatureC} °C · cycles = {active.exposureCycles} · k = {active.material.thermalConductivityWMK} W/(m·K) · moisture = {active.material.moistureSensitivity}</dd></div>
            </dl>
            <div className="cs-exp-data">
              <table className="cs-table">
                <caption>Measurement table (generated)</caption>
                <thead><tr>{detail.columns.map((c) => <th key={c} scope="col">{c}</th>)}</tr></thead>
                <tbody>{detail.rows.map((row, i) => <tr key={i}>{row.map((v, j) => <td key={j} className="cs-mono">{v}</td>)}</tr>)}</tbody>
              </table>
              <SciChart tone="light" height={220} series={[{ name: active.id, color: "var(--cs-violet)", points: detail.chart.points }]} xLabel={detail.chart.x} xUnit={detail.chart.xu} yLabel={detail.chart.y} yUnit={detail.chart.yu} />
            </div>
            <dl className="cs-detail-grid">
              <div><dt>Observations</dt><dd>Values follow the governing model exactly — a signature of generated data. Real measurements would scatter around the trend.</dd></div>
              <div><dt>Uncertainty</dt><dd className="cs-missing-text">Not quantified. No repeat specimens, instrument calibration or error budget exists for synthetic records.</dd></div>
              <div><dt>Conclusions</dt><dd>Suitable for learning the workflow only. Not evidence about the material and not for design.</dd></div>
              <div><dt>Data quality</dt><dd>
                <ul className="cs-quality">
                  {active.quality.missing.map((m) => <li key={m} className="miss"><CircleDashed size={13} aria-hidden="true" /> Missing: {m}</li>)}
                  {active.quality.warnings.map((w) => <li key={w} className="warn"><TriangleAlert size={13} aria-hidden="true" /> {w}</li>)}
                  <li className="ok"><CheckCircle2 size={13} aria-hidden="true" /> Provenance labelled: {active.sourceDescription}</li>
                </ul>
              </dd></div>
            </dl>
          </div>
        )}
      </Modal>
    </div>
  );
}

function StatusIcon({ status, withLabel }) {
  const map = { "Complete demonstration": [CheckCircle2, "ok"], "Missing information": [CircleDashed, "miss"], "Validation warning": [TriangleAlert, "warn"] };
  const [Icon, cls] = map[status];
  return (
    <span className={`cs-status ${cls}`} title={status}>
      <Icon size={14} aria-hidden="true" />
      {withLabel ? status : <span className="sr-only">{status}</span>}
    </span>
  );
}
