import React, { useState } from "react";
import SectionTitle from "../components/SectionTitle";
import Modal from "../components/Modal";
import { gallery } from "../data/mockData";
export default function Gallery({search}) {
 const [filter,setFilter]=useState("All"); const [active,setActive]=useState(null);
 const cats=["All",...new Set(gallery.map(g=>g.category))];
 const list=gallery.filter(g=>(filter==="All"||g.category===filter)&&`${g.title} ${g.caption}`.toLowerCase().includes(search.toLowerCase()));
 return <div className="page-wrap"><SectionTitle eyebrow="A VISUAL NOTEBOOK" title="Gallery of winter wonders" description="Original CSS-generated scenes and concept cards — no film stills or official artwork."/><div className="filter-pills gallery-filters">{cats.map(c=><button key={c} className={filter===c?"selected":""} onClick={()=>setFilter(c)}>{c}</button>)}</div><div className="gallery-grid">{list.map(g=><button key={g.id} className="gallery-card" onClick={()=>setActive(g)}><div className={`gallery-art tone-${g.tone}`}><span>{g.category==="Magic"?"❄":g.category==="Architecture"?"♢":g.category==="Sky"?"✧":g.category==="Nature"?"❀":"☾"}</span><i/><b>{String(g.id).padStart(2,"0")}</b></div><div><span className="eyebrow">{g.category}</span><h3>{g.title}</h3><p>{g.caption}</p></div></button>)}</div><Modal open={!!active} onClose={()=>setActive(null)} title={active?.title}>{active&&<><div className={`gallery-art modal-gallery tone-${active.tone}`}><span>✧</span><i/></div><p>{active.caption}</p></>}</Modal></div>;
}
