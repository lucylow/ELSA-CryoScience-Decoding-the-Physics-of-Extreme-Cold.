import React, { useRef } from "react";
import { ArrowRight, Atom, BookOpen, Boxes, Castle, FlaskConical, Snowflake, ThermometerSnowflake } from "lucide-react";
import CryoEmblem from "../components/cryo/CryoEmblem";
import CrystalSnowflake from "../components/cryo/CrystalSnowflake";
import CrystalPalace from "../components/cryo/CrystalPalace";
import SnowflakeAtom from "../components/cryo/SnowflakeAtom";
import ParticleField from "../components/cryo/ParticleField";
import DataTag from "../components/cryo/DataTag";
import { experimentRecords, materialFamilies, materials, propertyPointCount } from "../data/scienceData";
import { inspirations } from "../data/cryoContent";

const modules = [
  { id: "campus", Icon: Castle, eyebrow: "The campus", title: "Crystal Palace Science Campus", text: "Ten laboratories inside one luminous research palace. Choose a room and step inside." },
  { id: "ice", Icon: Snowflake, eyebrow: "Ice physics", title: "Ice Physics Observatory", text: "Hexagonal lattices, hydrogen bonds, phase transitions, latent heat and snow crystal growth." },
  { id: "cryo", Icon: ThermometerSnowflake, eyebrow: "Cryogenics", title: "Cryogenic Laboratory", text: "Dial the temperature down to −196 °C and follow stiffness, contraction and cooling." },
  { id: "materials", Icon: Boxes, eyebrow: "Materials", title: "Materials Intelligence", text: "Twenty material families, side-by-side comparisons and transparent, exportable records." },
  { id: "experiments", Icon: FlaskConical, eyebrow: "Research", title: "Experimental Laboratory", text: "Test configurations, measurement tables, uncertainty and data-quality indicators." },
  { id: "academy", Icon: BookOpen, eyebrow: "Learning", title: "ELSA Science Academy", text: "Ten learning pathways, quizzes and equation challenges for every curious mind." },
];

const equations = [
  { eq: "Q = m · L", name: "Latent heat", text: "Energy Q needed to change the phase of mass m, where L is the latent heat (334 kJ/kg to melt ice)." },
  { eq: "Q̇ = k · A · ΔT / L", name: "Fourier’s law", text: "Heat flow through a layer of conductivity k, area A and thickness L across a temperature difference ΔT." },
  { eq: "ΔL = α · L₀ · ΔT", name: "Thermal contraction", text: "Length change of a bar of length L₀ with expansion coefficient α when cooled or heated by ΔT." },
];

export default function Home({ setPage }) {
  const heroRef = useRef(null);
  const onPointerMove = (event) => {
    const el = heroRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    el.style.setProperty("--px", ((event.clientX - rect.left) / rect.width - 0.5).toFixed(3));
    el.style.setProperty("--py", ((event.clientY - rect.top) / rect.height - 0.5).toFixed(3));
  };
  const stats = [
    { value: materials.length, label: "Demonstration materials", note: `${materialFamilies.length} families` },
    { value: propertyPointCount.toLocaleString("en-US"), label: "Temperature data points", note: "−60 to 40 °C" },
    { value: experimentRecords.length, label: "Experiment records", note: "Synthetic demonstrations" },
    { value: 10, label: "Research laboratories", note: "Across the crystal campus" },
  ];

  return (
    <div className="cs-home">
      <section ref={heroRef} className="cs-hero" onPointerMove={onPointerMove} aria-labelledby="cs-hero-title">
        <div className="cs-hero-sky" aria-hidden="true">
          <div className="cs-aurora cs-aurora--a" />
          <div className="cs-aurora cs-aurora--b" />
          <div className="cs-aurora cs-aurora--c" />
          <div className="cs-hero-grid" />
        </div>
        <div className="cs-hero-flake cs-parallax" style={{ "--depth": 26 }} aria-hidden="true">
          <CrystalSnowflake className="cs-spin" strokeWidth={1.6} />
        </div>
        <div className="cs-hero-palace cs-parallax" style={{ "--depth": 10 }}>
          <CrystalPalace />
        </div>
        <ParticleField count={40} />
        <div className="cs-hero-molecule cs-parallax" style={{ "--depth": 40 }} aria-hidden="true">
          <svg viewBox="0 0 120 90">
            <line x1="60" y1="38" x2="26" y2="66" />
            <line x1="60" y1="38" x2="94" y2="66" />
            <circle cx="60" cy="38" r="18" className="o" />
            <circle cx="26" cy="66" r="10" className="h" />
            <circle cx="94" cy="66" r="10" className="h" />
            <text x="60" y="43" textAnchor="middle">O</text>
          </svg>
          <span>H₂O · 104.5°</span>
        </div>

        <div className="cs-hero-copy">
          <span className="cs-kicker">
            <CryoEmblem size={22} /> Extreme low-temperature physics · Research academy
          </span>
          <h2 id="cs-hero-title" className="cs-hero-title">
            ELSA <em>CryoScience</em>
          </h2>
          <p className="cs-hero-sub">Decoding the Physics of Extreme Cold.</p>
          <p className="cs-hero-lede">
            Explore the extraordinary science behind ice, matter, temperature and the materials that shape our world.
          </p>
          <div className="cs-hero-actions">
            <button className="cs-btn cs-btn--primary" onClick={() => setPage("campus")}>
              Enter the laboratory <ArrowRight size={16} aria-hidden="true" />
            </button>
            <button className="cs-btn cs-btn--glass" onClick={() => setPage("ice")}>
              <Atom size={16} aria-hidden="true" /> Explore physics
            </button>
            <button className="cs-btn cs-btn--glass" onClick={() => setPage("materials")}>
              <Boxes size={16} aria-hidden="true" /> Discover materials
            </button>
          </div>
        </div>

        <aside className="cs-hero-morph" aria-label="From crystal to atom">
          <SnowflakeAtom />
          <div>
            <span className="cs-overline">From crystal to atom</span>
            <p>
              A snowflake&apos;s six-fold symmetry comes from the hexagonal lattice of water molecules — each an oxygen atom bonded to two hydrogens.
            </p>
          </div>
        </aside>
      </section>

      <section className="cs-pearl cs-home-band" aria-labelledby="cs-band-title">
        <div className="cs-band-head">
          <div>
            <span className="cs-overline cs-overline--dark">Where magic meets the science of matter</span>
            <h3 id="cs-band-title" className="cs-display">
              Physics is creative, elegant, powerful — <em>and it belongs to you.</em>
            </h3>
          </div>
          <DataTag kind="synthetic" label="Synthetic demonstration data, clearly labelled" />
        </div>

        <dl className="cs-stat-row">
          {stats.map((s) => (
            <div key={s.label}>
              <dt>{s.label}</dt>
              <dd className="cs-mono">{s.value}</dd>
              <small>{s.note}</small>
            </div>
          ))}
        </dl>

        <div className="cs-module-grid">
          {modules.map(({ id, Icon, eyebrow, title, text }, index) => (
            <button key={id} className="cs-module" onClick={() => setPage(id)}>
              <span className="cs-module-num cs-mono">{String(index + 1).padStart(2, "0")}</span>
              <span className="cs-module-icon">
                <Icon size={20} aria-hidden="true" />
              </span>
              <span className="cs-overline cs-overline--dark">{eyebrow}</span>
              <b>{title}</b>
              <span className="cs-module-text">{text}</span>
              <span className="cs-module-cta">
                Open <ArrowRight size={14} aria-hidden="true" />
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="cs-equations" aria-labelledby="cs-eq-title">
        <div className="cs-section-head">
          <span className="cs-overline">The language of cold</span>
          <h3 id="cs-eq-title" className="cs-display cs-display--light">Three equations to begin with</h3>
        </div>
        <div className="cs-eq-grid">
          {equations.map((e) => (
            <article key={e.name} className="cs-eq-card">
              <code className="cs-mono">{e.eq}</code>
              <b>{e.name}</b>
              <p>{e.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="cs-manifesto">
        <CrystalSnowflake className="cs-manifesto-flake" strokeWidth={1} />
        <blockquote>
          <p>Where imagination meets discovery. Where curiosity becomes science. Where the next generation of physicists belongs.</p>
        </blockquote>
        <ul className="cs-quote-chips">
          {inspirations.map((q) => (
            <li key={q}>{q}</li>
          ))}
        </ul>
        <button className="cs-btn cs-btn--primary" onClick={() => setPage("academy")}>
          Visit the Science Academy <ArrowRight size={16} aria-hidden="true" />
        </button>
      </section>
    </div>
  );
}
