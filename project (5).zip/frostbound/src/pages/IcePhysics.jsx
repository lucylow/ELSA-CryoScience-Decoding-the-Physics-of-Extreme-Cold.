import React, { useMemo, useState } from "react";
import { Atom, Flame, Hexagon, Layers, Snowflake } from "lucide-react";
import SciChart from "../components/cryo/SciChart";
import DataTag from "../components/cryo/DataTag";
import CrystalSnowflake from "../components/cryo/CrystalSnowflake";
import { HEATING_BREAKPOINTS, HEATING_TOTAL_KJ, WATER, heatingCurve, heatingState, snowHabit } from "../utils/cryoPhysics";

const tabs = [
  { id: "lattice", label: "Ice crystal explorer", Icon: Hexagon },
  { id: "phase", label: "Phase transitions", Icon: Atom },
  { id: "latent", label: "Latent heat", Icon: Flame },
  { id: "snow", label: "Snow science", Icon: Layers },
];

export default function IcePhysics({ initialTab = "lattice" }) {
  const [tab, setTab] = useState(initialTab);
  return (
    <div className="page-wrap cs-page">
      <div className="cs-page-head">
        <div>
          <span className="cs-overline cs-overline--dark">Ice physics observatory · 02</span>
          <h2 className="cs-display">The physics of ice</h2>
          <p>From the hexagonal lattice to the energy of melting. Constants are standard textbook values for water at about one atmosphere.</p>
        </div>
        <DataTag kind="reference" />
      </div>
      <div className="cs-tabs" role="tablist" aria-label="Ice physics modules">
        {tabs.map(({ id, label, Icon }) => (
          <button key={id} role="tab" id={`ice-tab-${id}`} aria-selected={tab === id} aria-controls={`ice-panel-${id}`} className={tab === id ? "is-active" : ""} onClick={() => setTab(id)}>
            <Icon size={15} aria-hidden="true" /> {label}
          </button>
        ))}
      </div>
      <div role="tabpanel" id={`ice-panel-${tab}`} aria-labelledby={`ice-tab-${tab}`} className="cs-tabpanel" key={tab}>
        {tab === "lattice" && <LatticeExplorer />}
        {tab === "phase" && <PhaseTransitions />}
        {tab === "latent" && <LatentHeat />}
        {tab === "snow" && <SnowScience />}
      </div>
    </div>
  );
}

/* ---------- Lattice ---------- */

const S = 30;
const HW = Math.sqrt(3) * S;
function buildLattice(cols, rows, ox, oy) {
  const verts = new Map();
  const edges = new Map();
  const key = (x, y) => `${Math.round(x)}:${Math.round(y)}`;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cx = ox + c * HW + (r % 2) * (HW / 2);
      const cy = oy + r * 1.5 * S;
      const pts = Array.from({ length: 6 }, (_, i) => {
        const a = (Math.PI / 3) * i - Math.PI / 2;
        return [cx + S * Math.cos(a), cy + S * Math.sin(a)];
      });
      pts.forEach((p) => verts.set(key(...p), p));
      pts.forEach((p, i) => {
        const q = pts[(i + 1) % 6];
        const k = [key(...p), key(...q)].sort().join("|");
        if (!edges.has(k)) edges.set(k, [p, q]);
      });
    }
  }
  return { verts: [...verts.values()], edges: [...edges.values()] };
}

const features = {
  oxygen: { title: "Oxygen atoms", text: "Each oxygen sits at a vertex of the hexagonal network and bonds to four neighbours in a tetrahedral arrangement. Neighbouring oxygens are about 2.76 Å apart." },
  covalent: { title: "Covalent O–H bonds", text: "Each water molecule keeps two strong covalent O–H bonds about 0.96–1.0 Å long. The H–O–H angle opens from 104.5° in the free molecule to nearly 109.5° in ice." },
  hbond: { title: "Hydrogen bonds", text: "A hydrogen covalently bound to one oxygen is attracted to the next (≈1.8 Å). These weaker bonds hold the open lattice together — the reason ice (≈917 kg/m³) floats on water (≈1000 kg/m³)." },
  ring: { title: "Hexagonal rings", text: "Ordinary ice is ice Ih: puckered six-membered rings stacked along the c-axis. This hexagonal symmetry is why snow crystals have six arms." },
  growth: { title: "Crystal growth", text: "Molecules attach preferentially at steps and edges. Whether the basal or prism faces grow faster depends on temperature and supersaturation, producing plates, columns or dendrites." },
  boundary: { title: "Grain boundary", text: "Where two crystals with different orientations meet, the lattice cannot match perfectly. Grain boundaries host disorder, impurities and are pathways for creep and fracture." },
  defect: { title: "Point defect (vacancy)", text: "A missing molecule is a vacancy. Ice also hosts Bjerrum and ionic defects that violate the ice rules and enable electrical conductivity and mechanical relaxation." },
};

function LatticeExplorer() {
  const [active, setActive] = useState("hbond");
  const left = useMemo(() => buildLattice(4, 5, 70, 60), []);
  const right = useMemo(() => buildLattice(4, 5, 70, 60), []);
  const vacancy = left.verts[17];
  const growthFront = left.verts.filter((v) => v[1] < 40);
  const cls = (id) => (active === id ? "is-on" : "");

  const draw = (lat, skipVacancy) => (
    <>
      {lat.edges.map(([p, q], i) => {
        const near = i % 2 ? p : q;
        const far = i % 2 ? q : p;
        const h = [near[0] + (far[0] - near[0]) * 0.33, near[1] + (far[1] - near[1]) * 0.33];
        const isVac = skipVacancy && [p, q].some((v) => v === vacancy);
        if (isVac) return null;
        return (
          <g key={i}>
            <line x1={near[0]} y1={near[1]} x2={h[0]} y2={h[1]} className={`lt-cov ${cls("covalent")}`} />
            <line x1={h[0]} y1={h[1]} x2={far[0]} y2={far[1]} className={`lt-hb ${cls("hbond")}`} />
            <circle cx={h[0]} cy={h[1]} r="3.6" className="lt-h" />
          </g>
        );
      })}
      {lat.verts.map((v, i) => (skipVacancy && v === vacancy ? null : <circle key={i} cx={v[0]} cy={v[1]} r="7" className={`lt-o ${cls("oxygen")}`} />))}
    </>
  );

  return (
    <div className="cs-split">
      <article className="cs-card cs-card--dark cs-lattice-card">
        <svg viewBox="0 0 760 400" role="img" aria-label="Schematic basal-plane projection of hexagonal ice Ih showing oxygen atoms, hydrogen atoms, covalent bonds, hydrogen bonds, a grain boundary and a vacancy">
          <defs>
            <clipPath id="lt-left"><rect x="0" y="0" width="372" height="400" /></clipPath>
            <clipPath id="lt-right"><rect x="392" y="0" width="368" height="400" /></clipPath>
          </defs>
          <g clipPath="url(#lt-left)">{draw(left, true)}</g>
          <g clipPath="url(#lt-right)" transform="translate(392 0) rotate(17 190 200)">{draw(right, false)}</g>
          <polygon
            className={`lt-ring ${cls("ring")}`}
            points={Array.from({ length: 6 }, (_, i) => {
              const a = (Math.PI / 3) * i - Math.PI / 2;
              return `${70 + HW + S * Math.cos(a)},${60 + 3 * S + S * Math.sin(a)}`;
            }).join(" ")}
          />
          <line x1="382" y1="10" x2="382" y2="390" className={`lt-gb ${cls("boundary")}`} />
          <circle cx={vacancy[0]} cy={vacancy[1]} r="13" className={`lt-vac ${cls("defect")}`} />
          {growthFront.map((v, i) => (
            <circle key={i} cx={v[0]} cy={v[1]} r="11" className={`lt-grow ${cls("growth")}`} />
          ))}
        </svg>
        <p className="cs-caption">Schematic basal-plane projection of ice Ih, roughly to scale. Hydrogen positions are illustrative — real ice is proton-disordered while obeying the ice rules.</p>
      </article>
      <aside className="cs-card cs-feature-panel">
        <span className="cs-overline cs-overline--dark">Select a structure</span>
        <div className="cs-chip-list" role="group" aria-label="Lattice features">
          {Object.entries(features).map(([id, f]) => (
            <button key={id} className={active === id ? "is-active" : ""} aria-pressed={active === id} onClick={() => setActive(id)}>
              {f.title}
            </button>
          ))}
        </div>
        <h3>{features[active].title}</h3>
        <p>{features[active].text}</p>
        <dl className="cs-facts">
          <div><dt>Crystal system</dt><dd>Hexagonal (Ih)</dd></div>
          <div><dt>O···O distance</dt><dd className="cs-mono">2.76 Å</dd></div>
          <div><dt>Density at 0 °C</dt><dd className="cs-mono">917 kg/m³</dd></div>
          <div><dt>Coordination</dt><dd>4 (tetrahedral)</dd></div>
        </dl>
      </aside>
    </div>
  );
}

/* ---------- Phase transitions ---------- */

const N = 30;
function PhaseTransitions() {
  const [q, setQ] = useState(260);
  const state = heatingState(q);
  const nVap = Math.round(N * state.vapour);
  const nLiq = Math.round(N * state.liquid);
  const molecules = Array.from({ length: N }, (_, i) => ({
    i,
    kind: i < nVap ? "vapour" : i < nVap + nLiq ? "liquid" : "solid",
  }));
  const amp = Math.max(0.6, Math.min(4, (state.temperatureC + 60) / 40));

  return (
    <div className="cs-split">
      <article className="cs-card cs-card--dark cs-phase-card">
        <div className="cs-phase-stage" style={{ "--amp": `${amp}px` }} aria-hidden="true">
          {molecules.map(({ i, kind }) => {
            const col = i % 6;
            const row = Math.floor(i / 6);
            const lattice = { left: 18 + col * 13 + (row % 2) * 6.5, top: 46 + row * 10 };
            const liquid = { left: 10 + ((i * 37) % 80), top: 64 + ((i * 17) % 26) };
            const vapour = { left: 6 + ((i * 29) % 88), top: 6 + ((i * 23) % 34) };
            const pos = kind === "solid" ? lattice : kind === "liquid" ? liquid : vapour;
            return <span key={i} className={`cs-mol cs-mol--${kind}`} style={{ left: `${pos.left}%`, top: `${pos.top}%`, "--d": `${-(i % 7) * 0.3}s` }} />;
          })}
          <div className="cs-phase-legend">
            <span><i className="solid" /> Solid (ordered lattice)</span>
            <span><i className="liquid" /> Liquid</span>
            <span><i className="vapour" /> Vapour</span>
          </div>
        </div>
        <label className="cs-range">
          <span>Energy added to 1 kg starting at −40 °C <b className="cs-mono">{Math.round(q)} kJ</b></span>
          <input type="range" min="0" max={Math.round(HEATING_TOTAL_KJ)} value={q} onChange={(e) => setQ(Number(e.target.value))} />
        </label>
      </article>
      <aside className="cs-card cs-feature-panel">
        <span className="cs-overline cs-overline--dark">Current state</span>
        <h3>{state.phase}</h3>
        <div className="cs-readouts">
          <div><span>Temperature</span><b className="cs-mono">{state.temperatureC.toFixed(1)} °C</b></div>
          <div><span>Liquid fraction</span><b className="cs-mono">{Math.round(state.liquid * 100)}%</b></div>
          <div><span>Vapour fraction</span><b className="cs-mono">{Math.round(state.vapour * 100)}%</b></div>
        </div>
        <p>
          Temperature measures the average kinetic energy of molecules. In a solid they vibrate about fixed lattice sites; at 0 °C added energy breaks hydrogen bonds instead of raising temperature; at 100 °C molecules gain enough energy to escape into the vapour.
        </p>
        <code className="cs-eq cs-mono">{state.equation}</code>
        <DataTag kind="model" label="Idealised 1 atm model · no supercooling" compact />
      </aside>
    </div>
  );
}

/* ---------- Latent heat ---------- */

function LatentHeat() {
  const [q, setQ] = useState(600);
  const [mass, setMass] = useState(1);
  const state = heatingState(q);
  const bands = [
    { x1: HEATING_BREAKPOINTS[1], x2: HEATING_BREAKPOINTS[2], label: "Melting · L_f" },
    { x1: HEATING_BREAKPOINTS[3], x2: HEATING_BREAKPOINTS[4], label: "Boiling · L_v" },
  ];
  const vars = [
    ["Q", "Heat energy transferred", "kJ"],
    ["m", "Mass of the substance", "kg"],
    ["L", "Specific latent heat (fusion 334, vaporisation 2257)", "kJ/kg"],
    ["c", "Specific heat capacity (ice 2.09, water 4.18, steam 2.01)", "kJ/(kg·K)"],
    ["ΔT", "Temperature change", "K"],
  ];
  return (
    <div className="cs-stack">
      <article className="cs-card">
        <div className="cs-card-head">
          <div>
            <span className="cs-overline cs-overline--dark">Heating curve of water</span>
            <h3>Temperature versus energy input</h3>
          </div>
          <DataTag kind="reference" compact />
        </div>
        <SciChart
          tone="light"
          series={[{ name: "1 kg of H₂O", color: "var(--cs-glacier)", points: heatingCurve }]}
          xLabel="Energy input per kilogram"
          xUnit="kJ/kg"
          yLabel="Temperature"
          yUnit="°C"
          bands={bands}
          marker={{ x: q, y: state.temperatureC, label: state.phase }}
          xDomain={[0, Math.round(HEATING_TOTAL_KJ)]}
          yDomain={[-50, 150]}
          height={300}
          caption="Flat plateaus are phase changes: energy breaks bonds instead of raising temperature. The boiling plateau is about 6.8 times longer than the melting plateau."
        />
        <label className="cs-range cs-range--light">
          <span>Energy input <b className="cs-mono">{Math.round(q)} kJ/kg</b></span>
          <input type="range" min="0" max={Math.round(HEATING_TOTAL_KJ)} value={q} onChange={(e) => setQ(Number(e.target.value))} />
        </label>
      </article>
      <div className="cs-split cs-split--even">
        <article className="cs-card">
          <span className="cs-overline cs-overline--dark">The equations</span>
          <div className="cs-eq-pair">
            <code className="cs-eq cs-mono">Q = m · L</code>
            <code className="cs-eq cs-mono">Q = m · c · ΔT</code>
          </div>
          <dl className="cs-vars">
            {vars.map(([sym, desc, unit]) => (
              <div key={sym}>
                <dt className="cs-mono">{sym}</dt>
                <dd>{desc} <small>{unit}</small></dd>
              </div>
            ))}
          </dl>
        </article>
        <article className="cs-card cs-card--dark">
          <span className="cs-overline">Try it · melt ice at 0 °C</span>
          <label className="cs-range">
            <span>Mass of ice <b className="cs-mono">{mass.toFixed(1)} kg</b></span>
            <input type="range" min="0.1" max="10" step="0.1" value={mass} onChange={(e) => setMass(Number(e.target.value))} />
          </label>
          <code className="cs-eq cs-mono">Q = {mass.toFixed(1)} kg × {WATER.latentFusion} kJ/kg = {(mass * WATER.latentFusion).toFixed(0)} kJ</code>
          <p className="cs-muted-light">That is roughly the energy to heat the same mass of liquid water by {((WATER.latentFusion) / WATER.cWater).toFixed(0)} °C — melting is energetically expensive.</p>
        </article>
      </div>
    </div>
  );
}

/* ---------- Snow science ---------- */

const densities = [
  { label: "New snow", min: 50, max: 200 },
  { label: "Settled snow", min: 200, max: 300 },
  { label: "Wind-packed snow", min: 350, max: 400 },
  { label: "Firn", min: 400, max: 830 },
  { label: "Glacier ice", min: 830, max: 917 },
  { label: "Liquid water (ref.)", min: 1000, max: 1000 },
];
const snowpack = [
  { name: "New snow", depth: 18, cls: "l1", t: -14 },
  { name: "Wind slab", depth: 22, cls: "l2", t: -10 },
  { name: "Rounded grains", depth: 30, cls: "l3", t: -6 },
  { name: "Faceted crystals / depth hoar", depth: 30, cls: "l4", t: -2 },
];

function SnowScience() {
  const [temp, setTemp] = useState(-15);
  const habit = snowHabit(temp);
  let depth = 0;
  return (
    <div className="cs-stack">
      <div className="cs-split">
        <article className="cs-card cs-card--dark cs-snowlab">
          <div className="cs-snowlab-crystal" aria-hidden="true">
            <CrystalSnowflake className={`cs-habit cs-habit--${habit.habit.split(" ")[0].toLowerCase()}`} strokeWidth={2} />
          </div>
          <div>
            <span className="cs-overline">Snow crystal growth · Nakaya diagram (simplified)</span>
            <h3>{habit.habit}</h3>
            <p>{habit.detail}</p>
            <label className="cs-range">
              <span>Air temperature <b className="cs-mono">{temp} °C</b></span>
              <input type="range" min="-30" max="2" value={temp} onChange={(e) => setTemp(Number(e.target.value))} />
            </label>
          </div>
        </article>
        <article className="cs-card">
          <span className="cs-overline cs-overline--dark">Density comparison</span>
          <h3>From fresh snow to glacier ice</h3>
          <ul className="cs-ranges" aria-label="Typical density ranges">
            {densities.map((d) => (
              <li key={d.label}>
                <span>{d.label}</span>
                <span className="cs-ranges-track">
                  <i style={{ left: `${(d.min / 1000) * 100}%`, width: `${Math.max(1, ((d.max - d.min) / 1000) * 100)}%` }} />
                </span>
                <b className="cs-mono">{d.min === d.max ? d.min : `${d.min}–${d.max}`} <small>kg/m³</small></b>
              </li>
            ))}
          </ul>
          <p className="cs-caption cs-caption--dark">Typical literature ranges (e.g. Paterson, The Physics of Glaciers). Compaction expels air: sintering and pressure turn snow into firn and finally ice.</p>
        </article>
      </div>
      <article className="cs-card">
        <div className="cs-card-head">
          <div>
            <span className="cs-overline cs-overline--dark">Layered snowpack</span>
            <h3>Structure and temperature profile</h3>
          </div>
          <DataTag kind="model" label="Illustrative profile" compact />
        </div>
        <div className="cs-snowpack">
          <div className="cs-snowpack-layers">
            {snowpack.map((l) => (
              <div key={l.name} className={`cs-layer ${l.cls}`} style={{ flexBasis: `${l.depth}%` }}>
                <b>{l.name}</b>
                <span className="cs-mono">{l.t} °C</span>
              </div>
            ))}
            <div className="cs-layer ground"><b>Ground</b><span className="cs-mono">≈ 0 °C</span></div>
          </div>
          <svg className="cs-snowpack-profile" viewBox="0 0 220 300" role="img" aria-label="Temperature rises from about −18 °C at the surface to about 0 °C at the ground">
            <line x1="20" y1="10" x2="20" y2="280" className="axis" />
            <line x1="20" y1="280" x2="210" y2="280" className="axis" />
            <polyline
              points={[[-18, 0], ...snowpack.map((l) => { depth += l.depth; return [l.t, depth]; }), [0, 100]].map(([t, d]) => `${20 + ((t + 20) / 20) * 180},${10 + (Math.min(d, 100) / 100) * 270}`).join(" ")}
              className="line"
            />
            <text x="22" y="296">−20 °C</text>
            <text x="186" y="296">0 °C</text>
            <text x="28" y="22">surface</text>
          </svg>
        </div>
        <p className="cs-caption cs-caption--dark">A strong temperature gradient (warm ground, cold surface) drives vapour upward and grows faceted crystals and depth hoar — weak layers important in avalanche science.</p>
      </article>
    </div>
  );
}
