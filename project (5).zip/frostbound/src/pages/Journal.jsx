import React, { useState } from "react";
import SectionTitle from "../components/SectionTitle";
export default function Journal({notes,setNotes}) {
 const [draft,setDraft]=useState("");
 const add=()=>{if(draft.trim()){setNotes(old=>[{id:Date.now(),text:draft.trim(),date:new Date().toLocaleDateString()},...old]);setDraft("");}};
 return <div className="page-wrap"><SectionTitle eyebrow="PRIVATE PALACE NOTES" title="Explorer's journal" description="Save your observations, favorite details, and little ideas for future visits."/><div className="journal-compose"><div className="journal-mark">✎</div><div><textarea value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Write a note about a room, a spell, or a story moment..."/><div className="compose-foot"><small>Your notes are stored in this browser.</small><button className="primary-btn" onClick={add} disabled={!draft.trim()}>Add to journal</button></div></div></div><div className="journal-list">{notes.map(n=><article key={n.id}><span className="eyebrow">{n.date}</span><p>{n.text}</p><button onClick={()=>setNotes(old=>old.filter(x=>x.id!==n.id))}>Remove note</button></article>)}{!notes.length&&<div className="empty-state"><span>❄</span><h3>Your journal is waiting</h3><p>Write your first palace note above.</p></div>}</div></div>;
}
