import React, { useState } from "react";
import { Sparkles, WandSparkles, RotateCcw } from "lucide-react";
import SectionTitle from "../components/SectionTitle";
import { spells } from "../data/mockData";
export default function Magic() {
  const [active,setActive]=useState(spells[0]); const [energy,setEnergy]=useState(68); const [cast,setCast]=useState(0);
  return <div className="page-wrap"><SectionTitle eyebrow="ELSA'S WINTER MAGIC" title="The spellbook" description="A playful collection of fictional spell concepts inspired by the visual language of ice and snow."/>
    <div className="magic-layout"><div className="spell-list">{spells.map(s=><button key={s.id} className={`spell-row ${active.id===s.id?"active":""}`} onClick={()=>setActive(s)}><span className="spell-symbol" style={{"--spell":s.color}}>✧</span><span><b>{s.name}</b><small>{s.type} · {s.difficulty}</small></span><span className="spell-arrow">↗</span></button>)}</div>
    <div className="spell-stage"><div className="spell-orbit orbit-a"/><div className="spell-orbit orbit-b"/><div className="spell-core" style={{"--spell":active.color}}><span>{active.id==="snowflake"?"❄":active.id==="aurora"?"✧":active.id==="frost-wind"?"〰":"✦"}</span></div><span className="stage-kicker">SELECTED SPELL</span><h3>{active.name}</h3><p>{active.description}</p><div className="spell-meta"><span>{active.type}</span><span>{active.difficulty}</span></div><button className="primary-btn" onClick={()=>setCast(c=>c+1)}><WandSparkles size={16}/> Cast a practice spell</button>{cast>0&&<div className="cast-feedback">✧ {active.effect} <small>Practice casts: {cast}</small></div>}</div></div>
    <div className="energy-card"><div><span className="eyebrow">MAGIC BALANCE</span><h3>Keep your magic in harmony</h3><p>A decorative practice meter for this interactive demo.</p></div><div className="energy-control"><b>{energy}%</b><input type="range" min="0" max="100" value={energy} onChange={e=>setEnergy(Number(e.target.value))}/><button className="icon-btn" onClick={()=>setEnergy(68)}><RotateCcw size={16}/></button></div></div>
  </div>;
}
