import React, { useMemo, useState } from "react";
import { Check, ChevronDown, Database, FileJson2, Search } from "lucide-react";
import { experimentRecords, materialFamilies, materials } from "../data/scienceData";
import SciChart from "../components/cryo/SciChart";
import BarChart from "../components/cryo/BarChart";
import DataTag from "../components/cryo/DataTag";
import MaterialGlyph, { classLabels, materialClass } from "../components/cryo/MaterialGlyph";

function downloadBlob(name, type, content) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  URL.revokeObjectURL(url);
}

const metrics = {
  thermalConductivityWMK: { label: "Thermal conductivity", unit: "W/(m·K)", log: true },
  youngsModulusGPa: { label: "Young's modulus", unit: "GPa", log: true },
  densityKgM3: { label: "Density", unit: "kg/m³", log: true },
  tensileStrengthMPa: { label: "Tensile strength", unit: "MPa", log: true },
  thermalExpansionMicrostrainK: { label: "Thermal expansion", unit: "µm/(m·K)", log: false },
  embodiedCarbonKgCO2eKg: { label: "Embodied carbon indicator", unit: "kgCO₂e/kg", log: false },
};

const availability = [
  { property: "Young's modulus", status: "synthetic", note: "11 points, −60 to 40 °C" },
  { property: "Thermal conductivity", status: "missing", note: "Room temperature only" },
  { property: "Tensile strength", status: "missing", note: "Room temperature only" },
  { property: "Thermal expansion", status: "missing", note: "Single constant α" },
  { property: "Fracture toughness", status: "missing", note: "Not in dataset" },
];

const familyAverage = (family, key) => {
  const list = materials.filter((m) => m.family === family);
  return list.reduce((s, m) => s + m[key], 0) / list.length;
};

export default function MaterialsExplorer({ search: globalSearch = "", initialMetric = "thermalConductivityWMK" }) {
  const [search, setSearch] = useState(globalSearch);
  const [family, setFamily] = useState("All families");
  const [selectedId, setSelectedId] = useState(materials[0].id);
  const [comparisonId, setComparisonId] = useState(materials[25].id);
  const [metric, setMetric] = useState(initialMetric);
  const [notice, setNotice] = useState("");
  const filtered = useMemo(
    () => materials.filter((m) => (family === "All families" || m.family === family) && `${m.id} ${m.name} ${m.family}`.toLowerCase().includes(search.toLowerCase())),
    [family, search],
  );
  const selected = materials.find((m) => m.id === selectedId) ?? filtered[0] ?? materials[0];
  const comparison = comparisonId === selected.id ? null : materials.find((m) => m.id === comparisonId);
  const relatedCount = experimentRecords.filter((r) => r.materialId === selected.id).length;
  const gallery = useMemo(() => materialFamilies.map((f) => ({ family: f, count: materials.filter((m) => m.family === f).length })), []);
  const barItems = useMemo(
    () =>
      materialFamilies
        .map((f) => ({ label: f, value: Number(familyAverage(f, metric).toPrecision(3)), highlight: f === selected.family, color: f === selected.family ? "var(--cs-violet)" : "var(--cs-glacier)" }))
        .sort((a, b) => b.value - a.value),
    [metric, selected.family],
  );

  const selectMaterial = (m) => { setSelectedId(m.id); setNotice(""); };
  const exportJson = () => { downloadBlob(`${selected.id.toLowerCase()}-demo-record.json`, "application/json", JSON.stringify(selected, null, 2)); setNotice("JSON record exported with synthetic-data metadata."); };
  const exportCsv = () => {
    const rows = ["temperature_c,youngs_modulus_gpa,data_classification,material_id", ...selected.propertyCurve.map((p) => `${p.temperatureC},${p.youngsModulusGPa},${selected.dataClassification},${selected.id}`)];
    downloadBlob(`${selected.id.toLowerCase()}-curve.csv`, "text/csv;charset=utf-8", rows.join("\n"));
    setNotice("CSV curve exported with units and evidence category.");
  };

  const series = [{ id: "a", name: selected.name, color: "var(--cs-glacier)", points: selected.propertyCurve.map((p) => ({ x: p.temperatureC, y: p.youngsModulusGPa })) }];
  if (comparison) series.push({ id: "b", name: comparison.name, color: "var(--cs-violet)", dashed: true, points: comparison.propertyCurve.map((p) => ({ x: p.temperatureC, y: p.youngsModulusGPa })) });

  const rows = [
    ["Density", "densityKgM3", "kg/m³"],
    ["Young's modulus", "youngsModulusGPa", "GPa"],
    ["Tensile strength", "tensileStrengthMPa", "MPa"],
    ["Thermal conductivity", "thermalConductivityWMK", "W/(m·K)"],
    ["Specific heat", "specificHeatJkgK", "J/(kg·K)"],
    ["Thermal expansion", "thermalExpansionMicrostrainK", "µm/(m·K)"],
    ["Moisture sensitivity", "moistureSensitivity", "index 0–1"],
    ["Embodied carbon indicator", "embodiedCarbonKgCO2eKg", "kgCO₂e/kg"],
  ];

  return (
    <div className="page-wrap cs-page">
      <div className="cs-page-head">
        <div>
          <span className="cs-overline cs-overline--dark">Materials intelligence laboratory · 01</span>
          <h2 className="cs-display">Materials intelligence</h2>
          <p>Structured demonstration records with a transparent evidence category on every value.</p>
        </div>
        <span className="cs-count-pill"><Database size={15} aria-hidden="true" />{materials.length} records · {materialFamilies.length} families</span>
      </div>

      <div className="cs-family-strip" role="group" aria-label="Filter by material family">
        <button className={`cs-family ${family === "All families" ? "is-active" : ""}`} aria-pressed={family === "All families"} onClick={() => setFamily("All families")}>
          <span className="cs-family-all" aria-hidden="true">All</span>
          <b>All families</b>
          <small className="cs-mono">{materials.length}</small>
        </button>
        {gallery.map((g) => (
          <button key={g.family} className={`cs-family ${family === g.family ? "is-active" : ""}`} aria-pressed={family === g.family} onClick={() => setFamily(g.family)}>
            <MaterialGlyph family={g.family} size={44} />
            <b>{g.family}</b>
            <small>{classLabels[materialClass(g.family)]} · <span className="cs-mono">{g.count}</span></small>
          </button>
        ))}
      </div>

      <div className="materials-layout">
        <aside className="materials-browser science-panel">
          <div className="materials-browser-head"><span className="science-overline">CATALOG</span><b>{filtered.length} results</b></div>
          <label className="science-input-wrap"><Search size={15} aria-hidden="true" /><span className="sr-only">Search materials</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or ID" /></label>
          <div className="material-record-list">
            {filtered.map((m) => (
              <button key={m.id} className={`material-record ${selected.id === m.id ? "selected" : ""}`} onClick={() => selectMaterial(m)}>
                <MaterialGlyph family={m.family} size={30} />
                <span><b>{m.name}</b><small>{m.id} · {m.family}</small></span>
                {selected.id === m.id && <Check size={15} aria-hidden="true" />}
              </button>
            ))}
            {filtered.length === 0 && <p className="science-empty-state">No materials match these filters.</p>}
          </div>
        </aside>

        <section className="material-detail-column">
          <article className="cs-card cs-mat-hero">
            <MaterialGlyph family={selected.family} size={120} className="cs-mat-micro" label={`Schematic microstructure for ${classLabels[materialClass(selected.family)].toLowerCase()}`} />
            <div className="cs-mat-hero-body">
              <div className="material-title-row">
                <div>
                  <span className="cs-overline cs-overline--dark">{selected.id} · {classLabels[materialClass(selected.family)]}</span>
                  <h3>{selected.name}</h3>
                </div>
                <button className="science-icon-button" onClick={exportJson} aria-label="Export selected material as JSON"><FileJson2 size={17} aria-hidden="true" /></button>
              </div>
              <div className="cs-tag-row">
                <DataTag kind="synthetic" />
                <span className="cs-soft-chip"><span className="cs-mono">{relatedCount}</span> related experiment records</span>
              </div>
              <p className="cs-caption cs-caption--dark">Schematic microstructure illustration (not a micrograph). Values are not measured, not published reference data and not validated for design use.</p>
            </div>
          </article>

          <article className="cs-card">
            <div className="cs-card-head">
              <div>
                <span className="cs-overline cs-overline--dark">Side-by-side comparison</span>
                <h3>Property table</h3>
              </div>
              <label className="cs-select cs-select--light">
                <span>Compare with</span>
                <span className="cs-select-wrap">
                  <select value={comparisonId} onChange={(e) => setComparisonId(e.target.value)}>
                    <option value="">No comparison</option>
                    {materials.filter((m) => m.id !== selected.id).map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                  <ChevronDown size={14} aria-hidden="true" />
                </span>
              </label>
            </div>
            <div className="cs-table-wrap">
              <table className="cs-table">
                <thead>
                  <tr><th scope="col">Property</th><th scope="col">{selected.name}</th>{comparison && <th scope="col">{comparison.name}</th>}<th scope="col">Unit</th></tr>
                </thead>
                <tbody>
                  {rows.map(([label, key, unit]) => (
                    <tr key={key}>
                      <th scope="row">{label}</th>
                      <td className="cs-mono">{selected[key]}</td>
                      {comparison && <td className="cs-mono">{comparison[key]}</td>}
                      <td className="cs-unit">{unit}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </article>

          <article className="cs-card">
            <span className="cs-overline cs-overline--dark">Temperature response</span>
            <h3>Young&apos;s modulus from −60 °C to 40 °C</h3>
            <SciChart tone="light" series={series} xLabel="Temperature" xUnit="°C" yLabel="Young's modulus" yUnit="GPa" smooth onExport={exportCsv} caption="10 °C spacing · synthetic function, not test data. Hover or use arrow keys to read values." />
            {notice && <p className="science-success" role="status">{notice}</p>}
          </article>

          <div className="cs-split cs-split--even">
            <article className="cs-card">
              <div className="cs-card-head">
                <div>
                  <span className="cs-overline cs-overline--dark">Family comparison · averages</span>
                  <h3>{metrics[metric].label}</h3>
                </div>
                <label className="cs-select cs-select--light">
                  <span className="sr-only">Property to compare</span>
                  <span className="cs-select-wrap">
                    <select value={metric} onChange={(e) => setMetric(e.target.value)}>
                      {Object.entries(metrics).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                    <ChevronDown size={14} aria-hidden="true" />
                  </span>
                </label>
              </div>
              <BarChart tone="light" items={barItems} unit={metrics[metric].unit} log={metrics[metric].log} ariaLabel={`${metrics[metric].label} by material family`} caption={`Selected family highlighted. Synthetic demonstration averages${metric === "embodiedCarbonKgCO2eKg" ? "; negative values represent stored biogenic carbon" : ""}`} />
            </article>
            <article className="cs-card">
              <span className="cs-overline cs-overline--dark">Data availability</span>
              <h3>Temperature-dependent data</h3>
              <ul className="cs-avail">
                {availability.map((a) => (
                  <li key={a.property}>
                    <span>{a.property}</span>
                    <DataTag kind={a.status} compact label={a.status === "missing" ? "Not available" : "Synthetic curve"} />
                    <small>{a.note}</small>
                  </li>
                ))}
              </ul>
              <p className="cs-caption cs-caption--dark">Missing temperature-dependent data is shown as missing — never interpolated or invented.</p>
            </article>
          </div>
        </section>
      </div>
    </div>
  );
}
