import React, { useMemo, useState } from "react";
import { Filter, Search, Snowflake } from "lucide-react";
import SectionTitle from "../components/SectionTitle";
import RoomCard from "../components/RoomCard";
import Modal from "../components/Modal";
import { rooms } from "../data/mockData";
export default function Palace({favorites,setFavorites,search}) {
  const [filter,setFilter]=useState("All"); const [selected,setSelected]=useState(null);
  const categories=["All",...new Set(rooms.map(r=>r.category))];
  const filtered=useMemo(()=>rooms.filter(r=>(filter==="All"||r.category===filter)&&(`${r.name} ${r.description} ${r.category}`).toLowerCase().includes(search.toLowerCase())),[filter,search]);
  const toggle=id=>setFavorites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
  return <div className="page-wrap"><SectionTitle eyebrow="THE NORTH MOUNTAIN" title="Explore the Ice Palace" description="Ten imagined spaces, each shaped by a different expression of Elsa's winter magic."/>
    <div className="palace-banner"><div><span className="eyebrow">ARCHITECTURE NOTEBOOK</span><h3>Every crystal tells a story.</h3><p>Explore the rooms, discover their details, and save the spaces that inspire you.</p></div><div className="banner-crystal">✧</div></div>
    <div className="filter-row"><div className="filter-label"><Filter size={15}/> Filter rooms</div><div className="filter-pills">{categories.map(c=><button key={c} className={filter===c?"selected":""} onClick={()=>setFilter(c)}>{c}</button>)}</div><span className="result-count">{filtered.length} spaces</span></div>
    <div className="rooms-grid">{filtered.map(r=><RoomCard key={r.id} room={r} onClick={setSelected} favorite={favorites.includes(r.id)} onFavorite={toggle}/>)}</div>
    {!filtered.length&&<div className="empty-state"><Snowflake size={28}/><h3>No rooms found</h3><p>Try a different search or category.</p></div>}
    <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?.name}><div className={`modal-room-art art-${selected?.id}`}><span>{selected?.icon}</span></div>{selected&&<><p className="modal-description">{selected.description}</p><div className="detail-chips"><span>{selected.level}</span><span>{selected.mood}</span><span>{selected.temperature}</span></div><h4>Architectural details</h4><ul className="detail-list">{selected.details.map(d=><li key={d}>{d}</li>)}</ul><button className="primary-btn full-btn" onClick={()=>toggle(selected.id)}>{favorites.includes(selected.id)?"Remove from favorites":"Save this room"} ♥</button></>}</Modal>
  </div>;
}
