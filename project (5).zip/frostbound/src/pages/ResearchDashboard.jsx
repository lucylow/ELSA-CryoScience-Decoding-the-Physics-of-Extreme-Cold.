import React from "react";
import { Activity, ArrowRight, Atom, BookOpenCheck, Boxes, FlaskConical, Snowflake, Thermometer, Waves } from "lucide-react";
import { experimentRecords, materialFamilies, materials, propertyPointCount } from "../data/scienceData";

const formatNumber = (value) => new Intl.NumberFormat("en-US").format(value);

export default function ResearchDashboard({ setPage }) {
  const metrics = [
    { label: "Demonstration materials", value: formatNumber(materials.length), detail: `${materialFamilies.length} material families`, icon: Boxes },
    { label: "Temperature data points", value: formatNumber(propertyPointCount), detail: "Young's modulus curves · −60 to 40°C", icon: Activity },
    { label: "Experiment records", value: formatNumber(experimentRecords.length), detail: "Generated demonstration records", icon: FlaskConical },
    { label: "Research workflows", value: "3", detail: "Explorer · thermal · freeze–thaw", icon: Atom },
  ];
  const workflows = [
    { id: "materials", icon: Boxes, eyebrow: "01 / MATERIALS", title: "Explore the dataset", text: "Filter a 100-record catalog, inspect temperature-dependent properties, compare materials, or export a record.", action: "Open materials explorer" },
    { id: "lab", icon: Thermometer, eyebrow: "02 / THERMAL SCIENCE", title: "Run a heat-transfer study", text: "Adjust boundary temperatures, specimen thickness, area, and material. See the steady-state 1D Fourier-law calculation and assumptions.", action: "Open thermal lab" },
    { id: "lab-freeze", icon: Snowflake, eyebrow: "03 / EXPOSURE", title: "Investigate freeze–thaw", text: "Set cycle count and degree of saturation to explore a clearly illustrative exposure index—not a service-life prediction.", action: "Open freeze–thaw lab" },
  ];

  return <div className="page-wrap science-dashboard">
    <section className="science-hero">
      <div className="science-hero-copy">
        <span className="science-kicker"><Snowflake size={14} /> EXTREME LOW-TEMPERATURE SCIENCE & ADVANCED MATERIALS LABORATORY</span>
        <h2>The palace is <em>the laboratory.</em></h2>
        <p>Explore how materials respond to cold, heat, moisture, and repeated exposure. Follow the numbers back to their assumptions.</p>
        <div className="science-hero-actions">
          <button className="science-primary" onClick={() => setPage("materials")}>Explore materials <ArrowRight size={15} /></button>
          <span className="science-evidence"><i /> Synthetic demonstration environment</span>
        </div>
      </div>
      <div className="science-hero-visual" aria-hidden="true"><div className="science-orbit orbit-one"/><div className="science-orbit orbit-two"/><div className="science-crystal"><span>ICE</span></div><div className="science-hero-caption"><b>−60° → 40°C</b><small>temperature envelope</small></div></div>
    </section>

    <section className="science-metrics" aria-label="Dataset summary">
      {metrics.map(({ label, value, detail, icon: Icon }) => <article className="science-metric" key={label}><span className="science-metric-icon"><Icon size={17}/></span><div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div></article>)}
    </section>

    <div className="science-section-heading"><div><span className="science-overline">RESEARCH WORKFLOWS</span><h3>Choose an investigation</h3></div><span className="science-heading-note"><Waves size={15}/> Models are educational prototypes</span></div>
    <section className="science-workflow-grid" aria-label="Research workflows">
      {workflows.map(({ id, icon: Icon, eyebrow, title, text, action }, index) => <article className="science-workflow-card" key={id}><div className="science-workflow-top"><span className="science-workflow-icon"><Icon size={19}/></span><span>{eyebrow}</span></div><h4>{title}</h4><p>{text}</p><button className="science-text-button" onClick={() => setPage(id === "lab-freeze" ? "lab" : id)}> {action}<ArrowRight size={14}/></button>{index === 0 && <div className="science-card-watermark" aria-hidden="true">01</div>}</article>)}
    </section>

    <section className="science-bottom-grid">
      <article className="science-note-card"><div className="science-note-icon"><BookOpenCheck size={18}/></div><div><span className="science-overline">EVIDENCE FIRST</span><h4>Every number carries its provenance.</h4><p>The starter dataset is synthetic and deterministic. It is useful for exploring the interface and calculations, but it is not experimental evidence, published reference data, or a design value.</p></div></article>
      <article className="science-note-card palace-link-card"><div className="science-note-icon"><Snowflake size={18}/></div><div><span className="science-overline">THE RESEARCH CAMPUS</span><h4>Return to the ice palace</h4><p>Keep exploring the original palace rooms, winter world, gallery, and story—now with a connected research wing.</p><button className="science-text-button" onClick={() => setPage("palace")}>Visit the palace directory <ArrowRight size={14}/></button></div></article>
    </section>
    <div className="science-disclaimer"><Activity size={14}/><span>Not for design decisions. Demonstration calculations use simplified assumptions and require independent engineering validation.</span></div>
  </div>;
}
