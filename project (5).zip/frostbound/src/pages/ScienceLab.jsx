import React, { useMemo, useState } from "react";
import { Activity, ArrowRight, Info, RotateCcw, Snowflake, Thermometer, Waves } from "lucide-react";
import { materials } from "../data/scienceData";
import { calculateIceHeatingState, calculateIllustrativeFreezeThawIndex, calculateSteadyStateHeatTransfer, clamp } from "../utils/scienceCalculations";

const tabs = [
  { id: "heat", label: "Heat transfer", icon: Thermometer },
  { id: "freeze", label: "Freeze–thaw", icon: Snowflake },
  { id: "phase", label: "Phase change", icon: Waves },
];

export default function ScienceLab({ initialTab = "heat" }) {
  const [tab, setTab] = useState(initialTab);
  const [materialId, setMaterialId] = useState(materials[0].id);
  const material = materials.find((item) => item.id === materialId) ?? materials[0];
  return <div className="page-wrap science-page">
    <div className="science-page-heading"><div><span className="science-overline">COLD-CLIMATE ENGINEERING / 02</span><h2>Thermal & exposure lab</h2><p>Change the conditions and inspect the calculation behind each result.</p></div><span className="science-lab-status"><i/> Interactive demonstration</span></div>
    <section className="science-lab-tabs" role="tablist" aria-label="Science laboratory modules">{tabs.map(({ id, label, icon: Icon }) => <button key={id} className={`science-tab ${tab === id ? "active" : ""}`} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}><Icon size={16}/>{label}</button>)}</section>
    {tab !== "phase" && <label className="science-lab-material science-field-label">Specimen material<span className="select-wrap"><select value={materialId} onChange={(event) => setMaterialId(event.target.value)}>{materials.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.thermalConductivityWMK} W/(m·K)</option>)}</select></span></label>}
    {tab === "heat" && <HeatTransfer material={material}/>}
    {tab === "freeze" && <FreezeThaw material={material}/>}
    {tab === "phase" && <PhaseChange/>}
  </div>;
}

function HeatTransfer({ material }) {
  const [hot, setHot] = useState(12);
  const [cold, setCold] = useState(-24);
  const [thickness, setThickness] = useState(0.12);
  const [area, setArea] = useState(1.2);
  const result = useMemo(() => calculateSteadyStateHeatTransfer({ conductivityWMK: material.thermalConductivityWMK, areaM2: area, hotTemperatureC: hot, coldTemperatureC: cold, thicknessM: thickness }), [material, area, hot, cold, thickness]);
  const points = Array.from({ length: 41 }, (_, index) => ({ x: 34 + index * 12.5, y: 42 + (hot - (hot - cold) * index / 40 + 40) * 3.2 }));
  const path = points.map((point, index) => `${index ? "L" : "M"}${point.x} ${clamp(point.y, 30, 190)}`).join(" ");
  return <div className="science-lab-grid">
    <article className="science-panel science-controls"><div className="science-panel-heading"><span className="science-panel-icon"><Thermometer size={17}/></span><div><span className="science-overline">STEADY-STATE MODEL</span><h3>Boundary conditions</h3></div></div>
      <RangeControl id="hot" label="Warm-side temperature" value={hot} unit="°C" min={-20} max={40} onChange={setHot}/><RangeControl id="cold" label="Cold-side temperature" value={cold} unit="°C" min={-60} max={20} onChange={setCold}/><RangeControl id="thickness" label="Specimen thickness" value={thickness} unit="m" min={0.02} max={0.5} step={0.01} onChange={setThickness}/><RangeControl id="area" label="Transfer area" value={area} unit="m²" min={0.2} max={5} step={0.1} onChange={setArea}/>
      <div className="science-assumption"><Info size={15}/><p>One-dimensional, steady-state conduction through a homogeneous plane layer. Constant conductivity; no contact resistance, convection, radiation, or thermal storage.</p></div>
    </article>
    <article className="science-panel science-results"><div className="science-panel-heading"><span className="science-panel-icon"><Activity size={17}/></span><div><span className="science-overline">CALCULATED OUTPUT</span><h3>Heat flow through specimen</h3></div></div>
      <div className="science-result-callout"><div><span>Heat-transfer rate</span><strong>{Math.abs(result.heatRateW).toLocaleString("en-US", { maximumFractionDigits: 1 })}<small> W</small></strong></div><div className="result-direction"><span>Direction</span><b>{result.heatRateW >= 0 ? "Warm → cold" : "Cold → warm"}</b></div></div>
      <div className="science-equation"><span>FOURIER&apos;S LAW · 1D, STEADY STATE</span><code>Q̇ = k · A · (T<sub>hot</sub> − T<sub>cold</sub>) / L</code><small>{material.thermalConductivityWMK} × {area.toFixed(1)} × ({hot} − ({cold})) / {thickness.toFixed(2)} = {Math.abs(result.heatRateW).toFixed(1)} W</small></div>
      <div className="science-chart-block"><div className="science-chart-title"><span>Illustrative layer temperature profile</span><span>{material.name}</span></div><svg className="science-profile-chart" viewBox="0 0 560 210" role="img" aria-label={`Linear temperature profile from ${hot} degrees Celsius to ${cold} degrees Celsius through the specimen`}><defs><linearGradient id="thermal-line" x1="0" x2="1"><stop stopColor="#ffad7a"/><stop offset="1" stopColor="#69d8f2"/></linearGradient></defs>{[0,1,2,3].map((line) => <line key={line} x1="34" x2="534" y1={48 + line * 43} y2={48 + line * 43} className="chart-gridline"/>)}<path d={path} className="thermal-profile-line"/><circle cx="34" cy={clamp(points[0].y,30,190)} r="5" fill="#ffad7a"/><circle cx="534" cy={clamp(points.at(-1).y,30,190)} r="5" fill="#69d8f2"/><text x="34" y="199" className="chart-tick">Warm boundary · {hot}°C</text><text x="534" y="199" textAnchor="end" className="chart-tick">Cold boundary · {cold}°C</text></svg></div>
      <div className="science-formula-footer"><span>Heat flux</span><b>{Math.abs(result.heatFluxWM2).toLocaleString("en-US", { maximumFractionDigits: 1 })} W/m²</b><span>Temperature difference</span><b>{Math.abs(result.temperatureDropC).toFixed(0)}°C</b></div>
    </article>
  </div>;
}

function FreezeThaw({ material }) {
  const [cycles, setCycles] = useState(24);
  const [saturation, setSaturation] = useState(0.72);
  const materialSensitivity = material.moistureSensitivity;
  const index = calculateIllustrativeFreezeThawIndex({ cycles, saturation, materialSensitivity });
  const profile = Array.from({ length: 121 }, (_, step) => { const cyclePosition = step / 120 * Math.max(cycles, 1); const wave = Math.cos(cyclePosition * Math.PI * 2); return { x: 34 + step * 4.1, y: 108 - wave * 50 }; });
  const path = profile.map((point, pointIndex) => `${pointIndex ? "L" : "M"}${point.x} ${point.y}`).join(" ");
  return <div className="science-lab-grid">
    <article className="science-panel science-controls"><div className="science-panel-heading"><span className="science-panel-icon"><Snowflake size={17}/></span><div><span className="science-overline">EXPOSURE PROFILE</span><h3>Cycle conditions</h3></div></div>
      <RangeControl id="cycles" label="Freeze–thaw cycles" value={cycles} unit="cycles" min={0} max={100} onChange={setCycles}/><RangeControl id="saturation" label="Degree of saturation" value={saturation} unit="fraction" min={0} max={1} step={0.01} onChange={setSaturation}/><div className="science-readout-list"><div><span>Illustrative temperature window</span><b>−20°C ↔ +5°C</b></div><div><span>Selected material family</span><b>{material.family}</b></div><div><span>Moisture sensitivity input</span><b>{materialSensitivity.toFixed(2)} / 1.00</b></div></div><div className="science-assumption"><Info size={15}/><p>This exposure index is a user-interface demonstration. It is not a durability test, damage law, or service-life estimate.</p></div>
    </article>
    <article className="science-panel science-results"><div className="science-panel-heading"><span className="science-panel-icon"><Activity size={17}/></span><div><span className="science-overline">ILLUSTRATIVE OUTPUT</span><h3>Thermal cycling and exposure index</h3></div></div>
      <div className="freeze-summary"><div className="freeze-index"><strong>{index}<small>/100</small></strong><span>illustrative exposure index</span></div><div className="freeze-cycle-total"><b>{cycles}</b><span>defined cycles</span></div></div>
      <div className="science-chart-block"><div className="science-chart-title"><span>Temperature vs. normalized cycle time</span><span>Repeated idealized profile</span></div><svg className="science-profile-chart" viewBox="0 0 560 210" role="img" aria-label={`${cycles} idealized freeze-thaw cycles, from minus 20 to plus 5 degrees Celsius`}><line x1="34" y1="58" x2="526" y2="58" className="chart-gridline"/><line x1="34" y1="108" x2="526" y2="108" className="chart-gridline"/><line x1="34" y1="158" x2="526" y2="158" className="chart-gridline"/><path d={path} className="freeze-profile-line"/><text x="28" y="62" textAnchor="end" className="chart-tick">+5°C</text><text x="28" y="162" textAnchor="end" className="chart-tick">−20°C</text><text x="34" y="196" className="chart-tick">Start</text><text x="526" y="196" textAnchor="end" className="chart-tick">{cycles} cycles</text></svg></div>
      <div className="science-exposure-bar"><span>Index range</span><div><i style={{ width: `${index}%` }}/></div><b>{index}%</b></div><div className="science-data-label"><span>Synthetic demonstration</span><small>Index = cycles × saturation² × material moisture sensitivity × 0.48, capped at 100.</small></div>
    </article>
  </div>;
}

function PhaseChange() {
  const [energy, setEnergy] = useState(220);
  const state = calculateIceHeatingState(energy);
  const frozen = clamp(100 - state.meltedFraction * 100, 0, 100);
  const stagePosition = clamp(energy / 600 * 100, 0, 100);
  return <div className="phase-layout">
    <article className="science-panel phase-control"><div className="science-panel-heading"><span className="science-panel-icon"><Waves size={17}/></span><div><span className="science-overline">ENERGY INPUT</span><h3>Heating 1 kg of ice</h3></div></div><p className="science-panel-copy">Begin with ice at −20°C. Add heat and follow the energy through sensible warming and melting.</p><RangeControl id="energy" label="Energy added" value={energy} unit="kJ/kg" min={0} max={600} onChange={setEnergy}/><div className="phase-state-card"><span>Current state</span><b>{state.phase}</b><strong>{state.temperatureC.toFixed(1)}°C</strong></div><button className="science-text-button" onClick={() => setEnergy(0)}><RotateCcw size={14}/> Reset starting state</button></article>
    <article className="science-panel phase-visual"><div className="science-panel-heading"><span className="science-panel-icon"><Snowflake size={17}/></span><div><span className="science-overline">ENERGY-PHASE PATH</span><h3>Sensible heat & latent heat</h3></div></div>
      <div className="phase-stage-track"><div className="phase-stages"><span className={energy < 42 ? "current" : "done"}>Ice warming</span><span className={energy >= 42 && energy < 376 ? "current" : energy >= 376 ? "done" : ""}>Melting</span><span className={energy >= 376 ? "current" : ""}>Liquid warming</span></div><div className="phase-track"><i style={{ width: `${stagePosition}%` }}/><b style={{ left: `${stagePosition}%` }}/></div><div className="phase-scale"><span>0</span><span>42 kJ/kg</span><span>376 kJ/kg</span><span>600 kJ/kg</span></div></div>
      <div className="phase-ice-visual" aria-label={`${frozen.toFixed(0)} percent of the ice remains frozen`}><div className="phase-water"><span style={{ height: `${100 - frozen}%` }}/><div className="phase-crystals" style={{ opacity: frozen / 100, transform: `scale(${Math.max(0.3, frozen / 100)})` }}><i/><i/><i/><i/><i/></div></div><div className="phase-legend"><span><i className="solid-key"/> Ice remaining <b>{frozen.toFixed(0)}%</b></span><span><i className="liquid-key"/> Melted fraction <b>{(100 - frozen).toFixed(0)}%</b></span></div></div>
      <div className="science-assumption"><Info size={15}/><p>Approximate specific heats: ice 2.1 kJ/(kg·K), water 4.18 kJ/(kg·K); latent heat of fusion 334 kJ/kg. Pressure effects and heat losses are ignored.</p></div>
    </article>
  </div>;
}

function RangeControl({ id, label, value, unit, min, max, step = 1, onChange }) {
  const display = step < 1 ? Number(value).toFixed(step < 0.01 ? 2 : step < 0.1 ? 2 : 1) : value;
  return <div className="science-range-control"><div className="science-range-label"><label htmlFor={id}>{label}</label><output htmlFor={id}>{display} <small>{unit}</small></output></div><input id={id} type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))}/><div className="science-range-limits"><span>{min}</span><span>{max}</span></div></div>;
}
