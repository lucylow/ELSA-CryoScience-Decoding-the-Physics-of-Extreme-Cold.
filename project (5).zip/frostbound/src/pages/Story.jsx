import React from "react";
import SectionTitle from "../components/SectionTitle";
import { timeline } from "../data/mockData";
export default function Story() {
 return <div className="page-wrap"><SectionTitle eyebrow="A JOURNEY THROUGH WINTER" title="Elsa's story timeline" description="A compact, illustrative timeline of key emotional and magical turning points."/><div className="timeline-wrap">{timeline.map((item,i)=><div className="timeline-item" key={item.title}><div className="timeline-marker">{String(i+1).padStart(2,"0")}</div><div className="timeline-card"><span className="eyebrow">{item.year} · {item.tag}</span><h3>{item.title}</h3><p>{item.text}</p></div></div>)}</div><div className="story-note"><span>✧</span><p>This timeline is a fan-made summary, not a complete scene-by-scene chronology.</p></div></div>;
}
