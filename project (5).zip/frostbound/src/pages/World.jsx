import React, { useState } from "react";
import SectionTitle from "../components/SectionTitle";
import { locations } from "../data/mockData";
export default function World() {
 const [active,setActive]=useState(locations[2]);
 return <div className="page-wrap"><SectionTitle eyebrow="BEYOND THE PALACE" title="The winter world" description="A storybook atlas of places connected to Elsa's journey."/>
 <div className="world-layout"><div className="storybook-map"><div className="map-contour c1"/><div className="map-contour c2"/><div className="map-mountain">♢</div><div className="map-water"/>{locations.map((l,i)=><button key={l.id} className={`map-pin pin-${i} ${active.id===l.id?"active":""}`} onClick={()=>setActive(l)}><i/>{l.name}</button>)}<div className="map-compass">N<br/>✧</div></div>
 <div className="location-panel"><span className="eyebrow">{active.type} · {active.region}</span><h3>{active.name}</h3><p>{active.description}</p><div className="location-highlight"><small>NOTABLE FEATURES</small><b>{active.highlight}</b></div><div className="location-switcher">{locations.map(l=><button key={l.id} onClick={()=>setActive(l)} className={active.id===l.id?"active":""}>{l.name}</button>)}</div></div></div></div>;
}
