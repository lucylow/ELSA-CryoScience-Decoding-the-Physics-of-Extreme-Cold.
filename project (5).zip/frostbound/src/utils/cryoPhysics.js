// Standard textbook values for water at ~1 atm (educational reference values).
export const WATER = {
  cIce: 2.09, // kJ/(kg·K)
  cWater: 4.18, // kJ/(kg·K)
  cSteam: 2.01, // kJ/(kg·K)
  latentFusion: 334, // kJ/kg
  latentVaporization: 2257, // kJ/kg
  startC: -40,
  endC: 140,
};

const S1 = WATER.cIce * (0 - WATER.startC);
const S2 = S1 + WATER.latentFusion;
const S3 = S2 + WATER.cWater * 100;
const S4 = S3 + WATER.latentVaporization;
const S5 = S4 + WATER.cSteam * (WATER.endC - 100);
export const HEATING_TOTAL_KJ = S5;
export const HEATING_BREAKPOINTS = [0, S1, S2, S3, S4, S5];

/** Heating 1 kg of water from −40 °C: returns phase, temperature and phase fractions for energy Q (kJ/kg). */
export function heatingState(q) {
  const Q = Math.max(0, Math.min(HEATING_TOTAL_KJ, q));
  if (Q < S1) return { stage: 0, phase: "Solid ice warming", equation: "Q = m·c_ice·ΔT", temperatureC: WATER.startC + Q / WATER.cIce, liquid: 0, vapour: 0 };
  if (Q < S2) return { stage: 1, phase: "Melting at 0 °C", equation: "Q = m·L_f", temperatureC: 0, liquid: (Q - S1) / WATER.latentFusion, vapour: 0 };
  if (Q < S3) return { stage: 2, phase: "Liquid water warming", equation: "Q = m·c_water·ΔT", temperatureC: (Q - S2) / WATER.cWater, liquid: 1, vapour: 0 };
  if (Q < S4) {
    const v = (Q - S3) / WATER.latentVaporization;
    return { stage: 3, phase: "Boiling at 100 °C", equation: "Q = m·L_v", temperatureC: 100, liquid: 1 - v, vapour: v };
  }
  return { stage: 4, phase: "Water vapour warming", equation: "Q = m·c_steam·ΔT", temperatureC: 100 + (Q - S4) / WATER.cSteam, liquid: 0, vapour: 1 };
}

export const heatingCurve = HEATING_BREAKPOINTS.map((q) => ({ x: Math.round(q), y: heatingState(Math.min(q, HEATING_TOTAL_KJ - 1e-6)).temperatureC }))
  .map((p, i, arr) => (i === arr.length - 1 ? { x: p.x, y: WATER.endC } : p));

/** Linear interpolation of a {temperatureC, youngsModulusGPa} curve; null outside the data range. */
export function interpolateModulus(curve, temperatureC) {
  const first = curve[0];
  const last = curve[curve.length - 1];
  if (temperatureC < first.temperatureC || temperatureC > last.temperatureC) return null;
  for (let i = 0; i < curve.length - 1; i++) {
    const a = curve[i];
    const b = curve[i + 1];
    if (temperatureC >= a.temperatureC && temperatureC <= b.temperatureC) {
      const t = (temperatureC - a.temperatureC) / (b.temperatureC - a.temperatureC || 1);
      return a.youngsModulusGPa + t * (b.youngsModulusGPa - a.youngsModulusGPa);
    }
  }
  return last.youngsModulusGPa;
}

/** Linear thermal contraction ΔL = α·L0·ΔT with constant α (micro-strain per K). Returns millimetres. */
export function thermalLengthChangeMm({ alphaMicroPerK, lengthM, fromC, toC }) {
  return alphaMicroPerK * 1e-6 * lengthM * (toC - fromC) * 1000;
}

/** Lumped-capacitance (Newton) cooling of a thin slab: T(t) = T∞ + (T0 − T∞)·e^(−t/τ), τ = ρ·c·L / h. */
export function lumpedCoolingProfile({ densityKgM3, specificHeatJkgK, thicknessM = 0.01, hWm2K = 25, startC = 20, ambientC = -40, minutes = 120, steps = 24 }) {
  const tauS = (densityKgM3 * specificHeatJkgK * thicknessM) / hWm2K;
  const points = Array.from({ length: steps + 1 }, (_, i) => {
    const tMin = (minutes * i) / steps;
    return { x: Number(tMin.toFixed(1)), y: ambientC + (startC - ambientC) * Math.exp((-tMin * 60) / tauS) };
  });
  return { tauMinutes: tauS / 60, points };
}

/** Nakaya-style snow crystal habit as a function of air temperature (simplified, educational). */
export function snowHabit(temperatureC) {
  if (temperatureC > 0) return { habit: "No snow crystals", detail: "Above 0 °C ice crystals melt; precipitation falls as rain." };
  if (temperatureC >= -4) return { habit: "Thin plates", detail: "Near 0 to −4 °C growth favours flat hexagonal plates." };
  if (temperatureC >= -10) return { habit: "Columns & needles", detail: "Around −4 to −10 °C prism faces grow fastest, forming needles and hollow columns." };
  if (temperatureC >= -22) return { habit: "Plates & dendrites", detail: "Around −10 to −22 °C plates return; near −15 °C with high supersaturation, branching dendrites form." };
  return { habit: "Columns & plates", detail: "Below about −22 °C small columns and thick plates dominate." };
}
