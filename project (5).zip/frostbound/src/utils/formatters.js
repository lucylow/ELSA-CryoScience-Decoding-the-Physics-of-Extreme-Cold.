export const titleCase = value => String(value).replace(/[-_]/g," ").replace(/\\b\\w/g,c=>c.toUpperCase());
export const clamp = (value,min,max)=>Math.min(max,Math.max(min,Number(value)||0));
export const shortDate = date => new Intl.DateTimeFormat("en",{month:"short",day:"numeric"}).format(new Date(date));
export const makeId = prefix => `${prefix}-${Math.random().toString(36).slice(2,8)}`;
