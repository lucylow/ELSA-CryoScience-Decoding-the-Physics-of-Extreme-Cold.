export const snowflakeAngles = Array.from({length:6},(_,i)=>i*60);
export const crystalPoints = (radius=1)=>snowflakeAngles.map(degrees=>({x:Math.cos(degrees*Math.PI/180)*radius,y:Math.sin(degrees*Math.PI/180)*radius}));
export const estimateSpireRatio = (height,width)=>Number((height/Math.max(1,width)).toFixed(2));
export const frostPalette = {ice:"#a9e8ff",silver:"#e8f8ff",violet:"#bdbbff",mint:"#b9f1df",fjord:"#143b5b"};
