export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function calculateSteadyStateHeatTransfer({ conductivityWMK, areaM2, hotTemperatureC, coldTemperatureC, thicknessM }) {
  if (![conductivityWMK, areaM2, hotTemperatureC, coldTemperatureC, thicknessM].every(Number.isFinite)) {
    throw new TypeError("Heat-transfer inputs must be finite numbers.");
  }
  if (conductivityWMK <= 0 || areaM2 <= 0 || thicknessM <= 0) {
    throw new RangeError("Conductivity, area, and thickness must be greater than zero.");
  }
  const heatRateW = conductivityWMK * areaM2 * (hotTemperatureC - coldTemperatureC) / thicknessM;
  return { heatRateW, heatFluxWM2: heatRateW / areaM2, temperatureDropC: hotTemperatureC - coldTemperatureC };
}

export function calculateIllustrativeFreezeThawIndex({ cycles, saturation, materialSensitivity = 0.5 }) {
  if (![cycles, saturation, materialSensitivity].every(Number.isFinite)) {
    throw new TypeError("Freeze–thaw inputs must be finite numbers.");
  }
  if (cycles < 0 || saturation < 0 || saturation > 1 || materialSensitivity < 0 || materialSensitivity > 1) {
    throw new RangeError("Cycles must be non-negative; saturation and sensitivity must be between 0 and 1.");
  }
  return clamp(Math.round(cycles * saturation ** 2 * materialSensitivity * 0.48), 0, 100);
}

export function calculateIceHeatingState(energyKJPerKg) {
  if (!Number.isFinite(energyKJPerKg) || energyKJPerKg < 0) {
    throw new RangeError("Energy must be a finite, non-negative value.");
  }
  const iceSensibleKJPerKg = 2.1 * 20;
  const fusionLatentKJPerKg = 334;
  if (energyKJPerKg < iceSensibleKJPerKg) {
    return { phase: "Warming ice", temperatureC: -20 + energyKJPerKg / 2.1, meltedFraction: 0 };
  }
  if (energyKJPerKg < iceSensibleKJPerKg + fusionLatentKJPerKg) {
    return { phase: "Melting at 0°C", temperatureC: 0, meltedFraction: (energyKJPerKg - iceSensibleKJPerKg) / fusionLatentKJPerKg };
  }
  const liquidEnergy = energyKJPerKg - iceSensibleKJPerKg - fusionLatentKJPerKg;
  return { phase: "Warming liquid water", temperatureC: liquidEnergy / 4.18, meltedFraction: 1 };
}
