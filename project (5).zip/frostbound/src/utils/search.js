export function searchRecords(records,query,fields=["name","description"]){const q=query.trim().toLowerCase();if(!q)return records;return records.filter(record=>fields.some(field=>String(record[field]??"").toLowerCase().includes(q)));}
export function groupBy(items,key){return items.reduce((acc,item)=>{const group=item[key]??"Other";(acc[group]??=[]).push(item);return acc;},{});}
